'''
Write a Program to Implement Ohms Law.
{Note: V = I*R, where, v is voltage, I is current & R is resistance}
Input:
I = 10 amp
R = 5
Output: Voltage V = 50.

'''
i=int(input("I:"))
r=int(input("R:"))

v=i*r
print("voltage V=",v)
