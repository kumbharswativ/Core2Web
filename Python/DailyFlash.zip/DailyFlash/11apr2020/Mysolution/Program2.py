string=input("Enter a string : ")
i=int(input("Enter a first index : "))
j=int(input("Enter a ending index : "))
print(string[i:j+1])
