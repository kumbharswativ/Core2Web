'''
Q. write a program to ASCII values of input character.
input : A
output: ASCII value of A is 65
'''

ch=str(input("Enter a character :"))
print("ASCII value of",ch,"is",ord(ch))
