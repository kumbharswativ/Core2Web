'''
Q. write a program to calculate area of circle
'''

r=int(input("Enter radius of circle"))
area=(3.14*r*r)
print(area)
