'''
Q. Write a program to print following pattern
	1  2  3  4
	5  6  7  8
	9  10 11 12
	13 14 15 16
'''

for x in range(1,17):
	if(x%4==1):
		print(" ")	
	print(x,end=" ")
	

