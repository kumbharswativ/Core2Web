s=input("Enter a sentence:")
print("Length of sentence :",len(s))
