'''
Write a Program that prints Cube Root of a Number entered by
User.
Input: 27
Output: Cube Root of 27 is 3
'''
n=int(input("Input:"))
c=int(n**(1/3))
print("Cube root of",n,"is",c)
