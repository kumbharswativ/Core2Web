'''
Write a Program that accepts a String (i.e. Array of Characters)
from user. In addition, print that String
Input: Hello from Core2Web
Output: Hello from Core2Web

'''
n=str(input("Input:"))
print(n)
