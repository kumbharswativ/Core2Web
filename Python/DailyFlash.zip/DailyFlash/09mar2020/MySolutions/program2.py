
'''
Write a Program that prints the user entered numbers until user
enters 0. Use Do-While Statement for implementation of code.
Input: 1 2 3 4 5 9 0
Output: Exiting Code, You Entered Zero!
'''

n=1
while(n!=0):
	v=int(input())
	if(v==0):
		print("Existing code,You Entered zero!")
		break
	
	



		

	
	
	
	

