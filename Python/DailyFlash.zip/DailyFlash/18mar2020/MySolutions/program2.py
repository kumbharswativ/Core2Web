'''
Write a Program to print following array.
Arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9};
Output: 1 2 3 4 5 6 7 8 9

'''
arr={1,2,3,4,5,6,7,8,9}
for i in arr:
	print(i,end=" ")

