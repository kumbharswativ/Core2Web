'''
Write a Program to Convert entered Hexadecimal Number to
Decimal Number.
Input: Decimal Number: 25
Output: Decimal Number: 37

'''

hexa=input("Hexadecimal Number:")
dec=int(hexa,16)
decm=int(dec)
print("Decimal Number:",str(dec))
