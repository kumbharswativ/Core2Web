string=str(input("Enter a string:"))
print("Reversed string is:",string[::-1])
