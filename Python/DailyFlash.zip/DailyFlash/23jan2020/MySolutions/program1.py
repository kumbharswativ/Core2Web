'''
Write a Program to Print following Pattern
1
2 2 
3 3 3
4 4 4 4

'''
for i in range(1,5):
	for j in range(1,i+1):
		print(i,end=" ")
	print(" ")
