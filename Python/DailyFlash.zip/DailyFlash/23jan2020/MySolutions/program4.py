'''
Write a Program to Print following Pattern
*
* * 
* * *
* * * *

'''
for i in range(0,4):
	for j in range(0,i+1):
		print("*", end=" ")
	print(" ")
