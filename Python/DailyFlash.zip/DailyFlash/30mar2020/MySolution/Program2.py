s=input("Enter a sentence:")
o=len(s.split())
print("Length of sentence:",o)
