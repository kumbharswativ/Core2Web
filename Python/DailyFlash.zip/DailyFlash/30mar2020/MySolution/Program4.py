for i in range(5):
	for j in range(3):
		if(i+j<=1 or i-j>=3):
			print(" ",end=" ")
		else:
			print("0",end=" ")
	print(" ")
