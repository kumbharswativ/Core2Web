'''
Write a Program that accepts an integer from user and prints its
second successor and second predecessor.
Input: 50
Output:
Second Predecessor: 48
Second Successor: 52

'''
n=int(input("Input:"))
m=n-2
print("second predecessor:",m)
s=n+2
print("second Successor:",s)

