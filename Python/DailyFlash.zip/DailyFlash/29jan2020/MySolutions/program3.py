'''
Write a Program to take input length and breadth of rectangle and
calculate its area.
Input : 10 20
Output : Area of rectangle = 200

'''
l=int(input("Enter length of Rectangle:"))
b=int(input("Enter breadth of rectangle:"))
area=l*b
print("Area of rectangle=",area)
