'''
Write a Program to print table of 2.
Output: 2 4 6 8 10 12 14 16 18 20
'''
for i in range(2,21):
	if(i%2==0):
		print(i,end=" ")
