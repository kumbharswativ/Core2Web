
'''
Write a program to print squares of first 10 numbers.
Output:
Square of 1 : 1
Square of 2: 4
Square of 3 : 9
.
.
.
Square of 10 : 100
'''
for i in range(1,11):
	print("Square of",i,":",i*i)
