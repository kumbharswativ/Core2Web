s=input("Enter a string:")
if(s==s[::-1]):
    print("string is pallindrome")
else:
       print("string is not pallindrome")
