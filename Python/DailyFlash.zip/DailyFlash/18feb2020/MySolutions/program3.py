'''
Write a Program to find circumference of a Circle of radius entered
by user.
{Note: The formula to determine Circumference of Circle is 2πr. Where π =
3.142}
Input: radius of Circle 40
Output: The Circumference of Circle with Radius 40 is 251.36

'''

r=int(input("Radius of circle:"))
circumference=2*3.142*r

print("The circumference of circle with radius",r,"is",circumference)
