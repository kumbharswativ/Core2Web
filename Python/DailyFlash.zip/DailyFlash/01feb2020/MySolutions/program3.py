'''
Write a Program to Convert the Hours entered by user into
Seconds.
Input: 1hr
Output: 3600 seconds

'''
n=int(input("Enter Hours:"))
s=n*60*60
print(s,"Seconds")
