'''
Write a Program to Print following Pattern.
7 14 21 28
35 42 49
56 63
70
'''
num = 1
for i in range(0, 4): 
      
        for j in range(i,4): 
          
            
            print(num*7, end=" ") 
          
           
            num = num + 1
      
       
        print("\r") 
  































