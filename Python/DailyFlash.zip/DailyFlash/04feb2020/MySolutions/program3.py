'''
Write a Program to Convert enter distance in feet to centimetres.
Input: Distance in Feet: 6ft
Output: Equivalent distance for 6ft in cm is 180cm.

'''
n=int(input("Distance in Feet:"))
c=n*30
print("Equivalent distance for",n,"ft in cm is",c,"cm")
