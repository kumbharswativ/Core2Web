'''
Write a Program to Convert the entered distance in Kilometre by
user into meter.
Input: Enter Distance in KM: 1
Output: 1 KM is equal to 1000m

'''
m=0
n=int(input("Enter distance in KM:"))
m=n*1000
print(n,"KM is equal to",m,"m")

