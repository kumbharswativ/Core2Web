t=float(input("Enter period of pendulum in seconds:"))
l=(4*(3.142)**2*(9.81))/(t**2)
print("Length of that pendulum in",l,"meters")
