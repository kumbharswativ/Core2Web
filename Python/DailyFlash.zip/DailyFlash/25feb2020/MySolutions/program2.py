'''
Write a Program that calculates Square Root of a number ranging
in 200 to 600

'''
sqrt=0
for i in range(200,601):
	sqrt=int(i**0.5)
	print("square root of ",i,"=",sqrt)



