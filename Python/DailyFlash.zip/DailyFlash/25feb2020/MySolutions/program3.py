'''
Write a Program that accepts a number from user and prints max
digit from that number.
Input: 12357798
Output: The Max Digit from number 12357798 is 9

'''
num=[int (x) for x in input("Input:")]
print("The max number is:",max(num))
