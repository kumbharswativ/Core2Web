f=float(input("enter frequency of pendulum in hz:"))
t=1/f
print("Period of simple pendulum is",t)

