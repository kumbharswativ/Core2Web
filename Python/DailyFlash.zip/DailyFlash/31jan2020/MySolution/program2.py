'''
Write a Program that takes rupees as input from user and convert
them into dollars.
'''

n=float(input("Enter rupees:"))
d=n/71
print("Rupees in Dolor:",d)
