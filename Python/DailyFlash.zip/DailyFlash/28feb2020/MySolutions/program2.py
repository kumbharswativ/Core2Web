'''
Write a Program that calculates diameter of a circle if user provides
circumference of the same circle. {Note: π = 3.142}
Input: Circumference of circle = 25.13
Output: Diameter of that circle is 10

'''
c=float(input("Circumference of circle="))
d=c/(3.142)

print("Diameter of that circle is=",d)
