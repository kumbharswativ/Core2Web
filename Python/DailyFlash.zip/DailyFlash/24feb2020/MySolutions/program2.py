'''
Write a Program that calculates Square Root of a number entered
by user.
{Note: Do not use library functions}
Input: 16
Output: Square Root of 16 is 4

'''
n=int(input("Input:"))
sqrt=int(n**(0.5))
print("Square root of",n,"is",sqrt)
