'''
Write a Program that calculates radius of a circle if user provides
the area covered by that circle.
Input: Area of Circle 50.27
Output: Radius of circle is 4

'''
a=float(input("Area of circle:"))


r=a/3.14

rad=int(r**0.5)
print(rad)

