'''
Write a Program to Convert entered Octal Number to Decimal
Number
Input: Decimal Number: 17
Output: Decimal Number: 15

'''
octal=input("Octal Number:")
decimal=str(int(octal,8))
print("Decimal Number",decimal)
