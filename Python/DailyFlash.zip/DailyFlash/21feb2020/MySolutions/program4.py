
list1=['C','O','R','E']
for i in range(5):
	print(' '.join(list1[i:]))
	
	





