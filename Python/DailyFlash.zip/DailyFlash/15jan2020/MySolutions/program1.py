'''
Q.write a program to check whether the character is uppercase or lowercase character
input: v
output:letter v is in lowercase
'''

ch=input("Enter a character")
if(ch.isupper()):
	print("letter",ch,"is in uppercasecase")
else:
	print("letter",ch,"is in lowercase")
