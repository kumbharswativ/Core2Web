'''
Q.write a program to print following pattern
	1 2 3 4
	1 2 3 4
	1 2 3 4
	1 2 3 4
'''
for x in range(1,5):
	for y in range(1,5):
		print(y,end=" ")
		
	print("")


