'''
Write a Program to find radius of a circle if user provides
circumference of that same circle.
Input: Circumference of circle: 251.36
Output: The Radius of the circle is: 40

'''
n=float(input("Circumference of circle:"))
r=int(n/(2*3.14))
print("The radius of the circle is:",r)
