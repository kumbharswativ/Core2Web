
'''
Write a program that accepts an integer from user and print it.
Input: 11
Output: 11
'''

x=int(input("Input:"))
print(x)
