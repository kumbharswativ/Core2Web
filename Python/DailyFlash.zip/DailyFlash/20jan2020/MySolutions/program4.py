'''
Write a Program to accept 10 integers from user and prints the
sum & average of entered numbers .
Input: 1 2 3 4 5 6 7 8 9 10
Output:
Sum of 10 entered Number is: 55
Average of 10 entered number is: 5.55
'''

a=int(input(" "))
b=int(input(" "))
c=int(input(" "))
d=int(input(" "))
e=int(input(" "))
f=int(input(" "))
g=int(input(" "))
h=int(input(" "))
i=int(input(" "))
j=int(input(" "))

sum=a+b+c+d+e+f+g+h+i+j
print("sum of 10 entered number is:",sum)
avg=sum/10
print("Average of 10 entered number is:",avg)


