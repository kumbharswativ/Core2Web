'''
Write a Program that accepts an integer from user and prints
whether that number is odd or even.
Input: 2
Output: 2 is an Even Number

'''
n=int(input("Enter a number:"))
if(n%2==0):
	print(n,"is an Even Number")
else:
	print(n,"is an odd Number")


