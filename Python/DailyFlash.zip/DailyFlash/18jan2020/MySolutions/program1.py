'''
Q.Write a program to print First 10 Natural Numbers.
Output: 1 2 3 4 5 6 8 9 10
'''
for i in range(1,11):
	print(i,end=(" "))
