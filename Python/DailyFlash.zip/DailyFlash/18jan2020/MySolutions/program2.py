
'''
Write a Program to print Sum of First 10 Natural Numbers.
Output: The sum of First 10 Natural Numbers: 55
'''

sum=0

for i in range(1,11):
	sum=sum+i
print("The sum of first 10 natural numbers:",sum)


