'''
Write a Program to print First 50 Odd Numbers.
Output: 1 3 5 . . . 99
'''
for i in range(1,101):
	if(i%2==1):
		print(i,end=" ")
	
