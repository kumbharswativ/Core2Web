
'''
Write a Program to print First 50 Even Numbers
Output: 2 4 6 . . . 100
'''
for i in range(1,101):
	if(i%2==0):
		print(i,end=" ")
