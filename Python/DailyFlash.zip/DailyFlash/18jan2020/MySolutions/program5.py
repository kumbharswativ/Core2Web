
'''
Write a Program to print following Pattern.
Output:

0 0 0 0
0 0 0 0
0 0 0 0
0 0 0 0
'''

for i in range(4):
	for i in range(4):
		print("0",end=" ")
	print(" ")
