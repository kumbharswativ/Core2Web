'''
Write a Program to that accepts two integers from user and
calculates the Quotient & Reminder from their division
Input: 10 5
Output:
Quotient: 2
Reminder: 0

'''
n1=int(input("Inputs:"))
n2=int(input("Inputs:"))
a=n1//n2
b=n1%n2
print("Remainder=",a)
print("Quptient=",b)
