x=input("Enter a character")
if((x>='a'and'z')or(x>='A'and'Z')):
	print(x,"is a character")
elif(x>='0' and x<='9'):
	print(x,"is a digit")
else:
	print(x,"is a special symbol")


