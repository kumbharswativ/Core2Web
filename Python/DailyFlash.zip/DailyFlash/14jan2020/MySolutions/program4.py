for x in range(4):
    print("1 "*4)
