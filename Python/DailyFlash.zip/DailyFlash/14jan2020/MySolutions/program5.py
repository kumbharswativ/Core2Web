x=int(input("Enter first no. "))
y=int(input("Enter second nos. "))
z=int(input("Enter third nos. "))
if(x>y and x>z):
	print(x,"is max number among 1,4&2")
elif(y>x and y>z):
	print(y,"is max number among 1,4&2")
else:
	print(z,"is max number among 1,4&2")
