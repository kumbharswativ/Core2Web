
for itr in range(1,100,2):
    print(itr)
