class Program3{

	
	public static void main(String args[]){

		for(int itr = 1;itr<100;itr = itr+2){

			System.out.printf("%d\n",itr);
		}	
			
	}
}	
