#include<stdio.h>


void main(){

	for(int itr = 1;itr<100;itr = itr+2){

		printf("%d\n",itr);
	}		

}	
