
for i in range(4,0,-1):
    for j in range(1,5):
        if j < i : 
            print(end="\t")
        else:
            print(j , end="\t")
    print()

