

print(oct(int(input("Enter a binary number : "),2)))
