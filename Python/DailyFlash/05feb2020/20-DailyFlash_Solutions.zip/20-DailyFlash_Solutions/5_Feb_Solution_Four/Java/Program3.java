class Odd{

	public static void main(String[] arr){

		for(int i = 1 ; i <= 100 ; i++){

			if(i % 2 == 0)
				continue;
			else		
				System.out.print( i + "\t");
		}
		System.out.println();
	}
}
