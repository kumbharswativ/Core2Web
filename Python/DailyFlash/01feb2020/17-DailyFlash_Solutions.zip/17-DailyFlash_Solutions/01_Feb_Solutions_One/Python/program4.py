


for i in range(0,4,1):
    for j in range(0,4-i,1):
        if(j%2==0):
            print("+\t",end="")
        else:
            print("=\t",end="")
    print("\n")


