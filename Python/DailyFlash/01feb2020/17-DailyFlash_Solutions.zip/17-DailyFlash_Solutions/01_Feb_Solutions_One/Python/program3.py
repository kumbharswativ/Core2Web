

hour=int(input("Enter The Time In Hour :: "))

print(hour,"Hour In Second ",hour*3600)
