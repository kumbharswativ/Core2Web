

num=int(input("Enter The Input :: "))

for i in range(num,0,-2):
    print(i)

