


num=int(input("Enter The Input :: "))

print(num)

for i in range(num-1,0,-2):
    print(i)
    

