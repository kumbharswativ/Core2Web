
#include<stdio.h>


void main(){
	
	int input;
	printf("Enter the input : ");
	scanf("%d",&input);


	for(int itr  = input-1 ;itr > 0 ;itr = itr-2){
		
		printf("%d\n",itr);
		
	}	
	
}	
