
#include<stdio.h>

void main(){
	
	int hour;
	printf("Enter the time in hour : ");
	scanf("%d",&hour);

	printf("%d hour in Seconds is %d",hour,hour*3600);
	
}	
