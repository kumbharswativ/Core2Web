
#include<iostream>


int main(){
	
	int input;
	printf("Enter the input : ");
	scanf("%d",&input);


	for(int itr  = input ;itr > 0 ;itr = itr-2){
		
		printf("%d\n",itr);
		
	}	
	
}	
