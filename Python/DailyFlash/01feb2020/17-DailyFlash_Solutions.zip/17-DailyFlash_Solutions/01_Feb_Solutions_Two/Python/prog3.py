hrs = int(input("hrs : "))
print("sec : ", hrs * 60 * 60) if hrs >= 0 else print("Enter valid det.")
