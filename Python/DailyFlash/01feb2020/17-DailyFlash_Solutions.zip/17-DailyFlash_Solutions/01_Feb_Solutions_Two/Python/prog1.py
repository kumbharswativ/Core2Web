num = int(input("num : "))
for i in range(num, 0, -1):
    if(i % 2 == 1):
        print(i, end = " ")
