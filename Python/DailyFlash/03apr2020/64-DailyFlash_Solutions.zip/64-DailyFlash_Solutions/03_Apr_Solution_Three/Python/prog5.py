import math
F = float(input("F: "))
print(4 * 3.14 * 3.14 * F * F)
