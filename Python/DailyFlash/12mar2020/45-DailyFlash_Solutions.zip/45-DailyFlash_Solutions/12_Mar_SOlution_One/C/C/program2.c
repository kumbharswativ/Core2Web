
#include <stdio.h>

void main() {
	int n, left, right, place, temp;
	printf("Enter Number : ");
	scanf("%d", &n);
	temp = n;
	right = temp % 10;
	left = 0;
	place = 1;
	temp = temp / 10;
	while(temp != 0){
		left = temp % 10;
		place = place * 10;
		temp = temp / 10;
	}
	printf("%d\n",place);
	printf("Number Before : %d\n", n);
	printf("Number After : %d\n", (left == right)?(n):((right*place) + ((n%place)/10)*10 + left));
}
