
#include <stdio.h>

void main() {

	int n, l, u;
	printf("Enter Lower Limit : \n");
	scanf("%d", &l);
	printf("Enter upper Limit : \n");
	scanf("%d", &u);
	printf("Automorphic Numbers : \n");
	for(int i = l; i<=u; i++){
		if(i*i % 10 == i){
			printf("%d ",i);
		}
	}
	printf("\n");
}
