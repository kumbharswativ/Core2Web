
#include <stdio.h>

void main() {

	int n, sum;

	do {
		
		printf("Enter Number : ");
		scanf("%d", &n);
		sum = 0;
		for(int i = 1; i <= n/2; i++){
			if(n % i == 0){
				sum += i;
			}
		}
		if(sum == n)
			printf("%d\n", n);
		if(n < 0)
			break;
	}while(1);
}
