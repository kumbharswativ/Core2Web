
#include <iostream>

int main() {
	int n, left, right, place, temp;
	std::cout << ("Enter Number : ");
	std::cin >> n;
	temp = n;
	right = temp % 10;
	left = 0;
	place = 1;
	temp = temp / 10;
	while(temp != 0){
		left = temp % 10;
		place = place * 10;
		temp = temp / 10;
	}
	std::cout << ("Number Before : ") << n << std::endl;
	std::cout << ("Number After : ") << ((left == right)?(n):((right*place) + ((n%place)/10)*10 + left)) << std::endl;
}
