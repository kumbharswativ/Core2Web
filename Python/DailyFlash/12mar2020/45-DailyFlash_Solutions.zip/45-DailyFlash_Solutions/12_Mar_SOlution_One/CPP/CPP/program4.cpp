
#include <iostream>

int main() {

	int n,a = 0, b = 1, c;
	c = a+b;
	std::cout << ("Enter Number : \n");
	std::cin >> n;
	for(int i = 1; i<= n; i++){
		for(int j = 1; j < n+i; j++){
			if(j > n-i){
				std::cout << (char)(64 + j) << "\t";
			}
			else
				std::cout << ("\t");
		}
		std::cout << ("\n");
	}
}
