
#include <iostream>

int main() {

	int n, sum;

	do {
		
		std::cout << ("Enter Number : ");
		std::cin >> n;
		sum = 0;
		for(int i = 1; i <= n/2; i++){
			if(n % i == 0){
				sum += i;
			}
		}
		if(sum == n)
			std::cout << (n) << std::endl;
		if(n < 0)
			break;
	}while(1);
}
