
#include <iostream>

int main() {

	int l, u;
	std::cout << ("Enter Lower Limit : \n");
	std::cin >> l;
	std::cout << ("Enter Upper Limit : \n");
	std::cin >> u;
	std::cout << "Autographic Number : \n";
	for(int i = l; i <= u; i++){
		if(i*i % 10 == i){
			std::cout << (i) << " ";
		}
	}
	std::cout << std::endl;
}
