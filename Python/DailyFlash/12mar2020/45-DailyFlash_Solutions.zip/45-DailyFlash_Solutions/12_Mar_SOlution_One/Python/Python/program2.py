n = int(input("Enter Number "))
temp = n
right = temp % 10
left = 0
place = 1
temp = temp // 10
while(temp != 0):
	left = temp % 10
	place = place * 10	
	temp = temp // 10
	
print("Number Before : ", n)
print("Number After : ", n) if(left == right) else print("Number After : ",(right*place) + ((n%place)//10)*10 + left)

