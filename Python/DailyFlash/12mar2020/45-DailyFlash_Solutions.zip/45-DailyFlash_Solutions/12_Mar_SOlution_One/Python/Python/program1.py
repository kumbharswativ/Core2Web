
l = int(input("Enter lower limit : "))
u = int(input("Enter Upper limit : "))
for i in range(l,u+1):
    if(i*i % 10 == i):
        print(i,end = " ")
print()
	

