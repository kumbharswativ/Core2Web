
while True :
		
	print("Enter Number : ")
	n = int(input())
	sum = 0
	for i in range(1, n//2 + 1):
		if(n % i == 0):
			sum += i
	if(sum == n):
		print(n)
	if(n < 0):
		break

