
n = int(input("Enter Number : "))
a = 0
b = 1
c = a + b
for i in range(1,n+1):
    for j in range(1, n+i):
        if j > n - i:
            print(chr(64 + j), end = "\t")
        else:
            print(end = "\t")
    print()
