
import java.io.*;

class Program {
	public static void main(String [] kanif) throws IOException {
		int n, left, right, place, temp;
		System.out.printf("Enter Number : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		temp = n;
		right = temp % 10;
		left = 0;
		place = 1;
		temp = temp / 10;
		while(temp != 0){
			left = temp % 10;
			place = place * 10;
			temp = temp / 10;
		}
		
		System.out.printf("Number Before : %d\n", n);
		System.out.printf("Number After : %d\n", (left == right)?(n):((right*place) + ((n%place)/10)*10 + left));
	}
}