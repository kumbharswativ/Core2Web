

import java.io.*;

class Program {

	public static void main(String[] args) throws IOException {

		int l, u;

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.printf("Enter Lower limit : \n");
		l = Integer.parseInt(br.readLine());
		System.out.printf("Enter upper limit : \n");
		u = Integer.parseInt(br.readLine());
		for(int i = l; i <= u; i++){
			if(i*i % 10 == i){
				System.out.print(i + " ");
			}
		}
		System.out.println();
	}
}
