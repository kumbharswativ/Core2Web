
import java.io.*;

class Program {
	public static void main(String [] kanif) throws IOException {

		int n, sum;

		do {
			
			System.out.printf("Enter Number : ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			n = Integer.parseInt(br.readLine());
			sum = 0;
			for(int i = 1; i <= n/2; i++){
				if(n % i == 0){
					sum += i;
				}
			}
			if(sum == n)
				System.out.printf("%d\n", n);
			if(n < 0)
				break;
		}while(true);
	}
}