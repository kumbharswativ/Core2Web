

import java.io.*;

class Program {

	public static void main(String[] args) throws IOException {

		int n, a = 0, b = 1, c;
		c = a + b;
		System.out.printf("Enter Number : \n");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		for(int i = 1; i<= n; i++){
			for(int j = 1; j < n+i; j++){
				if(j > n-i){
					System.out.print((char)(64 + j) + "\t");
				}
				else
					System.out.printf("\t");
			}
			System.out.printf("\n");
		}
	}
}
