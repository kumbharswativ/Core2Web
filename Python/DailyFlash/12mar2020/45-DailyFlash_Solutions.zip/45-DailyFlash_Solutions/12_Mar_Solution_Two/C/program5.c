#include<stdio.h>
#include<math.h>


void main(){

	float dis1,dis2,dis3;

	int x1,y1;
	int x2,y2;
	int x3,y3;

	printf("Enter x1,,y1 ");
	scanf("%d%d",&x1,&y1);
	printf("Enter x2,,y2 ");
	scanf("%d%d",&x2,&y2);
	printf("Enter x3,,y3 ");
	scanf("%d%d",&x3,&y3);

	dis1 = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
	dis2 = sqrt((x3-x2)*(x3-x3)+(y3-y2)*(y3-y2));
	dis3 = sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));

	printf("len1 : %f\n",dis1);
	printf("len2 : %f\n",dis2);
	printf("len3 : %f\n",dis3);

	printf("Perimeter : %f",dis1+dis2+dis3);
	


	

}	
