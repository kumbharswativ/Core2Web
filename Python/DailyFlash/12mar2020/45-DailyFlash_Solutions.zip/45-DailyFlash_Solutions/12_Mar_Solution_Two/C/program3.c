#include<stdio.h>


void main(){
	
	int num;
	int arr[100];
	int jtr =0 ;
	do{
	
		scanf("%d",&num);
		int sum =0 ;
		for(int itr = 1 ; itr<=num/2 ; itr++){
			
			if(num%itr==0)
				sum = sum+itr;
		
		}		
		if(sum==num){
			
			arr[jtr++]=num;

		}	
			

	
	}while(num > 0);

	for(int itr = 0 ;itr<jtr;itr++)
		printf("%d ",arr[itr]);	

}	
