#include<stdio.h>



void main(){
	
	int upperlimit,lowerlimit;

	printf("Enter the upper limit : ");
	scanf("%d",&upperlimit);

	printf("Enter the lower limit : ");
	scanf("%d",&lowerlimit);
		
	for(int itr = lowerlimit;itr<upperlimit;itr++){

		int number = itr;

		

		int square = number*number;
		int flag = 0;
		while(number>0){
	
			if(number%10!=square%10){
				flag = 1;	
				break;
			}	
			number = number/10;
			square = square/10;
		}	

		if(flag ==0 ){
		
			printf("%d\n",itr);
		}		

	}


}	
