#include<stdio.h>
#include<string.h>


void main(){
	

	char number[1024] ;

	printf("Enter the number : ");
	scanf("%s",number);


	char temp;
	int len = strlen(number);
	temp = number[0];
	number[0] = number[len-1];
	number[len-1]=temp;


	printf("%s",number);



}	
