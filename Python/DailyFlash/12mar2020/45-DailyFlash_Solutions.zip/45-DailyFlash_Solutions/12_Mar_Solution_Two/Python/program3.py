
num = 1000;
arr = []
jtr = 0
while num>0:

    num = input();
    sum1 =0
    for itr in range(1,(num/2)+1):
        if num%itr==0:
            sum1 = sum1+itr;

    if sum1==num:
        arr.append(num);
        jtr = jtr+1

for itr in range(jtr):
    print(arr[itr])
