
number = str(input("Enter the number : "))

num = list(number)


num[0],num[len(num)-1] = num[len(num)-1],num[0]

for itr in range(0,len(num)):
    print(num[itr],end="")


