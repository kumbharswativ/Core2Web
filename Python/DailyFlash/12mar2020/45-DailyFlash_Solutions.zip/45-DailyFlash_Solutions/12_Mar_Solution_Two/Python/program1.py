


upperlimit = input("Enter the upper limit");

lowerlimit = input("Enter the lower limit");

for itr in  range(lowerlimit,upperlimit+1):
    number = itr
    square = number*number;
    flag = 0
    while number>0:
        if number%10 != square%10:
            flag = 1
            break;
        number = number/10
        square = square/10
    if flag==0:
        print(itr)

