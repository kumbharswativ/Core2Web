
ch = 'D'

for itr in range(4):
    ch = chr(ord('D')-itr)

    for jtr in range(4+itr):

        if jtr<3-itr:
            print(" ",end="")
        else:
            print(ch,end="")
            ch = chr(ord(ch)+1)
    print();        
