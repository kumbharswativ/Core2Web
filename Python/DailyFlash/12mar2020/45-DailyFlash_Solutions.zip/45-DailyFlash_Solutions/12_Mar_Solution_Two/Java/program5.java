import java.io.*;



class Program1{

	
	public static void main(String args[])throws IOException{
		
		BufferdReader br = new BufferedReader(new InputStreamReader(System.in));


	}	
}	
