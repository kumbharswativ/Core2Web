class Program4{

	
	public static void main(String args[]){

		
		int ch=68;
		for(int itr = 0 ; itr<4; itr++){
			ch = 68-itr;
			for(int jtr =0; jtr<4+itr;jtr++){

				System.out.print(jtr<3-itr?" ":(char)ch++);

			}
			System.out.printf("\n");


		}	
	}	
}	
