import java.io.*;



class Program2{

	
	public static void main(String args[])throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String num = br.readLine();
		
		int len = num.length();
		char ch[] = num.toCharArray();
		char temp = ch[0];
		ch[0]=ch[len-1];
		ch[len-1]=temp;

		System.out.println(ch);

	}	
}	
