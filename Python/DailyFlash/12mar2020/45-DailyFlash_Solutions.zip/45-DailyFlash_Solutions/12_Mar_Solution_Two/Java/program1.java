import java.io.*;



class Program1{

	
	public static void main(String args[])throws IOException{
		
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			System.out.printf("Enter the upper limit : ");
				int upperlimit = Integer.parseInt(br.readLine());
			System.out.printf("Enter the lower limit : ");
			int lowerlimit = Integer.parseInt(br.readLine());


			for(int itr = lowerlimit;itr<upperlimit;itr++){

				int number = itr;



				int square = number*number;
				int flag = 0;
				while(number>0){

					if(number%10!=square%10){
						flag = 1;
						break;
					}
					number = number/10;
					square = square/10;
				}

				if(flag ==0 ){
	
					System.out.printf("%d\n",itr);
				}

			}	



	}	
}	
