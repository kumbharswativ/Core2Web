import java.io.*;



class Program3{

	
	public static void main(String args[])throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int num;
		int arr[] = new  int[100];
		int jtr =0 ;
		do{

			num = Integer.parseInt(br.readLine());
			int sum =0 ;
			for(int itr = 1 ; itr<=num/2 ; itr++){

				if(num%itr==0)
					sum = sum+itr;

			}
			if(sum==num){

				arr[jtr++]=num;

			}



		}while(num > 0);

		for(int itr = 0 ;itr<jtr;itr++)
			System.out.printf("%d ",arr[itr]);

		}	
}	
