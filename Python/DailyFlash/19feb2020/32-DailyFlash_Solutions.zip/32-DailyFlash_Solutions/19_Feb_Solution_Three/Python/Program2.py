'''
Problem Statement


Program2 -- Write a Program to find radius of a circle if user provides circumference of that same circle.

'''

circum=float(input("Enter the Circumference of the Circle\n:"))

print("The Radius of the Circle is ",round(circum/(3.142*2),2))

