a, n, d = [int(a) for a in input("Enter a, n, d : ").split()]
print("sum : ", (n/2) * (a + a + (n - 1) * d))
