c = float(input("Enter circum : "))
print("Rad : ", c / (2 * 3.14))
