#include<iostream>

int main() {
	double c;
	std::cout << "Enter circum : ";
	std::cin >> c;
	std::cout << "Rad : " << c / (2 * 3.14);
	return 0;
}
