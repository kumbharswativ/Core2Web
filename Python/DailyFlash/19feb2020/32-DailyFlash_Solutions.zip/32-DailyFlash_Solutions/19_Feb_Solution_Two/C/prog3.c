#include<stdio.h>

int main(void) {
	double c;
	printf("Enter circum : ");
	scanf("%lf", &c);
	printf("Rad = %lf", c / (2 * 3.14));
	return 0;
}
