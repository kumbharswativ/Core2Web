k = 0
print("Starting element :");
a = int(input())
print("Number of element :");
n = int(input())
print("Common difference :")
d = int(input())

print("The sum of AP is : ", (n/2)*(2*a+(n-1)*d))
