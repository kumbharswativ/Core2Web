ch = input("Input : ")
print("Uppercase") if ch>='A' and ch<='Z' else print("Lowercase") if ch>='a' and ch<='z' else print("None")
