n1, n2, n3 = input("Input : ").split()
print("Output : Valid") if int(n1)>=0 and int(n2)>=0 and int(n3)>=0 and int(n1)+int(n2)+int(n3)==180 else print("Output : Invalid")
