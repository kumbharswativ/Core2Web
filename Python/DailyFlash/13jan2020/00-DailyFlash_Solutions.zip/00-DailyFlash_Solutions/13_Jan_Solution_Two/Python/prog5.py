n1 = int(input("Input : "))
print("Output : Divisible") if n1%5==0 and n1%11==0 else print("Output : Not divisible")
