n1 = int(input("Input : "))
print("Output : Negative") if n1<0 else print("Output : Zero") if n1==0 else print("Output : Positive")
