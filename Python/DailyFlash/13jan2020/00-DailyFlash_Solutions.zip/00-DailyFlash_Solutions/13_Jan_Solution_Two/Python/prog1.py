n1, n2 = input("Input : ").split()
print("Output : ", n1) if n1>n2 else print("Output : Equal") if n1==n2 else print("Output : ", n2)

