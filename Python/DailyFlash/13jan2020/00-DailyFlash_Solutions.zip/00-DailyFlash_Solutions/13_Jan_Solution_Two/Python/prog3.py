n1 = int(input("Input : "))
print("Even") if n1%2==0 else print("Odd")
