#include<iostream>

int main() {
	int n1;
	std::cout<<"Input : ";
	std::cin>>n1;
	n1%2==0?std::cout<<"Output : Even":std::cout<<"Output : Odd";
	return 0;
}
