#include<stdio.h>

int main() {
	int n1;
	printf("Input : ");
	scanf("%d", &n1);
	n1%2==0?printf("Output : Even"):printf("Odd");
	return 0;
}
