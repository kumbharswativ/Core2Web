
#include <iostream>

main() {

	int a;
	std :: cout << ("Enter Number : \n");
	std::cin >> (a);

	std::cout << ((a % 2 ==  0)? "Even Number" : "Odd Number") << std::endl;
	return 0;
}
