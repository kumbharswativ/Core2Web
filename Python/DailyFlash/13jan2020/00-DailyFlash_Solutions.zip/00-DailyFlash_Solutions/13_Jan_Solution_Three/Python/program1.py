
print("Enter Numbers")
a = input()
b = input()

if a > b :
	print(str(a) + " is max number among " + str(a) + " and " + str(b))
else:
	print(str(b) + " is max number among " + str(a) + " and " + str(b))
