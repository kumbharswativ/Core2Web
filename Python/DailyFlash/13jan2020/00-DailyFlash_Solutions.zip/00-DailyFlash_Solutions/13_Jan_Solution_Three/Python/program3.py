
a = int(input("Enter Number : "))

if a % 2 == 0 :
	print("Number is Even") 
else:
	print("Number is Odd")
