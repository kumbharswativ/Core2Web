
a = int(input("Enter Number : "))

if(a > 0) :
	print("Number is Positive")

elif  (a == 0) :
	print("Number is equal to zero")

else : 
	print("Number is Negative")

