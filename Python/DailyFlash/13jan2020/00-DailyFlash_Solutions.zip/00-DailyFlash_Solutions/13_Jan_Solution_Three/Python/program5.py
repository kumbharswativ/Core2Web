
a = int(input("Enter Number : "))

if a % 5 == 0 and a % 11 == 0:
	print("Number is divisible by 5 & 11")

else :
	print("Number is not divisible by 5 & 11")

