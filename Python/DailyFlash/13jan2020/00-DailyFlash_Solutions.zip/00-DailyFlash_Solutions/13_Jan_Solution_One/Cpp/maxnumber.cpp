/*
 *
 Program 1: Write a Program to Find Maximum between two numbers
 Input: 1 2
 Output: 2 is Max number among 1 & 2
 *
 */


#include<iostream>


int main(){
	
	int a = 2, b = 1 ;

	if(a>b)
		std::cout<<a<<" is greater than "<<b;
	else
		printf("%d is greater than %d",a,b);	
	
}

/*
 **********************output************************
 *
 *
 * 2 is greater than 1
 *
 * **************************************************
 */
