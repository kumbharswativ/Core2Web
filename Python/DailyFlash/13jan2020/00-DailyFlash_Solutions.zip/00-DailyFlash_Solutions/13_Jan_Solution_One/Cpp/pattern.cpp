/*
 
Program 4: Write a Program to Print following Pattern

* * * *
* * * *
* * * *
* * * *


 */

#include<iostream>

int main(){

	
	for(int i=0;i<5;i++){

		for(int j=0;j<5;j++){
			
			syd::cout<<"* ";
		}	
		printf("\n");
	}

}	

/*
 
   	output

*  *  *  *  *
*  *  *  *  *
*  *  *  *  *
*  *  *  *  *
*  *  *  *  *




 */
