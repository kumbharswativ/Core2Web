/*
 *
 Program 2: Write a Program to check whether the number ins Negative,
Positive or equal to Zero.
Input: -2
Output: -2 is the negative number
 *
 */


class NegativeNumber{
	
	public static void main(String args[]){
		
		int a = -2;

        	if(a<0)
                	System.out.println(a+" is negative number");
        	else
             		System.out.println(a+" is positive number");

	}	
	
}	
