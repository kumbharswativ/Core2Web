/*
 *
 Program 1: Write a Program to Find Maximum between two numbers
 Input: 1 2
 Output: 2 is Max number among 1 & 2
 *
 */


class MaxNumber{

	
	public static void main(String args[]){

		int a = 2, b = 1 ;

        	if(a>b)
                	System.out.println(a+" is greater than "+b);
        	else
		    	System.out.println(b+" is greater than "+a);
                	

	}	


}	
