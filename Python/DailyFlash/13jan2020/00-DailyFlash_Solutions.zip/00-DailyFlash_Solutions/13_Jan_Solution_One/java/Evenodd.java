/*

Program 3: Write a Program to Find whether the number Is Even or Odd
Input: 4
Output: 4 is an Even Number!

*/

class EvenOdd{

	
	public static void main(String args[]){

		
		int num =8;

        	if(num%2==0)
                	System.out.println(num+" is even numnber");
		else
                	System.out.println(num+" is odd number");

	}	

}	
