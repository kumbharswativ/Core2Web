/*

Program 3: Write a Program to Find whether the number Is Even or Odd
Input: 4
Output: 4 is an Even Number!

*/

#include<stdio.h>

void main(){

	int a =8;
	
	if(a%2==0)
		printf("%d is even number",a);
	else
		printf("%d is odd number",a);	

}

/*
 *********** output ***************

 * 8 is even number
 *
 * ********************************
