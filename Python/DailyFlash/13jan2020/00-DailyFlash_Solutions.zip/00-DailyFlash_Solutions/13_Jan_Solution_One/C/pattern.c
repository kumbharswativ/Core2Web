/*
 
Program 4: Write a Program to Print following Pattern

* * * *
* * * *
* * * *
* * * *


 */

#include<stdio.h>

void main(){

	
	for(int i=0;i<5;i++){

		for(int j=0;j<5;j++){
			
			printf("*  ");
		}	
		printf("\n");
	}

}	

/*
 
   	output

*  *  *  *  *
*  *  *  *  *
*  *  *  *  *
*  *  *  *  *
*  *  *  *  *




 */
