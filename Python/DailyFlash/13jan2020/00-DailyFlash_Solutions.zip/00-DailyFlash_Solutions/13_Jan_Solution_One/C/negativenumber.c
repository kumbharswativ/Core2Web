/*
 *
 Program 2: Write a Program to check whether the number ins Negative,
Positive or equal to Zero.
Input: -2
Output: -2 is the negative number
 *
 */

#include<stdio.h>

void main(){
	
	int a = -2; 

	if(a<0)
		printf("%d is negative",a);
	else
		printf("%d is positive",a);	

}

/*
 * **************** output *****************8
 *
 * -2 is negative
 *
 *  **************************************** 
