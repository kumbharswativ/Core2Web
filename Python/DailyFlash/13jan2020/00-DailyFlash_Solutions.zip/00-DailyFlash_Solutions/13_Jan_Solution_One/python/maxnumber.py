"""

/*
 *
 Program 1: Write a Program to Find Maximum between two numbers
 Input: 1 2
 Output: 2 is Max number among 1 & 2
 *
 */


"""


a = 2
b = 3

if a>b:
    print(str(a)+" is greater then "+str(b))
else:
    print(str(b)+" is greater then "+str(a))
        
