"""
 
Program 4: Write a Program to Print following Pattern

* * * *
* * * *
* * * *
* * * *


"""




for x in range(5):
    print("* "*4)

