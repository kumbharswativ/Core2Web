
import java.io.*;


class Program2{

	public static void main(String args[])throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.printf("Enter the amount in rupee\n");
		int rupee=Integer.parseInt(br.readLine());

		System.out.printf("Dollor = %f",rupee*0.014); //please google if don't know


		
	

	}	

}	
