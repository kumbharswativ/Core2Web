

#include<iostream>


int main(){

	
	int rupee;
	printf("Enter the amount in rupee\n");
	scanf("%d",&rupee);

	printf("Dollor = %f",rupee*0.014); //please google if don't know
}	
