

num = input("Enter the number ")

temp = 1

for itr in range(num):
    print(temp)
    temp = temp + num
