
rupee = input("Enter the amount in rupee ")

print("Doller : "+str(rupee*0.014))
