rs = float(input("rs : "))
print("Dollars : ", rs / 71.44) if rs >= 0 else print("Enter valid det.")
