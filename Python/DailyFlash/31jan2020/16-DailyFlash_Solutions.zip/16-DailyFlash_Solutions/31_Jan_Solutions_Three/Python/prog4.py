for i in range(4):
    num = 7 - i
    for j in range(i + 1):
        print(num, end = " ")
        num -= 1
    print()
