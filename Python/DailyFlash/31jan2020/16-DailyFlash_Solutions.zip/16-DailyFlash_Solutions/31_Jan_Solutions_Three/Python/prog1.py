inc = int(input("inc : "))
num = 1
for i in range(10):
    print(num, " ")
    num += inc
