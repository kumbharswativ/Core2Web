for i in range(5):
    for j in range(5 - i):
        print(chr(65 + i), end = " ")
    print()
