#include<iostream>


int main(){
	
	int num ;

	printf("Enter the number\n");
	scanf("%d",&num);
	int rem;
	while(num!=0){
		
		rem = num%10;
		int flag = 0;
		for(int itr =2; itr<=rem/2 ; itr++){
			
			if(rem%itr==0){
				flag = 1;
				break;
					
			}
		}	
		if(flag == 0 )
			printf("%d",rem);

		num = num/10;
		
	}	
}	
