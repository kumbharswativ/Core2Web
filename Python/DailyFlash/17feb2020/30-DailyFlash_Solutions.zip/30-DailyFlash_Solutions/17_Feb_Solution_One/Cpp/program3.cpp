#include<iostream>


int main(){
	
	int num;

	printf("Enter the number : ");
	scanf("%d",&num);
	
	int mul=1;
	int rem;
	while(num!=0){
		
		rem = num%10;
		if(rem%2==0)
			mul = mul*rem;
		num = num/10;
	}	

	printf("%d",mul);
}	
