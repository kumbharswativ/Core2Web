

num = input("Enter the number : ")

mul =1
rem = 0

while num!=0:
    rem = num%10

    if rem%2==0:
        mul = mul*rem
    num=num/10

print(mul)
    

