

num = input("Enter the number : ")

rem = 0 

while num!=0:
    rem = num%10
    flag = 0
    for itr in range(2,int((rem/2)+1)):
        if rem%itr == 0:
            flag = 1
            break
    if flag == 0:
        print(rem)
    num = num/10    

