import java.io.*;


class Program2{

	
	public static void main(String args[])throws IOException{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));

		int num = Integer.parseInt(br.readLine());

		int rev = 0;
		int rem=0;
		while(num!=0){
			
			rem = num%10;

			rev = rev*10+rem;

			num = num/10;
					

		}	

		System.out.printf("%d",rev);	
	}	
}	
