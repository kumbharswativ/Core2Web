import java.io.*;


class Program3{

	
	public static void main(String args[])throws IOException{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));

		int num = Integer.parseInt(br.readLine());	
		
		int mul=1;
		int rem;
		while(num!=0){
		
			rem = num%10;
			if(rem%2==0)
				mul = mul*rem;
			num = num/10;
		}	

		System.out.printf("%d",mul);


	}	
}	
