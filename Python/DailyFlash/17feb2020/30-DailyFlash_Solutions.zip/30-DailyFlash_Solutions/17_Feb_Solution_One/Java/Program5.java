import java.io.*;


class Program5{

	
	public static void main(String args[])throws IOException{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));

		int num = Integer.parseInt(br.readLine());


		int rem;
		while(num!=0){
		
			rem = num%10;
			int flag = 0;
			for(int itr =2; itr<=rem/2 ; itr++){
			
				if(rem%itr==0){
					flag = 1;
					break;
						
				}
			}	
			if(flag == 0 )
				System.out.printf("%d",rem);

			num = num/10;
		
		}	
	}	
}	
