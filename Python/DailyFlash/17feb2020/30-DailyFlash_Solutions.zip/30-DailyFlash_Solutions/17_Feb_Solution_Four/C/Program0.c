/* Problem Statement
 *
 * Program0 -- Write a Program to print sum of following series. Take the limiting factor from user and print sum up to that element.
 * Series: 1, 11, 111, 1111, 11111, 111111, 111111 . . .
 *
 * */

//Include Header File for all input output Operations
#include <stdio.h>

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - void
 * Function Arguments - void
 * */
void main() {

	/*
	 * Declarations
	 * num_input_1 - Integer type variable for user input
	 * sum - to keep the sum of all elements in the series
	 * cnt - To keep the count of number of elements in the series
	 * temp - to store the nth element of the series
	 * */
	int num_input_1,cnt = 0,sum = 0,temp = 0;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */
	do {
		printf("Enter Nth Element of the Series	\n");
		/*
		 * if there is character input the scanf returns 0, Hence for unsuccesfull return of scanf execute
		 * */
		if(!scanf("%d",&num_input_1)){

			printf("Character Inputs not allowed, Enter Positive Integers only\n");
			//Store all the character input in a temporary string
			char* tmp;
			scanf("%s",tmp);
			num_input_1 = 0;
		}
		//else-if statement if Condition 1 is false
		else if(num_input_1 <= 0){

			printf("Invalid, Only Positive values allowed\n");
		}

	}while(num_input_1 <= 0);

	cnt = num_input_1;

	//While loop to calculate the elements in the series and add it to the sum
	while(cnt > 0){

		temp = (temp*10) + (1);
		sum = sum + temp;
		cnt--;
	}

	// Print the sum of Elements in the series upto the nth Element
	printf("The Sum of numbers upto %dth Number is %d\n",num_input_1,sum);

}
