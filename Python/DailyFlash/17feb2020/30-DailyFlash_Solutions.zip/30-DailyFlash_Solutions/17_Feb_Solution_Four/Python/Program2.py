'''
Problem Statement


	Program2 -- Write a Program that takes a number as input from user and prints the Multiplication of Even digits.
'''

num=input("Enter a Number\n:")[::-1]

temp = int(num)
prod = 1

while(temp > 0):

    digit = temp%10
    if digit%2 == 0 :
        prod = prod * digit    
    temp = temp//10

print("The Product of Even Digits is ",prod)

