'''
Problem Statement

Program4 -- Write a Program to takes a number from user and prints those digits who are prime in nature.
'''

num=input("Enter a Number\n:")[::-1]

temp = int(num)
print("The Prime Digits are")
while(temp > 0):

    cnt = 0
    digit = temp%10

    for f in range(2,digit):
        if digit%f == 0 :
            cnt+=1
    if cnt == 0 :
        print(digit,end =" ")
    temp = temp//10
print()

