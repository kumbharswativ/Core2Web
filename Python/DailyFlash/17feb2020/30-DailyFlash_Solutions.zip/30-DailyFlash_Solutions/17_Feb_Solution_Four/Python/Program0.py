'''
Problem Statement

Program0 -- Write a Program to print sum of following series. Take the limiting factor from user and print sum up to that element.
Series: 1, 11, 111, 1111, 11111, 111111, 111111 . . .
'''

num=int(input("Enter a Number\n:"))

cnt = num
temp = sum = 0

while(cnt > 0) :

	temp = (temp*10) + (1);
	sum = sum + temp;
	cnt-=1;
	
print("Sum of Elements in the Series is ",sum)

