'''
Problem Statement

Program3 -- Write a Program to Print following Pattern.
 	
 		5	4	3	2	1
 			4	3	2	1
 				3	2	1
 					2	1	
 						1
'''

rows = int(input("Enter The number of rows\n"))

print("The Output of Pattern is")

for x in range(rows,0,-1) :

    for y in range(rows,0,-1):

        if( y > x) :

            print(" \t",end="",sep='')
            
        else :

            print(y,"\t",end="",sep='')
         
    print()
