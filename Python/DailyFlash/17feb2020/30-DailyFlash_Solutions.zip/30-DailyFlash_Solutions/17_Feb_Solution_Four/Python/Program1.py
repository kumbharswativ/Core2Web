'''
Problem Statement


	Program1 -- Write a Program that takes a number as input from user and prints Reversed Number.
'''

num=input("Enter a Number\n:")[::-1]
print("The Reversed Number is ",num)

