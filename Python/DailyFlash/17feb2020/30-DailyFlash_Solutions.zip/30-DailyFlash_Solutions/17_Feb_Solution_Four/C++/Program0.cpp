/* Problem Statement
 *
 * Program0 -- Write a Program to print sum of following series. Take the limiting factor from user and print sum up to that element.
 * Series: 1, 11, 111, 1111, 11111, 111111, 111111 . . .
 *
 * */

//Include Header File for all input output Operations
#include <iostream>

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - int
 * Function Arguments - void
 * */

int main() {

	/*
	 * Declarations
	 * num_input_1 - Integer type variable for user input
	 * sum - to keep the sum of all elements in the series
	 * cnt - To keep the count of number of elements in the series
	 * temp - to store the nth element of the series
	 * */
	int num_input_1,cnt = 0,sum = 0,temp = 0;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */
	do {
		std::cout<<"Enter A number \n";
		/*
		 * if there is character input the cin returns 0, Hence for unsuccesfull return of cin execute
		 * */

		std::cin>>num_input_1;

		//if statement if Condition 1 is false
		if(num_input_1 <= 0){

			std::cout<<"Invalid, Only Positive values allowed"<<std::endl;
		}
		else if(std::cin.fail()){

			std::cout<<"Characters are not allowed"<<std::endl;
		}
		else 
			break;

	}while(!std::cin.fail() && num_input_1 <= 0);

	cnt = num_input_1;

	//While loop to calculate the elements in the series and add it to the sum
	while(cnt > 0){

		temp = (temp*10) + (1);
		sum = sum + temp;
		cnt--;
	}
	std::cout<<"The Sum of numbers upto "<<num_input_1<<"th Number is "<<sum<<std::endl;

	return 0;
}
