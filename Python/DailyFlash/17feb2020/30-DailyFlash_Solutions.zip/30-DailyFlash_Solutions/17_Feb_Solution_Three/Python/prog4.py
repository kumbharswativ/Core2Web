n = int(input("N : "))

for i in range(n):
    for j in range(n):
        if(j >= i):
            print(n - j, end = " ")
        else:
            print(" ", end = " ")
    print()

