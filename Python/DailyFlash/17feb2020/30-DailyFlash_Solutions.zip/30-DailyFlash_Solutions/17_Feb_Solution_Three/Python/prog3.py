num = int(input("Enter num : "))
m = 1
while(num != 0):
    if((num % 10) % 2 == 0):
        m *= num % 10
    num = int(num / 10)
print("mul : ", m)
