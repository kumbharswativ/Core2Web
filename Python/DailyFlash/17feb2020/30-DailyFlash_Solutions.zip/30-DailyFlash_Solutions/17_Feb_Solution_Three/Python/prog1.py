num = int(input("Enter num : "))
s = 0
d = 0
for i in range(num):
    d = d * 10 + 1
    s += d
print("sum : ", s)
