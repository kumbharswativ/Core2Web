num = int(input("Enter num : "))
print("Prime digits : ", end = "")
while(num != 0):
    if(num % 10 == 2 or num % 10 == 3 or num % 10 == 5 or num % 10 == 7):
        print(num % 10, end = " ")
    num = int(num / 10)
