#include<iostream>

int main() {
	int num, rev = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	while(num != 0) {
		rev = rev * 10 + num % 10;
		num /= 10;
	}
	printf("Rev = %d", rev);
	return 0;
}
