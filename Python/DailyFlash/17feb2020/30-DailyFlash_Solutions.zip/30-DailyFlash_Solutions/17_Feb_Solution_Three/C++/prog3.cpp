#include<iostream>

int main() {
	int num, mul = 1;
	std::cout << "Enter num : ";
	std::cin >> num;
	while(num != 0) {
		if((num % 10) % 2 == 0) {
			mul *= num % 10;
		}
		num /= 10;
	}
	printf("Mul : %d", mul);
	return 0;
}
