#include<iosream>

int main() {
	int num, d = 0, sum = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	for(int i = 0; i < num; i++) {
		d = d * 10 + 1;
		sum += d;
	}
	std::cout << "sum : " << sum;
}
