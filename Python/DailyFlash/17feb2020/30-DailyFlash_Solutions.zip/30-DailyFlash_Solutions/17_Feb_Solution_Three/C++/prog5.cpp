#include<iostream>

int main() {
	int num;
	std::cout << "Enter num : ";
	std::cin >> num;
	std::cout << "Prime digits : ";
	while(num != 0) {
		if(num % 10 == 2 || num % 10 == 3 || num % 10 == 5 || num % 10 == 7) {
			std::cout << num % 10 << " ";
		}
		num /= 10;
	}
	return 0;
}
