import java.util.Scanner;

class Demo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter num : ");
		int num = sc.nextInt();
		System.out.print("Prime digits : ");
		while(num != 0) {
			if(num % 10 == 2 || num % 10 == 3 || num % 10 == 5 || num % 10 == 7) {
				System.out.print(num % 10 + " ");
			}
			num /= 10;
		}

	}
}
