import java.util.Scanner;

class Demo {
	public static void main(String[] args) {
		int sum = 0, d = 0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter num : ");
		int num = sc.nextInt();
		for(int i = 0; i < num; i++) {
			d = d * 10 + 1;
			sum += d;
		}
		System.out.print("sum : " + sum);
	}
}
