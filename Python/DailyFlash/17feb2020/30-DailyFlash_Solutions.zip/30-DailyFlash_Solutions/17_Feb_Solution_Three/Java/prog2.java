import java.util.Scanner;

class Demo {
	public static void main(String[] args) {
		int rev = 0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter num : ");
		int num = sc.nextInt();
		while(num != 0) {
			rev = rev * 10 + num % 10;
			num /= 10;
		}
		System.out.print("rev : " + rev);
	}
}
