#include<stdio.h>

int main(void) {
	int num, rem, rev = 0;
	printf("Enter num : ");
	scanf("%d", &num);
	while(num !=  0) {
		rev = rev * 10 + num % 10;
		num /= 10;
	}
	printf("Rev : %d", rev);
}	
