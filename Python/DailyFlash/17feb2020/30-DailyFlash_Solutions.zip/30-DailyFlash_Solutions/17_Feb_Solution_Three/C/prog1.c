#include<stdio.h>
int main(void) {
	int num;
	printf("Enter num : ");
	scanf("%d", &num);
	int d = 0, sum = 0;
	for(int i = 0; i < num; i++) {
		d = d * 10 + 1;
		sum += d;
	}
	printf("sum : %d", sum);
	return 0;
}
