#include<stdio.h>

int main(void) {
	int num;
	printf("Enter num : ");
	scanf("%d", &num);
	printf("Prime digits : ");
	while(num != 0) {
		if(num % 10 == 2 || num % 10 == 3 || num % 10 == 5 || num % 10 == 7) {
			printf("%d ", num % 10);
		}
		num /= 10;
	}
	return 0;
}
