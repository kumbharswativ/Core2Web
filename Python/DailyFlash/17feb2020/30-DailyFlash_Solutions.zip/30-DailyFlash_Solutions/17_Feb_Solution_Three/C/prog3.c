#include<stdio.h>

int main(void) {
	int num, mul = 1;
	printf("Enter num : ");
	scanf("%d", &num);
	while(num != 0) {
		if((num % 10) % 2 == 0) {
			mul *= num % 10;
		}
		num /= 10;
	}
	printf("Sum of even : %d", mul);
	return 0;
}
