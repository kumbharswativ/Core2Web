
n = int(input("Enter Number : "))
temp = 1
while (n!=0):
    if(n%10%2 == 0):
        temp = temp * (n%10) 
    n = n//10
print("Multiplication : ",temp)
