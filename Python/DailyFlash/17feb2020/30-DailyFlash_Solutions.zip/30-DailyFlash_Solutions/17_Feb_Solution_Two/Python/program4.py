n = int(input("Enter Number : "))
for i in range(1,n+1):
	for j in range(1,n+1):
		if(j<i):
			print("\t",end= "")
		else:
			print(n-j+1,end="\t")
	print()
