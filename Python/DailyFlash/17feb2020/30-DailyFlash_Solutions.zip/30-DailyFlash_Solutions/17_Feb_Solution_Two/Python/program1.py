
n = int(input("Enter Number : "))
temp = 0
sum = 0
while (n!=0):
    temp = temp * 10 + 1
    sum = sum + temp; 
    if(n == 1):
        print(temp," =",end = "")
    else:
        print(temp,"+",end = "")
    n-=1
print(temp)
