
import java.io.*;

class Program {
    public static void main(String ... k) throws IOException{
        int n,temp = 0;
        System.out.printf("Enter Number : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        n = Integer.parseInt(br.readLine());
        temp = 1;
        while (n!=0){
            temp = temp * (((n%10)%2 == 0)?(n%10):1); 
            n = n/10;
        }
        System.out.printf("Multiplication of even digits : %d\n",temp);
        
    }
}