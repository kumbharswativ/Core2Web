
import java.io.*;

class Program {
    public static void main(String ... k) throws IOException{
        int n,temp = 0;
        System.out.printf("Enter Number : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        n = Integer.parseInt(br.readLine());
        while (n!=0){
            temp = temp * 10 + n%10; 
            n = n/10;
        }
        System.out.printf("Reverse Number : %d\n",temp);
        
    }
}