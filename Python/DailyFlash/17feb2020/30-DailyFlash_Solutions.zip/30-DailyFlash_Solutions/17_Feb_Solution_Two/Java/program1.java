
import java.io.*;

class Program {
    public static void main(String ... k) throws IOException{
        int n,temp = 0;
        int sum = 0;
        System.out.printf("Enter Number : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        n = Integer.parseInt(br.readLine());
        while (n!=0){
            temp = temp * 10 + 1; 
            sum = sum + temp;
            System.out.printf("%d%c",temp,(n==1)?('='):('+'));
            n--;
        }
        System.out.printf("%d\n",sum);
        
    }
}