
#include<iostream>

int main() {
    int n,temp = 0;
    std::cout << ("Enter Number : ");
    std::cin >> n;

    while (n!=0){
        temp = temp * 10 + n%10; 
	    n = n/10;
    }
    std::cout << ("reverse Number :") << temp << "\n";
    
}
