
#include<iostream>

int main() {
    int n,temp = 0;
    long sum = 0;
    std::cout << ("Enter Number : ");
    std::cin >> n;

    while (n!=0){
        temp = temp * 10 + 1; 
        sum = sum + temp;
        std::cout << temp << ((n==1)?('='):('+'));
        n--;
    }
    std::cout << (sum) << "\n";
    
}
