
#include<stdio.h>

void main() {
    int n,temp = 0;
    long sum = 0;
    printf("Enter Number : ");
    scanf("%d",&n);

    while (n!=0){
        temp = temp * 10 + 1; 
        sum = sum + temp;
        printf("%d%c",temp,(n==1)?('='):('+'));
        n--;
    }
    printf("%ld\n",sum);
    
}
