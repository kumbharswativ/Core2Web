
#include<stdio.h>

void main() {
    int n,temp = 0;
    printf("Enter Number : ");
    scanf("%d",&n);
	
    temp = 1;
    while (n!=0){
        temp = temp *(((n%10)%2 == 0)?(n%10):1);
	n = n/10;
    }
    printf("Multiplication of Even digits: %d\n",temp);
    
}
