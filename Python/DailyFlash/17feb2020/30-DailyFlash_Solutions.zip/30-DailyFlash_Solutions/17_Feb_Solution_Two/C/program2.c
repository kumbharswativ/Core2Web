
#include<stdio.h>

void main() {
    int n,temp = 0;
    printf("Enter Number : ");
    scanf("%d",&n);

    while (n!=0){
        temp = temp * 10 + n%10; 
	n = n/10;
    }
    printf("reverse Number : %d\n",temp);
    
}
