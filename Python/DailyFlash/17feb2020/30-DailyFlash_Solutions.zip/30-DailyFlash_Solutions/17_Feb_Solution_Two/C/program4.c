
#include<stdio.h>

void main() {
    int n,temp = 0;
    printf("Enter Number : ");
    scanf("%d",&n);
	
    for(int i = 1; i <= n; i++){
    	for(int j = 1; j <= n; j++){
		if(j<i){
			printf("\t");
		}
		else{
			printf("%d\t",(n-j+1));
		}
	}
	printf("\n");
    }
    
}
