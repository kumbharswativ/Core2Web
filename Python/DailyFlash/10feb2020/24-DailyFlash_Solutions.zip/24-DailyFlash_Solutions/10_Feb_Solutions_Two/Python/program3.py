
print("Enter Number : ")
while(True):
	n = int(input())
	if(n < 0):
		exit(0)
	print(n)

