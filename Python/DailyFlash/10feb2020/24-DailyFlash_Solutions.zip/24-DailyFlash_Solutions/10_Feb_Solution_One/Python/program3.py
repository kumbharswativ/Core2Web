
while 1:

    num = input()

    if num<0:
        print("invalid")
        break

