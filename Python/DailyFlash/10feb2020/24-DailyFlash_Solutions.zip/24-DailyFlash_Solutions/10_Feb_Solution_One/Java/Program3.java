import java.io.*;

class Program3{
	

	public static void main(String args[])throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int num;
		System.out.printf("Enter the number\n");
		while(true){

			num = Integer.parseInt(br.readLine());

			if(num<0)
				break;


		}
	}

}	
