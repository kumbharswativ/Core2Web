#include<iostream>


int main(){

	int num;
	printf("Enter the number\n");
	while(1){
		
		scanf("%d",&num);

		if(num<0)
			break;
		
		
	}		
}	
