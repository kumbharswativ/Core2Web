num = int(input())
i = 0
while(num != 0):
    num = int(num / 10)
    i += 1

print("no of digits : ", i)
