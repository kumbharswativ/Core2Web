while(True):
    n = int(input())
    if(n < 0):
        break
    print("U entered : ", n)
