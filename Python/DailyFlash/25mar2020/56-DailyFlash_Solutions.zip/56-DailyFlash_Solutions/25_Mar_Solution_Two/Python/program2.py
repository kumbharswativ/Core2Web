print(len(input("Enter any String : ")))

