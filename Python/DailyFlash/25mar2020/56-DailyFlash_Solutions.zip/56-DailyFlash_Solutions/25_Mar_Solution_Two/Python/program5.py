
print("Enter area and base")
area = int(input())
b = int(input())
h = (2 * area) / b
print("Height : ", h)
