base  = int(input("Enter Base of Triangle : "))
area  = float(input("Enter Area of Triangle : "))
	
print("Height of triangle is ",round((2*area/base),2))
