

sr = input("Enter a String  :\t")

print("Length of String",len(sr))

