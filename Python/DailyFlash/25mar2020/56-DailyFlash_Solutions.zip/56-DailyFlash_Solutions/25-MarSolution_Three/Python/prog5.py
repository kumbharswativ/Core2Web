A = int(input())
b = int(input())

print(2 * A / b)
