#include<bits/stdc++.h>

int main() {
	char arr[10];
	std::cin.getline(arr, sizeof(arr));
	std::cout << strlen(arr);
}

