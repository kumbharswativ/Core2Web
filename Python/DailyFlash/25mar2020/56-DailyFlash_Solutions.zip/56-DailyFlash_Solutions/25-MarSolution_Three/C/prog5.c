#include<stdio.h>
#include<math.h>
int main() {
	float A, b;
	scanf("%f %f", &A, &b);
	printf("%f", 2 * A / b);
}
