
n = int(input("Enter Number : "))
while(n != 0):
	if(n%10 == 0) :
		print("Numbers is Duck")
		break
		
	n = n // 10
print("Number is not Duck Number")
