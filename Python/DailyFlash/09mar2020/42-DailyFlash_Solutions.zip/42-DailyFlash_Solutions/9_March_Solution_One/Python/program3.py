
print("Enter Number : ")
while(1):
	n = int(input())
	if(n < 0) :
		print("You entererd negative Number")
		break
	print("Square : ", n , ": ", n*n)
		
	

