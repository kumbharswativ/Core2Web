
print("Enter Number : ")
while(1):
	n = int(input())
	if(n%7 == 0) :
		print("You entererd Number divisible by 7")
		break