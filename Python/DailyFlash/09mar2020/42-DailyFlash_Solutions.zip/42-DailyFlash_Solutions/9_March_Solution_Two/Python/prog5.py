while(True):
    num = int(input())
    if(num % 7 == 0):
        exit()
    print(num)
