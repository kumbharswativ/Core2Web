arr = raw_input()
a = 0
e = 0
i1 = 0
o = 0
u = 0
for i in arr:
    if(i == 'a'):
        a+=1
    if(i == 'e'):
        e+=1
    if(i == 'i'):
        i1+=1
    if(i == 'o'):
        o+=1
    if(i == 'u'):
        u+=1
print("a : ", a, "e: ", e, "i: ", i, "o ", o, "u: ", u)
