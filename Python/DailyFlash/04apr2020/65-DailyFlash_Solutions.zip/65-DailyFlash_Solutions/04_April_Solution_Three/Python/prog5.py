import math
F = float(input("F: "))
print("T: ", 1 / F)
