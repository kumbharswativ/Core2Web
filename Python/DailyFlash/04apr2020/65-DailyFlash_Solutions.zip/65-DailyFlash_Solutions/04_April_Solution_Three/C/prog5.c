#include<stdio.h>
#include<math.h>



int main() {
	float F;
	printf("F : ");
	scanf("%f", &F);
	printf("T = %f", 1 / F);
}
