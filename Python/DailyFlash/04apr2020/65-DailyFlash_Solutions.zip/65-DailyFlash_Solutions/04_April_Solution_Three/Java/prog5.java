import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		float F;
		Scanner sc = new Scanner(System.in);
		F = sc.nextFloat();
		System.out.print("T: ");
		System.out.println(1 / F);
	}
}
