#include<iostream>
#include<math.h>



int main() {
	float F;
	std::cout << "F : ";
	std::cin >> F;
	std::cout << "T = " << 1 / F;
}
