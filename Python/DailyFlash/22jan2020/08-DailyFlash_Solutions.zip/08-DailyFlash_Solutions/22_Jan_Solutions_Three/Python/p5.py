for var1 in range(4):
	for var2 in range(var1+1):
		print("*",end=" ")
	print()