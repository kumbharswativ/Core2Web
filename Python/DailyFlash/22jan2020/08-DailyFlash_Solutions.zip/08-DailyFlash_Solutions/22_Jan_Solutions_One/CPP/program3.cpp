#include <iostream>

int main () {

	int a,  b;
	std::cout << ("Enter Numbers : \n");
	std::cin >> a >> b;
	
	std::cout << ("Addition : ") << a * a * a + b * b * b  << "\nSubtraction : " << 
	a * a - b * b << std::endl;
}
