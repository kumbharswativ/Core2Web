
import math
len = float(input("Enter length in metre  : "))

print("period in seconds : ", round((2*3.142)/(math.sqrt(len/9.81)), 3))