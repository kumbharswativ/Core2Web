arr = raw_input()
words = 0
for i in arr:
    if(i == ' '):
        words += 1;
print(words + 1)
