import math
l = int(input("Length: "))
print((2 * 3.14) / math.sqrt(l / 9.81))
