#include<iostream>
#include<math.h>
int main() {
	float l;
	std::cout << "Len: ";
	std::cin >> l;
	std::cout << (2 * 3.14) / sqrt(l/9.81);
}
