
length=float(input("Enter the lenght :"))

t=(2*3.14)/((length/9.81)**0.5)

print("Time is :",round(t,2))

