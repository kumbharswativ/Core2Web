st = input("enter the string : ")

mx=0

for ch in st:
    if ch==' ':
        mx+=1

print("No of words :",(mx+1))


