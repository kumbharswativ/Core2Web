

num = input("Enter the number : ")


for itr in range(num,0,-1):
    if itr%2==0:
        print(itr)


        
