k = 0
print("Starting element :");
a = int(input())
print("Number of element :");
n = int(input())
print("Common difference :")
d = int(input())

print("The AP is : ")
while(k < n) :
	print(a + k * d, end = " ")
	k+=1
print()
