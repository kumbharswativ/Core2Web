#include<stdio.h>

int main(void) {
	double r;
	printf("Enter radius : ");
	scanf("%lf", &r);
	printf("Circum : %lf", 2 * 3.14 * r);
	return 0;
}
