#include<iostream>

int main() {
	double r;
	std::cout << "Enter radius : ";
	std::cin >> r;
	std::cout << "Circum : " << 2 * 3.14 * r;
	return 0;
}
