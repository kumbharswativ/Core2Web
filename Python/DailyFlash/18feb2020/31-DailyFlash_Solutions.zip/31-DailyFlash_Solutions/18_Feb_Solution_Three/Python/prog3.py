r = int(input("Enter radius : "))
print("Circum : ", 2 * 3.14 * r)
