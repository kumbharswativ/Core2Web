#include<iostream>


int main(){
	
	int rad;

	printf("Enter the number : ");
	scanf("%d",&rad);

	printf("%f",2*3.14*rad);

}	
