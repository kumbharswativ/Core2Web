

rad = input("Enter the radius : ")

print(2*3.14*rad)
