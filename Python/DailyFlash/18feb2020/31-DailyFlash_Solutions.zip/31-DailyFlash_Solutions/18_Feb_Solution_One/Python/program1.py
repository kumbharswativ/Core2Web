
start = input("Enter the first element : ")

number = input("Enter the number of element : ")

diff = input("Enter the diff : ")

temp = start

for itr in range(1,number+1):
    print(temp)
    temp = temp + diff

