import java.io.*;


class Program3{

	
	public static void main(String args[])throws IOException{
		
		BufferedReader br  =new BufferedReader(new InputStreamReader(System.in));
		 int num = Integer.parseInt(br.readLine()); 
		
		 System.out.printf("%f",2*3.14*num);
	}	
}	
