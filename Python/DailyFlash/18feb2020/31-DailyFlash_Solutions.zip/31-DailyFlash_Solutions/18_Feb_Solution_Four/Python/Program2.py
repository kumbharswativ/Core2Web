'''
Problem Statement


	Program2 -- Write a Program to find circumference of a Circle of radius entered by user.
        {Note: The formula to determine Circumference of Circle is 2πr. Where π = 3.142}
'''

radius=int(input("Enter the Radius of the Circle\n:"))

print("The Circumference of the Circle is ",round(radius*3.142*2,2))

