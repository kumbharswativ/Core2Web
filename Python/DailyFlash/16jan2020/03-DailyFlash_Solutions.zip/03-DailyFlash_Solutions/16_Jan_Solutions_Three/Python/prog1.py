n1, n2, n3 = [int(i) for i in input("Input : ").split()]
print("Satisfies pythagoras therom") if n1>0 and n2>0 and n3>0 and n1*n1+n2*n2==n3*n3 else print("Does not satisfies pythagoras therom")

