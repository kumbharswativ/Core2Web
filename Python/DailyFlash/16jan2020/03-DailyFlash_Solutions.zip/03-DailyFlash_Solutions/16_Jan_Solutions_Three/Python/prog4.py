n = 1
for i in range(4):
    for j in range(4):
        print(n, "\t\t", end="")
        n+=1
    print()
