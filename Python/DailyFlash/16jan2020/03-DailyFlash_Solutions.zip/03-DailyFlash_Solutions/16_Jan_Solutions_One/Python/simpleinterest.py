"""
/*
Program 2: Write a Program to calculate Simple Interest. Taking all essential
terms to compute as input.
*/

"""

principal_amount = input("Enter the principal amount : ")
rate = input("Enter the rate of interest : ")
timeperiod = input("Enter the timeperiod (Years) : ")

print((principal_amount*rate*timeperiod)/100)

