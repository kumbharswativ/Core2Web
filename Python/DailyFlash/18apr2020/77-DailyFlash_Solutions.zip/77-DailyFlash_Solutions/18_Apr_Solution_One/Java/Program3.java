import java.util.*;

class Pattern{


	public static void main(String ... args){

		int row = 0;
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number of Rows");
		row = sc.nextInt();

		int m = row/2;

	for(int olc = 0; olc < row; olc++){

		for(int ilc=0; ilc < row; ilc++){

			if(olc < m){
				if( ((ilc - olc > 0) && (ilc < m)) || ((olc+ilc < row-1) && (ilc >= m)) ) {

					System.out.printf(" \t");
				}
				else
					System.out.printf("*\t");
			}
			else if( (olc+ilc >= row && ilc < m) || (ilc-olc < 0) && ilc >= m){

				System.out.printf(" \t");
			}
			else
				System.out.printf("*\t");
		}
		System.out.printf("\n");
	}
	}
}
