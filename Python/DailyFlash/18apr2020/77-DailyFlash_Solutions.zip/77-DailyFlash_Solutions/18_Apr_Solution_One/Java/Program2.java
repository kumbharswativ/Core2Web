import java.io.*;

class Program1 {


	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.printf("Enter A String 1\n");
		String str1 = new String(br.readLine());

		System.out.printf("Enter A String 2\n");
		String str2 = new String(br.readLine());

		char inp[] = new char[str1.length()];
		char ip1[] = new char[str2.length()];

		for(int i = 0; i < str1.length(); i++){

		for(int j = 0; j < str2.length(); j++){

			if(inp[i] == ip1[j]){

				int k;
				for(k = j; k < str2.length() - j - 1; k++)
					ip1[k] = ip1[k+1];
				//ip1[k-1] = '\0';
			}
		}
	}
		String s = new String(ip1);
		System.out.println("Second String is "+s);
	}
}
