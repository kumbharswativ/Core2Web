import java.io.*;

class Program1 {


	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.printf("Enter A String 1\n");
		String str1 = new String(br.readLine());

		int cnt = 1;

		for(int i = 0; i < str1.length(); i++){

			if(str1.charAt(i) == ' ')
				cnt++;
		}
		System.out.println("Number of Words in the String is "+cnt);
	}
}
