st1 = input("Enter a String 1\t :")

cnt = 1

for i in st1 :

	if i is ' ' :
		cnt+=1
print(cnt)
