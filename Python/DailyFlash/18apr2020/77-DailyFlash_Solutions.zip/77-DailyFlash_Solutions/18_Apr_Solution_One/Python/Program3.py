row = int(input("Rows\t : "))

m = row//2

for olc in range(row) :

    for ilc in range(row) :

        if olc < m :
            if( ((ilc - olc > 0) and (ilc < m)) or ((olc+ilc < row-1) and (ilc >= m)) )  :

                print(" ",end="\t")

            else :
                print("*",end="\t");

        elif( (olc+ilc >= row and ilc < m) or (ilc-olc < 0) and ilc >= m) :

            print(" ",end="\t");

        else :
            print("*",end="\t");


    print()


