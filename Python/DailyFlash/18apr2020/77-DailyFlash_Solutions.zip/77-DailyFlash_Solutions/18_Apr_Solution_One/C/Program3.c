#include<stdio.h>

void main(){

	int row;
	printf("Enter the rows : ");
	scanf("%d",&row);

	int m = row/2;

	for(int olc = 0; olc < row; olc++){

		for(int ilc=0; ilc < row; ilc++){

			if(olc < m){
				if( ((ilc - olc > 0) && (ilc < m)) || ((olc+ilc < row-1) && (ilc >= m)) ) {

					printf(" \t");
				}
				else
					printf("*\t");
			}
			else if( (olc+ilc >= row && ilc < m) || (ilc-olc < 0) && ilc >= m){

				printf(" \t");
			}
			else
				printf("*\t");
		}
		printf("\n");
	}
}


