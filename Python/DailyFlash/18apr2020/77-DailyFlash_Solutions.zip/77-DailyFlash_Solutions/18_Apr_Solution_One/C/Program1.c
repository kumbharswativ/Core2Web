#include <stdio.h>

int main() {

	char inp[100] = {'\0'};

	printf("Input a string 1\n");
	fgets(inp,sizeof(inp),stdin);

	int cnt = 0;
	char *tmp = inp;

	while(*tmp != '\0'){

		if(*tmp == ' ' || *tmp == '\n')
			cnt++;
		tmp++;
	}

	printf("Number of Words in %s is %d\n",inp,cnt);
	return 0;
}
