#include <stdio.h>

int main() {

	char inp[100] = {'\0'};
	char ip1[100] = {'\0'};

	printf("Input a string 1\n");
	fgets(inp,sizeof(inp),stdin);

	printf("Input a string 1\n");
	fgets(ip1,sizeof(ip1),stdin);

	for(int i = 0; inp[i] != '\0'; i++){

		for(int j = 0; ip1[j] != '\0'; j++){

			if(inp[i] == ip1[j]){

				int k;
				for(k = j; ip1[k] != '\0'; k++)
					ip1[k] = ip1[k+1];
				ip1[k-1] = '\0';
			}
		}
	}
	printf("Second String %s\n",ip1);
	return 0;
}
