class Demo {
public static void main(String[] args) {

	for(int i = 0; i< 10; i++) {
		for(int j = 0; j < 10; j++) {
			if(i < 5 && j > i && j <= 8 - i) {
				System.out.print(" ");
			} else if(j >= 10 - i && j < i){
				System.out.print(" ");
			} else {
				System.out.print("*");
			}
		}
		System.out.print("\n");
	}
}
}
