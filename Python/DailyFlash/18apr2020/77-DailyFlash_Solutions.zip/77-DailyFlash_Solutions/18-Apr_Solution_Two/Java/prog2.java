import java.util.*;

class Demo {
	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		String str1 = sc.next();
		int w=0;
		for(int i =0; i < str1.length(); i++) {
			if(str1.charAt(i) ==  ' ')
				w++;
		}
		System.out.println((w+1));

	}
}
