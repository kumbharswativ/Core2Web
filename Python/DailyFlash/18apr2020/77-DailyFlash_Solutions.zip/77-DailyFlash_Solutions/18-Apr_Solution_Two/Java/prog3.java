import java.util.*;

class Demo {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String str1 = sc.next();
		String str2 = sc.next();		
		for(int i = 0; i < str2.length(); i++) {
			char ch = str2.charAt(i);
			for(int j = 0; j < str1.length(); j++) {
				if(str1.charAt(i) == ch) {
					str1 = str1.replace(Character.toString(ch), "");
				}
			}
		}
		System.out.print(str1);

	}
}
