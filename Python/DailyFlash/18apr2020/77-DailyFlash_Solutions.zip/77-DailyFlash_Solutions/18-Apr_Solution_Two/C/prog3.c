#include<stdio.h>
#include<string.h>


int main() {
	char str1[40] = {'\0'};
	char str2[20] = {'\0'};
	printf("Enter string1: ");
	fgets(str1, 40, stdin);
	if(str1[strlen(str1) - 1] == '\n')
		str1[strlen(str1)-1] = '\0';
	printf("Enter string2: ");
	fgets(str2, 20, stdin);
	if(str1[strlen(str2) - 1] == '\n')
		str1[strlen(str2)-1] = '\0';
	int len = strlen(str1);
	for(int i = 0; i < strlen(str2); i++) {
		int ch = str2[i];
		for(int j = 0; j < len;j++) {
		
			if(ch == str1[j]) {

				str1[j] = '\0';
			}	
		}
	}

	for(int i = 0; i<40; i++) {
		if(str1[i] != '\0')
		printf("%c", str1[i]);
	}
}
