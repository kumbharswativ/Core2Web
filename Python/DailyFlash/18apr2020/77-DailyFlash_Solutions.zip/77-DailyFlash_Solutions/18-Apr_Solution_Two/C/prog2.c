#include<stdio.h>
#include<string.h>
int main() {
	char str1[40];
	printf("Enter string1: ");
	fgets(str1, 40, stdin);
	if(str1[strlen(str1) - 1] == '\n')
		str1[strlen(str1)-1] = '\0';
	int len = strlen(str1);
	int cnt =0;
	for(int i = 0; i < len; i++) {
		if(str1[i] == ' ') {
			cnt++;
		}
	}
	printf("words: %d", cnt+1);
	
	
}
