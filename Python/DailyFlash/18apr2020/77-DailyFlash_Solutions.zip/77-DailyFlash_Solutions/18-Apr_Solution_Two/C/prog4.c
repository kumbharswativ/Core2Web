#include<stdio.h>

int main() {

	for(int i = 0; i< 10; i++) {
		for(int j = 0; j < 10; j++) {
			if(i < 5 && j > i && j <= 8 - i) {
				printf(" ");
			} else if(j >= 10 - i && j < i){
				printf(" ");
			} else {
				printf("*");
			}
		}
		printf("\n");
	}
}
