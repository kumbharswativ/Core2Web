#include<iostream>

int main() {

	for(int i = 0; i< 10; i++) {
		for(int j = 0; j < 10; j++) {
			if(i < 5 && j > i && j <= 8 - i) {
				std::cout << " ";
			} else if(j >= 10 - i && j < i){
				std::cout << " ";
			} else {
				std::cout << "*";
			}
		}
		std::cout << "\n";
	}
}
