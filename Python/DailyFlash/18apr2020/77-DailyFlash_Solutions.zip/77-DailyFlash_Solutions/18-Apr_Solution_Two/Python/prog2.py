str1 = input()
w=0
for i in str1:
    if(i == ' '):
        w+=1
print(w+1)
