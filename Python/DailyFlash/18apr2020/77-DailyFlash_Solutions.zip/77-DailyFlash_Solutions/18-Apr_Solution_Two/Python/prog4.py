for i in range(10):
    for j in range(10):
        if(i<5 and j > i and j <= 8-i):
            print(" ", end="")
        elif(j>=10-i and j < i):
            print(" ", end="")
        else:
            print("*", end = "")
    print()
