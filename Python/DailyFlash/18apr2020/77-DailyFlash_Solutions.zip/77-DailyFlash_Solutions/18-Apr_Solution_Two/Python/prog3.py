str1 = input()

str2 = input()

flag = 0
for i in str2:
    for j in str1:
        if(i == j):
            str1=str1.replace(""+i, "")

print(str1)
