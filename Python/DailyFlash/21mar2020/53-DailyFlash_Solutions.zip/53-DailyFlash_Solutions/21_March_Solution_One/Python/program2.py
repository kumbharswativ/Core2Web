
ch = raw_input("Enter the String : ")


for itr in range(len(ch)):

    if ch[itr]=='A' or ch[itr]=='a':
        print(ch[itr])
    elif ch[itr]=='E' or ch[itr]=='e':
        print(ch[itr])
    elif ch[itr]=='i' or ch[itr]=='I':
        print(ch[itr])
    elif ch[itr]=='o' or ch[itr]=='O':
        print(ch[itr])
    elif ch[itr]=='u' or ch[itr]=='U':
        print(ch[itr])
