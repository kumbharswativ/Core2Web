
#include <stdio.h>

void main() {
	char c;
	printf("Character : ");
	printf("ASCII : %d\n", getc(stdin));
	return;
}
