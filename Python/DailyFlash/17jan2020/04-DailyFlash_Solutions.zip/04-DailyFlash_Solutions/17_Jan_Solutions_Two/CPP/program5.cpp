
#include <iostream>

int main() {
	int c;
	std::cout << ("Character : ");
	c = getc(stdin);
	std::cout << ("ASCII : " ) <<  c << std::endl;
	return 0;
}
