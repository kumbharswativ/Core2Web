
/*
Program 5: Write a program to ASCII values of input character.
Input: A
Output: ASCII Value of A is 65

*/

#include<iostream>

int main(){

	char input;
	
	printf("Enter the character\n");
	scanf("%c",&input);

	printf("Ascii value of %c is %d",input,input);

}	
