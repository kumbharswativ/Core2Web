"""
Program 5: Write a program to ASCII values of input character.
Input: A
Output: ASCII Value of A is 65

"""


ch = input("Enter the charcter ")

print("Ascii value of "+str(ord(ch)));
