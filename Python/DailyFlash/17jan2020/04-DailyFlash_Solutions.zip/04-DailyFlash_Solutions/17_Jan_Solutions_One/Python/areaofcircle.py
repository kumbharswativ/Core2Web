"""Program 1: Write a Program to calculate area of circle."""

radius = input("Enter the radius of the circle : ")

print(3.14*radius*radius)
