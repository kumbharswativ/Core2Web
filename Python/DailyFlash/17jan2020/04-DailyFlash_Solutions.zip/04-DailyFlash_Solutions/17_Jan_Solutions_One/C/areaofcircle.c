/*Program 1: Write a Program to calculate area of circle.*/


#include<stdio.h>


void main(){
	int radius;
	printf("Enter the radius of the circle\n");
	scanf("%d",&radius);

	printf("Area of circle is %f",3.14*radius*radius);

}	
