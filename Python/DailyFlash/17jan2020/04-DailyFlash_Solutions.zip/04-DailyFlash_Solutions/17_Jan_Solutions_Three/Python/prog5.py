ch = input("Char : ")
print("ASCII : ", ord(ch))
