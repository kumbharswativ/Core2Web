r = float(input("Radius : "))
print("Area : ", 3.14 * r * r) if r >= 0 else print("Enter valid input.")
