for i in range(4):
    for j in range(4):
        print(2 * (j + 1), "\t", end="")
    print()
