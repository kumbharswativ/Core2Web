#include<stdio.h>

int main() {
	char ch;
	printf("Char : ");
	scanf("%c", &ch);
	printf("ASCII : %d", ch);
	return 0;
}
