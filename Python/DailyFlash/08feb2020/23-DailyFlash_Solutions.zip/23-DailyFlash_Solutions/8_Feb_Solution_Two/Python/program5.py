
print("Enter Numbers : ")

p = list()
for i in range(0,5):
	p.append(int(input()))
p.reverse()
print(p)



