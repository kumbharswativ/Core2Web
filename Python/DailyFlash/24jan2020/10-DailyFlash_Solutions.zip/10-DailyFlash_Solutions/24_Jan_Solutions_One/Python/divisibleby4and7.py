

for itr in range(1,101):

    if itr%4==0 and itr%7==0:
        print(itr)
