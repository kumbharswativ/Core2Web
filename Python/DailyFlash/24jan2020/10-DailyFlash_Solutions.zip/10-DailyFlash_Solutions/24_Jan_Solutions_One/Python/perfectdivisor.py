

num = input("Enter the number ")

for itr in range(2,(num/2)+1):

    if num%itr==0:
        print(itr)
