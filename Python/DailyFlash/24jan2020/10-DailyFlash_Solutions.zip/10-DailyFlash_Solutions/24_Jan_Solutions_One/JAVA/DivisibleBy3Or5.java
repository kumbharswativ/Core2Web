

class DivisibleBy3or5{


	public static void main(String args[]){

		for(int itr = 1 ; itr <=100 ; itr++){
		
			if(itr%3 == 0  || itr%5 ==0)
				System.out.printf("%d ",itr);
		}	
	}	
}	
