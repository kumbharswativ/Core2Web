
class Process0 {
	
	public static void main(String[] args) {
		
		for(int i = 3; i <= 100; i++) {
			if(i % 4 == 0 && i % 7 == 0)
				System.out.printf("%d ", i);
		
		}
		System.out.printf("\n");
	}
}
