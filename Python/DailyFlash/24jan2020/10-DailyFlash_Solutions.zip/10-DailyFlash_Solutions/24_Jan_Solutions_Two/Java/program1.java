
class Process0 {
	
	public static void main(String[] args) {
		
		for(int i = 3; i <= 100; i++) {
			if(i % 3 == 0 || i % 5 == 0)
				System.out.printf("%d ", i);
		
		}
		System.out.printf("\n");
	}
}
