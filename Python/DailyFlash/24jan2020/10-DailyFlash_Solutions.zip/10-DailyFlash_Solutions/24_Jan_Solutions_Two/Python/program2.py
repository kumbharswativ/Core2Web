'''Run using python3'''

for i in range(3,101) :
	if(i % 4 == 0 and i % 7 == 0):
		print(i, end = ' ')

print()