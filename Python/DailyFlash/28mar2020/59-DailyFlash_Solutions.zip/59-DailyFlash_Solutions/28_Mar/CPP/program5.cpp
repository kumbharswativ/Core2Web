
#include <iostream>

int isPrime(int n) {

	for(int i = 2; i <= n/2; i++){
		if(n % i == 0)
			return 0;
	}
	return 1;
}

int main () {
	
	int n;
	std::cout << ("Enter Number : ");
	std::cin >> n;

	int f = 1, temp = n, flag = 0;
	while(temp != 0){
		f = f * 10;
		temp /= 10;
	}
	f /= 10;
	temp = n;
	while(temp != n || flag == 0){
		temp = (temp % f)*10 + (temp/f);
		if(!isPrime(temp)){
			flag = 3;
			break;
		}
		std::cout << (temp) << std::endl;
		flag = 1;
	}
	if(temp == n && flag != 3){
		std::cout << ("Number is circular\n");
	}
	else{
		std::cout << ("Number is not circular\n");
	}
}
