
#include <stdio.h>

int isPrime(int n) {

	for(int i = 2; i <= n/2; i++){
		if(n % i == 0)
			return 0;
	}
	return 1;
}

void main () {
	
	int n;
	printf("Enter Number : ");
	scanf("%d", &n);

	int f = 1, temp = n, flag = 0;
	while(temp != 0){
		f = f * 10;
		temp /= 10;
	}
	f /= 10;
	temp = n;
	while(temp != n || flag == 0){
		temp = (temp % f)*10 + (temp/f);
		if(!isPrime(temp)){
			break;
		}
		printf("%d\n",temp);
		flag = 1;
	}
	if(temp == n){
		printf("Number is circular\n");
	}
	else{
		printf("Number is not circular\n");
	}
}
