
#include <stdio.h>

def isPrime(n:int) -> bool :

	for i in range(2, n//2 + 1):
		if(n % i == 0):
			return False
	
	return True

print("Enter Number : ")
n = int(input())	
f = 1
temp = n
flag = 0
while(temp != 0):
	f = f * 10
	temp //= 10
	
f //= 10
temp = n
while(temp != n or flag == 0):
	temp = (temp % f)*10 + (temp//f)
	if(isPrime(temp) == False):
		break
		
	print(temp)
	flag = 1
	
if(temp == n):
	print("Number is circular")
	
else:
	print("Number is not circular")
	

