import java.io.*;
class Program {
	public static void main(String[] args) throws IOException{
	
		int n;
		System.out.printf("Enter Number : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		Program program = new Program();
		int f = 1, temp = n, flag = 0;
		while(temp != 0){
			f = f * 10;
			temp /= 10;
		}
		f /= 10;
		temp = n;
		while(temp != n || flag == 0){
			temp = (temp % f)*10 + (temp/f);
			if(!program.isPrime(temp)){
				break;
			}
			System.out.printf("%d\n",temp);
			flag = 1;
		}
		if(temp == n){
			System.out.printf("Number is circular\n");
		}
		else{
			System.out.printf("Number is not circular\n");
		}
	}

	boolean isPrime(int n) {

		for(int i = 2; i <= n/2; i++){
			if(n % i == 0)
				return false;
		}
		return true;
	}
}