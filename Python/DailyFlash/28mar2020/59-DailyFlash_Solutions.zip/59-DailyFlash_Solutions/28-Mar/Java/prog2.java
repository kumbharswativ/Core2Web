import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int l, sum, mul = 1;
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		StringBuilder sb = new StringBuilder();
		char max = str.charAt(0);
		for(int i = 0; i < str.length(); i++) {
			if(max < str.charAt(i))
				max = str.charAt(i);
		}

		for(int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if(ch == 'a' ||ch == 'e' ||ch == 'i' ||ch == 'o' ||ch == 'u')
				sb.append(max);
			else
				sb.append(str.charAt(i));
		}
		System.out.println(sb);
	}
}
