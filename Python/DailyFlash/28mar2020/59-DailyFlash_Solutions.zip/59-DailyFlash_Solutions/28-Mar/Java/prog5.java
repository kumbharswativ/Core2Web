import java.util.Scanner;

class Demo {

	static boolean isPrime(int num) {
		for(int i = 2; i <= Math.sqrt(num); i++) {
			if(num % i == 0) 
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		int num;
		System.out.println("Enter num: ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		int temp = num;
		int n = 0;
		while(temp!=0) {
			n++;
			temp/=10;
		}
		temp = num;
		int cp = 0;
		int rem;
		while(temp!=0) {
			rem = temp%10;
			int temp1 = num/10;
			num = rem *(int) Math.pow(10, n - 1) + temp1;
			if(isPrime(num)) {
				cp++;
			}
			temp = temp/10;
		}
		if(cp == n)
			System.out.println("Circular prime.");
	}
}
