class Demo {
	public static void main(String[] args) {
		int num = 1;
		for(int i = 0; i < 15; i++) {
			if(i < 8) {
				for(int j = 0; j < i + 1; j++) {
					if(j == 0)
						System.out.print("C");
					if(j == 1)
						System.out.print("O");
					if(j == 2)
						System.out.print("R");
					if(j == 3)
						System.out.print("E");
					if(j == 4)
						System.out.print("2");
					if(j == 5)
						System.out.print("W");
					if(j == 6)
						System.out.print("E");
					if(j == 7)
						System.out.print("B");
				}
			} else {
				for(int j = 0; j < 15 - i; j++) {
					
					if(j == 0)
						System.out.print("C");
					if(j == 1)
						System.out.print("O");
					if(j == 2)
						System.out.print("R");
					if(j == 3)
						System.out.print("E");
					if(j == 4)
						System.out.print("2");
					if(j == 5)
						System.out.print("W");
					if(j == 6)
						System.out.print("E");
					if(j == 7)
						System.out.print("B");
                                

				}
			}
			System.out.println();
		}
	}
}
