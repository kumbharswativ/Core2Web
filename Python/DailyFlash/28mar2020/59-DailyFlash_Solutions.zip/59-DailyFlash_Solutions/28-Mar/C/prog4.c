#include<stdio.h>

int main() {
	
	for(int i = 0; i < 15; i++) {

		if(i < 8) { 
			for(int j = 0; j < i + 1; j++) {
				if(j==0)
					printf("C");
				if(j == 1)
					printf("O");
				if(j == 2 )
					printf("R");
				if(j == 3)
					printf("E");
				if(j == 4)
					printf("2");
				if(j == 5)
					printf("W");
				if(j == 6)
					printf("E");
				if(j == 7)
					printf("B");
			}
		} else {
			for(int j = 0; j < 15 - i; j++) {
				
				if(j==0)
					printf("C");
				if(j == 1)
					printf("O");
				if(j == 2 )
					printf("R");
				if(j == 3)
					printf("E");
				if(j == 4)
					printf("2");
				if(j == 5)
					printf("W");
				if(j == 6)
					printf("E");
				if(j == 7)
					printf("B");

			}
		}
		printf("\n");
	}
}
