#include<stdio.h>
#include<math.h>

int isPrime(int num) {
	for(int i = 2; i <= sqrt(num); i++) {
		if(num % i == 0) 
			return 0;
	}
	return 1;
}

int main(void) {
	int num;
	printf("Enter num: ");
	scanf("%d", &num);
	int temp = num;
	int n = 0;
	while(temp!=0) {
		n++;
		temp/=10;
	}
	temp = num;
	int cp = 0;
	int rem;
	while(temp!=0) {
		rem = temp%10;
		int temp1 = num/10;
		num = rem * pow(10, n - 1) + temp1;
		if(isPrime(num)) {
			cp++;
		}
		temp = temp/10;
	}
	if(cp == n)
		printf("Circular prime.");
}
