#include<iostream>

int main() {
	
	for(int i = 0; i < 15; i++) {
		if(i < 8) {
			for(int j = 0; j < i + 1; j++) {
				
				if(j == 0)
					std::cout << "C";
				if(j == 1)
					std::cout << "O";
				if(j == 2)
					std::cout << "R";
				if(j == 3)
					std::cout << "E";
				if(j == 4)
					std::cout << "2";
				if(j == 5)
					std::cout << "W";
				if(j == 6)
					std::cout << "E";
				if(j == 7)
					std::cout << "B";
			} 
		} else {
			for(int j = 0; j < 15 - i; j++) {
				if(j == 0)
					std::cout << "C";
				if(j == 1)
					std::cout << "O";
				if(j == 2)
					std::cout << "R";
				if(j == 3)
					std::cout << "E";
				if(j == 4)
					std::cout << "2";
				if(j == 5)
					std::cout << "W";
				if(j == 6)
					std::cout << "E";
				if(j == 7)
					std::cout << "B";

			}
		}
		std::cout << "\n";
	}
}
