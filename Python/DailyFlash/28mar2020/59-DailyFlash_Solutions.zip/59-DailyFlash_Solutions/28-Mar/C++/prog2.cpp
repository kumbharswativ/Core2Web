#include<bits/stdc++.h>

int main() {
	char arr[10];
	char max;
	std::cin.getline(arr, sizeof(arr));
	max = arr[0];
	for(int i = 0; i < strlen(arr); i++) {
		if(max<arr[i])
			max = arr[i];
	}
	for(int i = 0; i < strlen(arr); i++) {
		if(arr[i] == 'a' ||arr[i] == 'e' ||arr[i] == 'i' ||arr[i] == 'o' ||arr[i] == 'u')
			arr[i]=max;
		std::cout<<arr[i];
	}
}

