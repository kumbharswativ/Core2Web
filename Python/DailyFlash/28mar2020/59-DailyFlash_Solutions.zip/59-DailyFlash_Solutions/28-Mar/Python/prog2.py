arr = raw_input()
m = arr[0]
for i in arr:
    if(m < i):
        m = i
for i in arr:
    if(i == 'a' or i == 'o' or i == 'i' or i == 'e' or i == 'u'):
        i = m
    print(i)
