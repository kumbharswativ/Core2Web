num = 1
for i in range(15):
    if(i < 8):
        for j in range(i + 1):
            if(j == 0):
                print("C", end = "")
            if(j == 1):
                print("O", end = "")
            if(j == 2):
                print("R", end = "")
            if(j == 3):
                print("E", end = "")
            if(j == 4):
                print("2", end = "")
            if(j == 5):
                print("W", end = "")
            if(j == 6):
                print("E", end = "")
            if(j == 7):
                print("B", end = "")
    else:
        for j in range(15 - i):
        
            if(j == 0):
                print("C", end = "")
            if(j == 1):
                print("O", end = "")
            if(j == 2):
                print("R", end = "")
            if(j == 3):
                print("E", end = "")
            if(j == 4):
                print("2", end = "")
            if(j == 5):
                print("W", end = "")
            if(j == 6):
                print("E", end = "")
            if(j == 7):
                print("B", end = "")
    print()
