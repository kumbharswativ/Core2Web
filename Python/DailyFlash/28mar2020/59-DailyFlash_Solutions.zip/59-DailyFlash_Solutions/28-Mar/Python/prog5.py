import math
def isPrime(num):
    for i in range(2, int(math.sqrt(num))+1):
        if(num % i == 0):
            return False
    return True

num = int(input("Enter num : "))
temp = num
n = 0
while(temp != 0):
    n+=1
    temp = int(temp/10)
temp = num
cp = 0
while(temp != 0):
    rem = temp%10
    temp1 = int(num / 10)
    num = rem * pow(10, n - 1) + temp1
    if(isPrime(num)):
        cp+=1
    temp = int(temp/10)

if(cp == n):
    print("Circular prime")
