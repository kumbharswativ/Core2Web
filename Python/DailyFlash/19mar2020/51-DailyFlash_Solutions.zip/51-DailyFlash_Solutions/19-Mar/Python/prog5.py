num = int(input())
s = 0
for i in range(num):
    num = int(input())
    s += num
print(s / num)
