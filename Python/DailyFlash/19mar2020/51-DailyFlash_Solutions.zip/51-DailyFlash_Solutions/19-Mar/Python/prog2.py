s = raw_input()
print(s)
