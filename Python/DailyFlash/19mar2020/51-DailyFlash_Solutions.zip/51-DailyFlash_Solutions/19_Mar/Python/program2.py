
print(input("Enter String : "))
