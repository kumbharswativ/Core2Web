
n = int(input("Total Number : "))
l = []
sum = 0
for i in range(1,n+1):
    sum+=int(input())
print(sum / n)
