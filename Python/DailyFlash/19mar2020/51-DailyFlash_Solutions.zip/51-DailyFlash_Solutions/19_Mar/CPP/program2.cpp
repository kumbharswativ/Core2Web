
#include <iostream>

int main() {
	char st[20];

	std::cout << ("Enter Any String : ");
	fgets(st, 20, stdin);
	std::cout << (st);
}
