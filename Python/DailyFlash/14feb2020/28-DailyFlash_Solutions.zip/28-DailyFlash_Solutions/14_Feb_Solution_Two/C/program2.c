
#include<stdio.h>

void main() {

	char he[10] = {'\0'}, bin[4] = {'\0'};
	printf("Enter Hexadecimal Number : ");
	fgets(he,5,stdin);

	printf("%s\n",he);
	int i = 0, n, k;
	while (he[i] != '\n' && he[i] != '\0'){
		if(he[i]>= 'G'){
			printf("Not a Hexadecimal Number\n");
			exit(0);
		}
		n = (he[i] <= '9')?(he[i] - '0') : (he[i] - 55);
		k = 3;
		while (k>=0){
			bin[k] = (char)(n%2 + 48);
			n = n / 2;
			k--;
		}
		k = 0;
		while (k<=3){
			printf("%c", bin[k]);
			k++;
		}
		i++;
	}
	printf("\n");
}