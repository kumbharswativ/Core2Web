
#include <stdio.h>

void exit(int);

void main () {

	int cnt1 = 0, n;
	printf("Enter Number : ");
	scanf("%d", &n);

	if(n<0)
		return;
	while(n != 0){
		if(n%10 == 1){
			cnt1++;
		}
		n = n / 10;
	}	
	printf("Occurrence of one: %d\n", cnt1);
}
