
#include <stdio.h>

void main () {
	int n,temp, sum = 0, fact;
	printf("Enter Limit: ");
	scanf("%d", &n);
	for(int j = 1; j <= n; j++){
		sum = 0;
		temp = j;
		while(temp!=0){
			fact = 1;
			for(int i = 1; i<= temp%10; i++){

				fact = fact * i;
			}
			sum = sum + fact;
			temp = temp / 10;
		}
		if(sum == j){
			printf("%d ", j);
		}
	}
}
