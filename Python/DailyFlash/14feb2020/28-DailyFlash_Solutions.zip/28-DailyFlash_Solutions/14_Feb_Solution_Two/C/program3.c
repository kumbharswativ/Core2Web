
#include <stdio.h>

void main () {
	int n, cnt = 0;
	double avg, sum = 0;
	printf("Enter Number: ");
	scanf("%d", &n);
	while(n!=0){
		sum = sum + n % 10;
		cnt++;
		n = n / 10;
	}
	printf("Average : %f\n", sum/cnt);
}
