
#include <iostream>

int main () {
	int n,temp, sum = 0, fact;
	std::cout << ("Enter Number: ");
	std::cin >> n;
	for(int j = 1; j<= n; j++){
		temp = j;
		sum = 0;
		while(temp!=0){
			fact = 1;
			for(int i = 1; i<= temp%10; i++){

				fact = fact * i;
			}
			sum = sum + fact;
			temp = temp / 10;
		}
		if(sum == j){
			std::cout << (j) << " ";
		}
	}
}