
#include <iostream>

int main () {

	int cnt1 = 0,cnt2 = 0, n;
	std::cout << ("Enter Number : ");
	std::cin >> n;

	if(n<0)
		return 0;
	while(n != 0){
		if(n%10 == 1){
			cnt1++;
		}
		n = n / 10;
	}	
	std::cout << ("Occurrence: ") << (cnt1) << "\n";
}
