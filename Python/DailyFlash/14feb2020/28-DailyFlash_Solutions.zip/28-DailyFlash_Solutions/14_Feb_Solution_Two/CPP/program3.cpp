
#include <iostream>

int main () {
	int n, cnt = 0;
	double sum = 0;
	std::cout << ("Enter Number: ");
	std::cin >> n;
	while(n!=0){
		sum = sum + n % 10;
		n = n / 10;
		cnt++;
	}
	std::cout << ("Average : ") << (sum/cnt) << "\n";
}
