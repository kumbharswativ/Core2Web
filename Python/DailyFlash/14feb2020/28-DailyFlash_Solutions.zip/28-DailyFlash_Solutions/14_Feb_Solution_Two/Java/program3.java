
import java.io.*;

class Program {
	public static void main (String ... kbd) throws IOException{
		int n, cnt = 0;
		double sum = 0;
		System.out.printf("Enter Number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		while(n!=0){
			sum = sum + n % 10;
			cnt++;
			n = n / 10;
		}
		System.out.println("Avg :" + (sum/cnt));
	}
}