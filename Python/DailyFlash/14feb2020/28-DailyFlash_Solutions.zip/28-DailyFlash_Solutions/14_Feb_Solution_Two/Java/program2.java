

import java.io.*;

class Program {
	public static void main(String ... kbd) throws IOException {

		char bin[] = new char[4];
		System.out.printf("Enter Hexadecimal Number : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String he = br.readLine();

		System.out.printf("%s\n",he);
		int i = 0, n, k;
		while (i < he.length()){
			if(he.charAt(i)== 'G'){
				System.out.printf("Not a Hexadecimal Number\n");
				System.exit(0);
			}
			n = (he.charAt(i) <= '9')?(he.charAt(i) - '0') : (he.charAt(i) - 55);
			k = 3;
			while (k>=0){
				bin[k] = (char)(n%2 + 48);
				n = n / 2;
				k--;
			}
			k = 0;
			while (k<=3){
				System.out.printf("%c", bin[k]);
				k++;
			}
			i++;
		}
		System.out.printf("\n");
	}
}