	
try:
	n = int(input("Enter Number : "))
except ValueError as e:
	print("Not a Number");
	exit(0)
for j in range(1,n+1):
	sum = 0
	temp = j
	while(temp!=0):
		fact = 1
		for i in range(1, (temp%10) + 1):
			fact = fact * i		
		sum = sum + fact
		temp = temp // 10
		
	if(sum == j):
		print(j,end = " ")
	

