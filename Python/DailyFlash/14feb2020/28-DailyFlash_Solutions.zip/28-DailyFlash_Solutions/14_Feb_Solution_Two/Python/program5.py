
try:
	n = int(input("Enter Number : "))
except ValueError as e:
	exit(0)
cnt1 = 0

if(n<0):
	exit(0)
while(n != 0):
	if((n%10)==1):
		cnt1 += 1
	n = n // 10
print("Occurrence : ",cnt1)
