num = int(input("Num : "))
temp = num
s = 0
for i in range(1, num + 1):
    temp = i
    s = 0
    while(temp > 0):
        rem = temp % 10;
        fact = 1
        for j in range(1, rem + 1):
            fact *= j
        s += fact
        temp = int(temp / 10)
    if(s == i):
        print(i, end = " ")
