hx = input("Enter hex : ")
l = len(hx)
h = 0
b = ""
while(l > 0):
    if(hx[h] <= '9'):
        num = ord(hx[h]) - 48
    else:
        num = ord(hx[h]) - 55
    temp = ""
    while(True):
        rem = num % 2
        num =int(num / 2)
        temp += chr(rem + 48)
        if(num == 0):
            break
    temp_len = len(temp)
    while(temp_len < 4):
        temp += '0'
        temp_len += 1
    for i in range(4):
        b += temp[3 - i]
    h += 1
    l -= 1
print("Bin : ", b)
