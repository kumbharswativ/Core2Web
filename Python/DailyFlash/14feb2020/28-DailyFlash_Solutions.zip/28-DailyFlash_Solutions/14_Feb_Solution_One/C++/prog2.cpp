#include<iostream>
#include<string.h>
int main() {
	char hex[10];
	char temp[4];
	char bin[30];
	for(int i = 0; i < sizeof(bin); i++) {
		bin[i] = '\0';
	}
	std::cout << "Enter hex : ";
	std::cin.getline(hex, sizeof(hex));
	int len = strlen(hex);
	int b = 0, k ,  num, rem, h = 0;
	while(len > 0) {
		num = hex[h] <= '9' ? hex[h] - 48 : hex[h] - 55;
		for(int j = 0; j < 4; j++) {
			temp[j] = '0';
		}
		k = 0;
		while(1) {
			rem = num % 2;
			num /= 2;
			temp[3 - k] = rem + '0';
			k++;
			if(num == 0)
				break;
		}
		for(int j = 0; j < 4; j++) {
			bin[b] = temp[j];
			b++;
		}
		len--;
		h++;
	}
	std::cout << "bin : " << bin;
	return 0;
}
