#include<iostream>

int main() {
	long num;
	int i = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	while(num != 0) {
		if((num % 10)== 1)
			i++;
		num = num / 10;
	}
	std::cout << "No of 1,s : " << i;
	return 0;
}
