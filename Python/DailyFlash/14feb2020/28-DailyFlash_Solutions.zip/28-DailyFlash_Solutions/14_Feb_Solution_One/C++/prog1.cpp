#include<iostream>

int main() {
	int num;
	std::cout << "Enter num : ";
	std::cin >> num;
	int temp, rem, sum, fact = 1;
	for(int i = 1; i <= num; i++){
		sum = 0;
		temp = i;
		while(temp > 0) {
			rem = temp % 10;
			fact = 1;
			for(int j = 1; j <= rem; j++) {
				fact = fact * j;
			}
			sum += fact;
			temp /= 10;
		}
		if(sum == i) {
			std::cout << i << " ";
		}
	}
	return 0;
}
