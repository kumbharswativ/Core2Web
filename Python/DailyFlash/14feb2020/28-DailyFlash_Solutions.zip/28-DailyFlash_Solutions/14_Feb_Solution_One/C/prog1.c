#include<stdio.h>

int main(void) {
	int num;
	printf("Enter num : ");
	scanf("%d", &num);
	int temp, rem, sum = 0, fact;
	for(int i = 1; i <= num; i++) {
		temp = i;
		sum = 0;
		while(temp > 0) {
			rem = temp % 10;
			fact = 1;
			for(int i = 1; i <= rem; i++) {
				fact = fact * i;
			}
			sum += fact;
			temp /= 10;
		}
		if(i == sum)
			printf("%d ", i);
	}

	return 0;
}
