'''

Problem Statement

Program4 -- Write a Program that takes a number as input from user and prints the counts the occurrence of '1' Ones from it
'''

num = int(input("Please Enter any Number: "))
cnt = 0

while(num > 0):

    if (num % 10) == 1 :
        cnt+=1
    num = num //10

print("Occurence of '1' Ones in the Given Number = ",cnt)
