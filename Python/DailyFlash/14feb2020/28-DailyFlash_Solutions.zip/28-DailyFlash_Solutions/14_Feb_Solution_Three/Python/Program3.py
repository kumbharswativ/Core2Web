'''
Problem Statement

Program3 -- Write a Program to Print the following pattern. 

 	 	 	#	
 	 	#	*	
	#	*	*	
#	*	*	*	
'''

rows = int(input("Enter The number of rows\n"))

for x in range(rows) :

    for y in range(rows):

        if( x+y == (rows-1)) :

            print("#\t",end="",sep='')
        elif( x+y >= (rows-1)) :

            print("*\t",end="",sep='')
        else :
            print(" \t",end="",sep='')
    print()
