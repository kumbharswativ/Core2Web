'''
Problem Statement

Program1 -- Write a Program to Convert entered Hexadecimal Number to Binary Number
'''

hexdec = input("Enter number in Hexadecimal Format: ");

decimal = int(hexdec, 16);
binary = bin(decimal)

print(hexdec,"in Binary =",str(binary));
