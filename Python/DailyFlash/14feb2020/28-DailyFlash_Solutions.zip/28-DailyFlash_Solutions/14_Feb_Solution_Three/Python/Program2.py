'''
Problem Statement

Program2 -- Write a Program to that accepts an integer value from user and prints the Average of all the digits
'''

num = int(input("Please Enter any Number: "))
Sum = 0
cnt = 0

while(num > 0):

    Sum = Sum + (num % 10)
    num = num //10
    cnt+=1

print("Average of digits of Given Number = ",round(Sum/cnt,2))
