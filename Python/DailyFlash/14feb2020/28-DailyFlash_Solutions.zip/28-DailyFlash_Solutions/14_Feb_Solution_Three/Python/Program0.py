'''
Problem Statement

Program0 -- Write a Program to print Series of Strong Numbers up to Nth Elements. Where n is the number entered by User.
'''

num=int(input("Enter Nth Element for Strong Number Series\n:"))

for check in range(1,num+1):

    temp=check
    fsum = 0

    while(temp > 0):

        fact = 1
        digit = temp%10

        for f in range(1,digit+1):
            fact = fact*f
        fsum = fsum + fact
        temp = temp//10
    
    if(fsum==check):
        print(check,end=" ")
print()
