//Import io package for all Input Output Operations
import java.io.*;

//User defined class to convert Hexadecimal Number to Binary
class Binary {

	//Entry Point Function main, throws IOException as the readLine method of BufferedReader throws Exception
	public static void main(String[] args) throws IOException {

		//To make a connection between Java code and Keyboard for Input 
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));

		/* 
		 * Declarations
		 * String Variable
		 * num_input_1 - To store User Input
		 *
		 * */

		int pow = 0,tmp,binary = 0;
		String num_input_1 = null;

		/*
		 * Test Conditions
		 * Condition1 - Number Should be greater than 0 
		 * Condition2 - Only HexaDecimal Characters are allowed
		 * 
		 * */

		//do-while loop to take user input till all conditions are true
		do {
			System.out.println("Enter Hexadecimal Number");

			//Try-catch to Handle Character input 
			try {
				num_input_1 = b.readLine();

			}
			catch(NumberFormatException n){

				System.out.println("Invalid, Enter in Proper Format");
			}

		}while(num_input_1 == null);

		
		int decimal = Integer.parseInt(num_input_1,16);	
		pow = 0;
		tmp = decimal;

		//While Loop to convert Decimal Number into Binary Number
		while(tmp > 0){

			binary = binary + ((tmp%2)*power(10,pow));
			pow++;
			tmp/=2;

		};

		System.out.println(binary);	

	}

	static int power(int number, int index){

		int answer = 1;

		//while to calculate exponention value from the 0 to the specified Index
		while(index > 0){

			answer*=number;
			index--;
		}
		return answer;
	}

}
