/* Problem Statement
 *
 * Program0 -- Write a Program to print Series of Strong Numbers up to Nth Elements. Where n is the number entered by User.
 *
 * */

//Include Header File for all input output Operations
#include <iostream>

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - int
 * Function Arguments - void
 * */

int main() {

	/*
	 * Declarations
	 * num_input_1 - Integer type variable for user input
	 * sum - To store sum of factorials
	 * fact - To store factorial of number
	 * */
	int num_input_1,sum = 0,temp = 0,fact = 1;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */
	do {
		std::cout<<"Enter Nth element for Series of Strong Numbers \n";
		/*
		 * if there is character input the cin returns 0, Hence for unsuccesfull return of cin execute
		 * */

		std::cin>>num_input_1;

		//if statement if Condition 1 is false
		if(num_input_1 <= 0){

			std::cout<<"Invalid, Only Positive values allowed"<<std::endl;
		}
		else if(std::cin.fail()){

			std::cout<<"Characters are not allowed"<<std::endl;
		}
		else 
			break;

	}while(!std::cin.fail() && num_input_1 <= 0);

	std::cout<<"The Series of Strong Numbers is "<<std::endl;
	
	//For loop to check for Strong Number upto the User input
	for(int lc = 1; lc <= num_input_1; lc++){

		//Reinitialisation of sum to 0, for each element
		temp = lc;
		sum = 0;

		//While loop to separate each digit of the number
		while(temp > 0){

			/*
			 * Reinitialisation of fact to 1, for each iteration of while-loop
			 * int digit - to store the separated digit for further calculations
			 * */
			fact = 1;
			int digit = (temp%10);

			//For loop to calculate factorial of Each digit
			for(int lc = 1; lc <= digit; lc++){

				fact*=lc;
			}

			//Add factorial of each digit to the sum
			sum+=fact;
			temp/=10;
		}

		//If-else to check for Strong Number
		if(sum == lc)

			std::cout<<lc<<"\t";
	}
	std::cout<<std::endl;

	return 0;
}
