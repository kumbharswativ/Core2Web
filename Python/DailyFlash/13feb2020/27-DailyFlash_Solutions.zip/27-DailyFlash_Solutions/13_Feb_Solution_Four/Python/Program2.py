'''
Write a Program to Convert entered Hexadecimal Number to
Decimal Number.
'''

hexdec = input("Enter number in Hexadecimal Format: ");

dec = int(hexdec, 16);
print(hexdec,"in Decimal =",str(dec));
