
print("Enter Number : ")
while(True) :
	n = int(input())
	if(n < 0):
		break
	print("cube of ", n, " : ", n*n*n)
print("You entered a negative number")

