
n = int(input("Enter Number : "))
if(n*n % 10 == n):
	print("Number is Automorphic Number")	
else:
	print("Number is not Automorphic Number")
	

