asc = 65
while(True):
    ch = input()
    if(ord(ch[0]) != asc):
        break
    asc += 1

