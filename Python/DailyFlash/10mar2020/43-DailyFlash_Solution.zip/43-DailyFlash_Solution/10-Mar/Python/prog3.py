while(True):
    num = int(input())
    if(num <  0):
        exit()
    print(num * num * num)
