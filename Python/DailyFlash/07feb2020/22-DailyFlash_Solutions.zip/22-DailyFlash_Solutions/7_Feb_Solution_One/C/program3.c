
#include<stdio.h>


void main(){

	for(int itr =1 ;itr<=100 ;itr++){

		if(itr%7!=0)
			printf("%d ",itr);
	}	

}	
