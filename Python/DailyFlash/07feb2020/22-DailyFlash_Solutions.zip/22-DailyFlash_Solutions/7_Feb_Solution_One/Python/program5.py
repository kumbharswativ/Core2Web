

for itr in range(0,4):
    for jtr in range(0,4):
        print("=",end="\t") if jtr==itr else print(jtr+1,end="\t")
    print("")    
