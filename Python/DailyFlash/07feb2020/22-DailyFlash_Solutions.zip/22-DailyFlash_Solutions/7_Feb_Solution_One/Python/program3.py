
for itr in range(1,101):

    if itr%7!=0:
        print(itr)
