
num = input("Enter the number : ")

print(hex(num))
