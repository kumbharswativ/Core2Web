
#include <stdio.h>

void main() {

	for(int i = 1;i <= 100; i++){
		if(i%7 == 0)
			continue;
		printf("%d ", i);
	}
	printf("\n");
}
