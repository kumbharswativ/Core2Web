"""
Program 3 : Write a Program that accepts a n inte ger from user and prints
whether that number is odd or even .
Input: 2
Output: 2 is an Even Number

"""


num = input("Enter the number : ")

if num%2==0:
    print("Even")
else:
    print("Odd")
