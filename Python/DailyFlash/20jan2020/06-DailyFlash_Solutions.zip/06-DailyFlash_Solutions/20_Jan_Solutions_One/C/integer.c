/*
Program 1: Write a program that accepts an integer from user and print it.
Input: 11
Output: 11

*/

#include<stdio.h>

void main(){
	int num;
	printf("Enter the Integer : ");
	scanf("%d",&num);

	printf("%d",num);
}	
