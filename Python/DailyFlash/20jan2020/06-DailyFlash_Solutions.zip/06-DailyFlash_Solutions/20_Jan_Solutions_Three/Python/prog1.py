print("Output :", input("Input : "))
