num = int(input("Input : "))
sum = 0
for i in range(num):
    sum += i + 1

print("Sum : ", sum)
