n0, n1, n2, n3, n4, n5, n6, n7, n8, n9 = [int(i) for i in input("Input : ").split()]
sum = n0 + n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9
print("Sum : ", sum, "\nAvg : ", sum / 10)
