num = int(input("Input : "))
print("Output : Even") if num % 2 == 0 else print("Output : Odd")
