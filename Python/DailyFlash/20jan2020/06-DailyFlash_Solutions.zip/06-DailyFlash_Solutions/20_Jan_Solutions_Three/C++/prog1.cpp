#include<iostream>

int main() {
	int i;
	std::cout << "Input : ";
	std::cin >> i;
	std::cout << "Output : "<<i;
	return 0;
}
