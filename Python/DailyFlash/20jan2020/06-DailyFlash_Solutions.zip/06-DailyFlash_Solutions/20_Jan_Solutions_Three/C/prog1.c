#include<stdio.h>

int main(void) {
	int i;
	printf("Input : ");
	scanf("%d", &i);
	printf("Output : %d", i);
	return 0;
}
