
#include <stdio.h>

void main() {
	
	int k;
	printf("Enter Number : ");
	scanf("%d", &k);
	printf("Number : %d\n", k);
	return;
}
