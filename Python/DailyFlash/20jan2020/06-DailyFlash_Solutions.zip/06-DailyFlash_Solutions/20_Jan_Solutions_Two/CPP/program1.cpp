
#include <iostream>

int main() {
	
	int k;
	std::cout << ("Enter Number : ");
	std::cin >> k;
	std::cout << ("Number :" ) << k << std::endl;
	return 0;
}
