#include<iostream>


int main(){

	
	int current,resistance;

	printf("Enter the current value : ");
	scanf("%d",&current);

	printf("Enter the resistance value : ");
	scanf("%d",&resistance);

	printf("Volatage V = %d",current*resistance);
	
}	
