current = input("Enter the current value : ")

resistance = input("Enter the resistance value : ")

print("Voltage v = "+str(current*resistance))
