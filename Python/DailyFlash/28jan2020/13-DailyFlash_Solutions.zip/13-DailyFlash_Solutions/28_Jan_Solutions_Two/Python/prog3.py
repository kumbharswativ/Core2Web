i = float(input("Current : "))
r = float(input("Res : "))
print("Volt = ", i * r) if i >= 0 and r >= 0 else print("Enter valid det.")
