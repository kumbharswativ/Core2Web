'''
Problem Statement

Write a Program to Implement Ohms Law
Note: V = I*R, where, v is voltage, I is current & R is resistance
'''

i = int(input("Enter Current in Amperes \n"))
r = int(input("Enter Resistance in ohms \n"))

v = i*r

print("The Voltage V =  ",v," volts")
