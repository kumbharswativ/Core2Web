
#include <stdio.h>

void main () {
	int n, sum = 0, digit;
	printf("Enter Number : ");
	scanf("%d", &n);
	printf("Enter digit\n");
	scanf("%d", &digit);
	int temp = n;

	while(n != 0){
		if(n%10 == digit){
			sum++;
		}
		n = n / 10;
	}
	if(sum == 0){
		printf("Digit is not present\n");
	}
	else {
		printf("Frequrncy of %d in number %d is : %d \n", digit, temp, sum);
	}

	
}
