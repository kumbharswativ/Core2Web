
#include <stdio.h>

void main () {
	int n, sum = 0;
	printf("Enter Number : ");
	scanf("%d", &n);
	int temp = n;

	while(n != 0){
		sum = sum * 10 + n%10;
		n = n / 10;
	}
	if(sum == temp){
		printf("%d is Palindrome Number \n", temp);
	}
	else {
		printf("%d is not a Palindrome Number \n", temp);
	}

	
}
