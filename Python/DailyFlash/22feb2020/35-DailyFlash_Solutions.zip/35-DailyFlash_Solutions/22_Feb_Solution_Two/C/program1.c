
#include <stdio.h>

void main () {
	int n, sum = 0;
	printf("Enter Number : ");
	scanf("%d", &n);
	int temp = n;

	while(n != 0){
		sum += n%10;
		n = n / 10;
	}
	if(temp % sum == 0){
		printf("%d is Harshad Number \n", temp);
	}
	else {
		printf("%d is not a Harshad Number \n", temp);
	}

	
}
