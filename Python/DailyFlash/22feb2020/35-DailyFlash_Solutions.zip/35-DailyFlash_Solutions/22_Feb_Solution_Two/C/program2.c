
#include <stdio.h>

extern void fun1(int);
extern void fun2(int);
extern void fun3(int);
void main () {
	int n, opt;
	char c;
	printf("Enter Number :  ");
	scanf("%d", &n);
	
	printf("1: Octal\n2: Hexadecimal\n3: Binary\n");
	do {	
		printf("Enter Choice :  ");
		scanf("%d", &opt);

		switch(opt){
			case 1:
				fun1(n);
				break;
			case 2:
				fun2(n);
				break;
			case 3:
				fun3(n);
				break;
			default:
				break;
		}
		printf("do you want to continue : ");
		scanf(" %c", &c);
	}while(c =='y' || c == '\n');


}

/*
 * 	Run: 
 *	cc program2.c program2a.c program2b.c program2c.c 
 *	./a.out
 *
 *
 * */
