
#include <iostream>

int main () {
	int n, sum = 0;
	std::cout << ("Enter Number : ");
	std::cin >> n;
	int temp = n;

	while(n != 0){
		sum = sum * 10 + n%10;
		n = n / 10;
	}
	if(sum == temp){
		std::cout << temp << (" is Palindrome Number \n");
	}
	else {
		std::cout <<temp <<  (" is not a Palindrome Number \n");
	}

	
}
