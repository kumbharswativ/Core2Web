
#include <iostream>

int main () {
	int n, sum = 0, digit;
	std::cout << ("Enter Number : ");
	std::cin >> n;
	std::cout << ("Enter digit\n");
	std::cin >> digit;
	int temp = n;

	while(n != 0){
		if(n%10 == digit){
			sum++;
		}
		n = n / 10;
	}
	if(sum == 0){
		std::cout << ("Digit is not present\n");
	}
	else {
		std::cout << ("Frequrncy of ") << digit << "in number " << temp << "is : " << sum << "\n";
	}

	
}
