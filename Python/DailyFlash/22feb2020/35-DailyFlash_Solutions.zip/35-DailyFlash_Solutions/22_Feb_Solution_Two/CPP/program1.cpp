
#include <iostream>

int main () {
	int n, sum = 0;
	std::cout << ("Enter Number : ");
	std::cin >> n;
	int temp = n;

	while(n != 0){
		sum += n%10;
		n = n / 10;
	}
	if(temp % sum == 0){
		std::cout << temp << (" is Harshad Number \n");
	}
	else {
		std::cout << temp << (" is not a Harshad Number \n");
	}

	
}
