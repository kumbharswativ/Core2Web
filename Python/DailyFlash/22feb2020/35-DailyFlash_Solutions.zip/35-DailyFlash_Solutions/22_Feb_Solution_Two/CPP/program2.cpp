
#include <iostream>

class Program {
	
	public:
	void fun1(int n) {
		int temp, i = 0;
		while(n!=0) {
			temp = n%10;
			if(temp >= 8){
				i = 3;
				char bin[4] = {'\0'};
				while(i>=0) {
					bin[i] = (temp % 8) + 48;
					temp = temp / 8;
					i--;
				}
				std::cout << ("octal of " ) << n%10 << " : " << bin << std::endl;
			}
			else{
				std::cout << ("octal of " ) << n%10 << " : 000" << n%10 << std::endl;
			}
			n = n/10;
		}
	}

	void fun2(int n) {
		int temp, i = 0;
		while(n!=0) {
			temp = n%10;
			i = 3;
			char bin[4] = {'\0'};
			while(i>=0) {
				bin[i] = (temp % 16) + 48;
				temp = temp / 16;
				i--;
			}
			std::cout << ("Hexdecimal of " ) << n%10 << " : "<< (bin) << "\n";
			n = n/10;
		}
	}
	void  fun3(int n) {
		int temp, i = 0;
		char bin[5] = {'0', '0', '0','0', '\0'};
		while(n!=0) {
			temp = n%10;
			i = 3;
			while(i>=0) {
				bin[i] = (temp % 2) + 48;
				temp = temp / 2;
				i--;
			}
			std::cout << ("Binary of ") << n%10 << " = " << bin << std::endl;
			n = n/10;
		}
	}
};

int main () {
	int n, opt;
	char c;
	std::cout << ("Enter Number :  ");
	std::cin >> n;
	Program p;
	std::cout << ("1: Octal\n2: Hexadecimal\n3: Binary\n");
	do {	
		std::cout << ("Enter Choice :  ");
		std::cin >> opt;

		switch(opt){
			case 1:
				p.fun1(n);
				break;
			case 2:
				p.fun2(n);
				break;
			case 3:
				p.fun3(n);
				break;
			default:
				break;
		}
		std::cout << ("do you want to continue : ");
		std::cin >> c;
	}while(c =='y' || c == '\n');
}

/*
 * 	Run: 
 *	g++ program2.cpp program2a.cpp
 *	./a.out
 *
 *
 * */
