sum = 0
n = int(input("Enter Number : "))
temp = n
while(n != 0):
    sum = sum * 10 + n%10
    n = n // 10
if(sum == temp):
    print(temp, "is Palindrome Number")
else :
    print(temp," is not a Palindrome Number")
