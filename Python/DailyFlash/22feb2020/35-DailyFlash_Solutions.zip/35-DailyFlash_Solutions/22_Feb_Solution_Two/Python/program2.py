
def fun1(n):
    i = 0
    while(n!=0) :
        temp = n%10
        i = 3
        binary = []
        while(i>=0) :
            binary.append(chr((temp % 8) + 48))
            temp = temp // 8
            i-=1
		
        print("octal of ", n%10, ":",binary[::-1])
        n = n//10

def fun2(n):
    i = 0
    while(n!=0) :
        temp = n%10
        i = 3
        binary = []
        while(i>=0) :
            binary.append(chr((temp % 16) + 48))
            temp = temp // 16
            i-=1
		
        print("Hexadecimal of ", n%10, ":",binary[::-1])
        n = n//10

def fun3(n):
    i = 0

    while(n!=0) :
        temp = n%10
        i = 3
        binary = []
        while(i>=0) :
            binary.append(chr((temp % 2) + 48))
            temp = temp // 2
            i-=1
        print("Binary of ", n%10, ":",binary[::-1])
        n = n//10


n = int(input("Enter Number: "))
print("1:Octal\n2:Hex\n3:Binary")
opt = int(input("Enter Choice: "))
if(opt == 1):
    fun1(n)
elif(opt == 2):
    fun2(n)
elif(opt == 3):
    fun3(n)
else:
    print("No valid input")
