sum = 0
n = int(input("Enter Number : "))
digit = int(input("Enter digit : "))
if(digit > 9):
    exit(0)
temp = n
while(n != 0):
    if(n%10 == digit):
        sum+=1
    n = n // 10
if(sum == 0):
    print("Digit is absent")
else :
    print("Frequency : ", sum)
