sum = 0
n = int(input("Enter Number : "))
temp = n
while(n != 0):
    sum += n%10
    n = n // 10
if(temp % sum == 0):
    print(temp, "is Harshad Number")
else :
    print(temp," is not a Harshad Number")
