
import java.io.*;
class Program {
	public static void main (String ... kbd) throws IOException {
		int n, sum = 0;
		System.out.printf("Enter Number : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n =  Integer.parseInt(br.readLine());
		int temp = n;
	
		while(n != 0){
			sum = sum * 10 + n%10;
			n = n / 10;
		}
		if(sum == temp){
			System.out.printf("%d is Palindrome Number \n", temp);
		}
		else {
			System.out.printf("%d is not a Palindrome Number \n", temp);
		}
	}
}
