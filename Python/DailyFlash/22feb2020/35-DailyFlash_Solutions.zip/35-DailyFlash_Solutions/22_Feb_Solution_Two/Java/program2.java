
import java.io.*;

class Program1 {
	public static void  main(int n){
		int temp, i = 0;
		char bin[] = {'0', '0', '0','0'};
	
		while(n!=0) {
			temp = n%10;
			i = 3;
			while(i>=0) {
				bin[i] = (char)((temp % 8) + 48);
				temp = temp / 8;
				i--;
			}
			System.out.print("octal of " + (n%10) + " : ");
			System.out.println(bin);
			n = n/10;
		}
	}
}	

class Program2 {
	public static void  main(int n){
		int temp, i = 0;
		char bin[] = {'0', '0', '0','0'};	
		while(n!=0) {
			temp = n%10;
			i = 3;
			while(i>=0) {
				bin[i] = (char)((temp % 16) + 48);
				temp = temp / 16;
				i--;
			}
			//System.out.printf("Binary of %d : %s\n", n%10, bin);
			System.out.print("Hexadecimal of " + (n%10) + " : ");
			System.out.println(bin);
			n = n/10;
		}
	}
}	

class Program3 {
	public static void  main(int n){
		int temp, i = 0;
		char bin[] = {'0', '0', '0','0'};
	
		while(n!=0) {
			temp = n%10;
			i = 3;
			while(i>=0) {
				bin[i] = (char)((temp % 2) + 48);
				temp = temp / 2;
				i--;
			}
			//System.out.printf("Binary of %d : %s\n", n%10, bin);
			System.out.print("Binary of " + (n%10) + " : ");
			System.out.println(bin);
			n = n/10;
		}
	}
}	

class Program {
		public static void main (String [] args) throws IOException{
		int n, opt = 0;
		char c;
		System.out.printf("Enter Number :  ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
	
		System.out.printf("1: Octal\n2: Hexadecimal\n3: Binary\n");
		do {	
			System.out.printf("Enter Choice :  ");
			opt = Integer.parseInt(br.readLine());

			switch(opt){
				case 1:
					Program1.main(n);
					break;
				case 2:
					Program2.main(n);
					break;
				case 3:
					Program3.main(n);
					break;
				default:
					break;
			}
			System.out.printf("do you want to continue : ");
			c = (char)br.read();
			br.skip(1);
		}while(c =='y' || c == '\n');	
	}
}
