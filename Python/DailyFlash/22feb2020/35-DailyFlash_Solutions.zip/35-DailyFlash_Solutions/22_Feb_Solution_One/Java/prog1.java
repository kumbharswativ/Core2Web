import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num, sum = 0;
		System.out.println("Enter num : ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		int temp = num;
		while(num != 0) {
			sum = sum + num % 10;
			num /= 10;
		}
		if(temp % sum == 0) {
			System.out.println("It is a harshad num.");
		} else {
			System.out.println("It is not a harshed num.");
		}	
	}
}
