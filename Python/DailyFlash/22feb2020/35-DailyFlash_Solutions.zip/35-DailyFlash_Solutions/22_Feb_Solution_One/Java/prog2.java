import java.util.Scanner;
class Demo {

	public static void main(String[] args) {
		int num, rem;
		System.out.println("Enter num : ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		System.out.println("Enter choice\n1.Bin\n2.Hex\n3.Oct");
		int choice;
		String bin = "";
		String oct = "";
		choice = sc.nextInt();
		switch(choice) {
		
			case 1:
				while(num != 0) {
					bin = "";
					rem = num % 10;
					while(rem != 0) {
						bin = rem % 2 + bin;
						rem /= 2;
					}
					System.out.print("Bin of " + num % 10 + " : ");
					num /= 10;
					for(int i = 0; i < bin.length(); i++) {
						System.out.print(bin.charAt(i));
					}
					System.out.println();
				}
				break;
			case 2:
				while(num != 0) {
					System.out.println("Hex of " + num % 10 + " : " + num % 10);
					num /= 10;
				}
				break;
			case 3:
				while(num != 0) {
					oct = "";
					rem = num % 10;
					while(rem != 0) {
						oct = rem % 8 + oct;
						rem /= 8;
					}
					System.out.println("Oct of " + num % 10 + " : " + oct.charAt(0) + oct.charAt(1));
					num /= 10;
				}
				break;
			default :
				System.out.println("Enter invalid choice.");
		}
	}
}
