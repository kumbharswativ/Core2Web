class Demo {
	public static void main(String[] args) {
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 4; j++) {
				if(j >= i) {
					System.out.print(i);
					System.out.print(j + "\t");
				} else {
					System.out.print("\t");
				}
			}
			System.out.println();
		}
	}
}
