import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num, sum = 0, n, cnt = 0;
		System.out.println("Enter num : ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		System.out.println("Enter num to check freqn : ");
		n = sc.nextInt();
		int temp = num;
		while(num != 0) {
			if(num % 10 == n)
				cnt++;
			num /= 10;
		}
		System.out.println("Freqn of " + n + " : " + cnt);
	}
}
