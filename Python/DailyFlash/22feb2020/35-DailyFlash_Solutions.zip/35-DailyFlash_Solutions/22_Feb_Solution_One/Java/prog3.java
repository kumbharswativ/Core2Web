import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num, rev = 0;
		System.out.println("Enter num : ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		int temp = num;
		while(num != 0) {
			rev = rev * 10 + num % 10;
			num /= 10;
		}
		if(rev == temp) {
			System.out.println("It is a palindrome num.");
		} else {
			System.out.println("It is not a palindrome num.");
		}	
	}
}
