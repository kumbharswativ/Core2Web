num = int(input("num : "))
n = int(input("num for freqn : "))
cnt = 0
while(num != 0):
    if(num % 10 == n):
        cnt += 1
    num = int(num / 10)
print("Freqn of", n, ":", cnt)
