num = int(input("num : "))
s = 0
temp = num
while(num != 0):
    s += num % 10
    num = int(num / 10)
if(temp % s == 0):
    print("Harshed")
else:
    print("Not harshed")
