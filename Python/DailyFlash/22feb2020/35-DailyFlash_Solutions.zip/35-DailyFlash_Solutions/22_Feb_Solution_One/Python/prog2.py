num = int(input("num : "))
print("1.Bin\n2.Hex\n3.Oct\nEnter ch : ")
ch = int(input())
while(num != 0):
    rem = num % 10
    while(rem != 0):
        if(ch == 1):
            print("bin of ", rem, " : ", bin(rem))
        elif(ch == 2):
            print("hex of ", rem, " : ", hex(rem))
        elif(ch == 3):
            print("oct of ", rem, " : ", oct(rem))
        else:
            print("Enter valid choice.")
        rem = int(rem / 10)
    num = int(num / 10)
