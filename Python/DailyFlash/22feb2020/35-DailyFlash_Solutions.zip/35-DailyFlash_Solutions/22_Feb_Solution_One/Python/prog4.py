for i in range(4):
    for j in range(4):
        if(j >= i):
            print(i, end = "")
            print(j, end = "\t")
        else:
            print(end = "\t")
    print()
