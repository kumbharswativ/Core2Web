#include<stdio.h>

int main(void) {
	int num, sum = 0;
	printf("Enter num : ");
	scanf("%d", &num);
	int temp = num;
	while(num != 0) {
		sum = sum + num % 10;
		num /= 10;
	}
	if(temp % sum == 0) {
	       printf("It is a harshad num.");
	} else {
		printf("It is not a harshed num.");
	}	
}
