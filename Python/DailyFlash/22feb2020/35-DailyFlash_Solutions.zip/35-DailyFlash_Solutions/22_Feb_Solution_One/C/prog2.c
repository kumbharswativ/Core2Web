#include<stdio.h>

void init(char* bin) {		
	bin[0] = '0';
	bin[1] = '0';
	bin[2] = '0';
	bin[3] = '0';
}

int main(void) {
	int num, rem, k;
	printf("Enter num : ");
	scanf("%d", &num);
	printf("Enter choice\n1.Bin\n2.Hex\n3.Oct\n");
	int choice;
	char bin[4];
	char oct[2];
	scanf("%d", &choice);
	switch(choice) {
	
		case 1:
			while(num != 0) {
				k = 0;
				init(bin);
				rem = num % 10;
				while(rem != 0) {
					bin[3 - k] = rem % 2 + '0';
					rem /= 2;
					k++;
				}
				printf("Bin of %d : ", num % 10);
				num /= 10;
				for(int i = 0; i < 4; i++) {
					printf("%c", bin[i]);
				}
				printf("\n");
			}
			break;
		case 2:
			while(num != 0) {
				printf("Hex of %d : %d\n", num % 10, num % 10);
				num /= 10;
			}
			break;
		case 3:
			while(num != 0) {
				k = 0;
				oct[0] = '0';
				oct[1] = '0';
				rem = num % 10;
				while(rem != 0) {
					oct[1 - k] = rem % 8 + '0';
					k++;
					rem /= 8;
				}
				printf("Oct of %d : %c%c\n", num % 10, oct[0], oct[1]);
				num /= 10;
			}
			break;
		default :
			printf("Enter invalid choice.");
	}
}
