#include<stdio.h>

int main(void) {
	int num, rev = 0;
	printf("Enter num : ");
	scanf("%d", &num);
	int temp = num;
	while(num != 0) {
		rev = rev * 10 + num % 10;
		num /= 10;
	}
	if(rev == temp) {
	       printf("It is a palindrome num.");
	} else {
		printf("It is not a palindrome num.");
	}	
}
