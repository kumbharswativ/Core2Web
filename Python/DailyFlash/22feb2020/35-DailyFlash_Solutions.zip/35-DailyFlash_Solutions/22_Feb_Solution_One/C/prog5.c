#include<stdio.h>

int main(void) {
	int num, sum = 0, n, cnt = 0;
	printf("Enter num : ");
	scanf("%d", &num);
	printf("Enter num to check freqn : ");
	scanf("%d", &n);
	int temp = num;
	while(num != 0) {
		if(num % 10 == n)
			cnt++;
		num /= 10;
	}
	printf("Freqn of %d : %d", n, cnt);
}
