#include<iostream>

int main() {
	int num, sum = 0, n, cnt = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	std::cout << "Enter num to check freqn : ";
	std::cin >> n;
	int temp = num;
	while(num != 0) {
		if(num % 10 == n)
			cnt++;
		num /= 10;
	}
	std::cout << "Freqn of " << n << " : " << cnt;
}
