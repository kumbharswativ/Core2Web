#include<iostream>

int main() {
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 4; j++) {
			if(j >= i) {
				std::cout << i << j << "\t";
			} else {
				std::cout << "\t";
			}
		}
		std::cout << "\n";
	}
}
