#include<iostream>

int main() {
	int num, sum = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	int temp = num;
	while(num != 0) {
		sum = sum + num % 10;
		num /= 10;
	}
	if(temp % sum == 0) {
		std::cout << "It is a harshad num.";
	} else {
		std::cout << "It is not a harshed num.";
	}	
}
