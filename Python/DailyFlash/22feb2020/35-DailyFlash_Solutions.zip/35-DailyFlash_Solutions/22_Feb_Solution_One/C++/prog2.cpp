#include<iostream>

void init(char* bin) {		
	bin[0] = '0';
	bin[1] = '0';
	bin[2] = '0';
	bin[3] = '0';
}

int main() {
	int num, rem, k;
	std::cout << "Enter num : ";
	std::cin >> num;
	std::cout << "Enter choice\n1.Bin\n2.Hex\n3.Oct\n";
	int choice;
	char bin[4];
	char oct[2];
	std::cin >> choice;
	switch(choice) {
	
		case 1:
			while(num != 0) {
				k = 0;
				init(bin);
				rem = num % 10;
				while(rem != 0) {
					bin[3 - k] = rem % 2 + '0';
					rem /= 2;
					k++;
				}
				std::cout << "Bin of " << num % 10 << " : ";
				num /= 10;
				for(int i = 0; i < 4; i++) {
					std::cout << bin[i];
				}
				std::cout << "\n";
			}
			break;
		case 2:
			while(num != 0) {
				std::cout << "Hex of " << num % 10 << " : " << num % 10 << "\n";
				num /= 10;
			}
			break;
		case 3:
			while(num != 0) {
				k = 0;
				oct[0] = '0';
				oct[1] = '0';
				rem = num % 10;
				while(rem != 0) {
					oct[1 - k] = rem % 8 + '0';
					k++;
					rem /= 8;
				}
				std::cout << "Oct of " << num % 10 << " : " << oct[0] << oct[1] << "\n";
				num /= 10;
			}
			break;
		default :
			std::cout << "Enter invalid choice.";
	}
}
