'''
Program4 -- Write a Program that prints frequency of a digit from a number, where user provides number & digit both.
'''

num=input("Enter the number\t: ")
digit = input("Enter Digit to Check frequency of\t: ")
cnt = 0

for x in range(len(num)):
    if digit == num[x]:
        cnt+=1

print("Frequency of ",digit," is ",cnt)
