'''
Program0 -- Write a Program that checks whether an entered number is Harshad Number or Not.
{Note: A number is termed as Harshad number if sum of all digits from that number is Perfect Divisor of that number. E.g., 171, 1+7+1 = 9, and 9 is perfect divisor of 171 so 171 is Harshad number.}
'''

num = int(input("Enter A number\t:"))

sum = 0;
temp = num

while temp > 0 :

    sum = sum + (temp%10)
    temp = temp//10

if num%sum == 0:
    print("Entered Number is a Harshad Number")
else:
    print("Entered Number is not a Harshad Number")

