'''
Program1 -- Write a Program that accepts a number from user and asks for user choice from (Binary, Octal, and Hexadecimal) and prints respective values of each digit from that number.
{Note: User Choice, 1 for Binary, 2 for Hexadecimal, and 3 for Octal)
'''
num=input("Enter the number\t: ")[::-1]
num = int(num)

ch = int(input("Select Choice\n1. Binary\t2. Hexadecimal\t3. Octal\t: "))

while(num > 0):
    rem=num % 10
    if ch == 1:
        print("The Binary value of",rem,":",str(bin(rem))[2:])
    elif ch == 2:
        print("The Hexadecimal value of",rem,":",str(hex(rem))[2:])
    elif ch == 3:
        print("The octal value of",rem,":",str(oct(rem))[2:])
    num=num//10

