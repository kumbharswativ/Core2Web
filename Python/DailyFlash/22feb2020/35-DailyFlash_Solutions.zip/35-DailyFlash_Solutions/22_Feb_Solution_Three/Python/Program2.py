'''
Program2 -- Write a Program to check whether the entered number is Palindrome number or not.
'''
num=input("Enter the number\t: ")
rev = num[::-1]
rev = int(rev)
num = int(num)


if num == rev :
    print("The Entered Number is a Pallindrome Number")
else:
    print("The Entered Number is not a Pallindrome Number")

