'''
Program3 -- Write a Program to Print following Pattern.
 	
 		00	01	02	03
 			11	12	13
 				22	23
 					33
'''
rows = int(input("Enter Number of Rows : \n"))

for x in range(rows):
    for y in range(rows):
        if(y < x):
            print(" ",end="\t")

        else:
            print(x,y,end="\t",sep="")
    print()
