/* Problem Statement
 *
 * Program4 -- Write a Program that prints frequency of a digit from a number, where user provides number & digit both.
 *
 * */


//Include Header File for all input output Operations
#include <iostream>

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - int
 * Function Arguments - void
 * */

int main() {

	/*
	 * Declarations
	 * num_input_1 - Integer type variable for user input
	 * digit - to store each digit of a number
	 * temp - To store a temporary number for calculations
	 *
	 * */
	int num_input_1 = 0,temp = 0,digit = 0,cnt = 0;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */

	do {
		std::cout<<"Enter A number and a digit to check frequency of\n";
		/*
		 * if there is character input the cin returns 0, Hence for unsuccesfull return of cin execute
		 * */

		std::cin>>num_input_1;
		std::cin>>digit;

		//if statement if Condition 1 is false
		if(num_input_1 <= 0){

			std::cout<<"Invalid, Only Positive values allowed"<<std::endl;
		}
		else if(std::cin.fail()){

			std::cout<<"Characters are not allowed"<<std::endl;
		}
		else 
			break;

	}while(!std::cin.fail() && num_input_1 <= 0);

	temp = num_input_1;
	digit < 1 ? (digit = -digit) : 1 ;

	//While to check for the frequency of digit
	while(temp > 0){

		if(temp%10 == digit)
			cnt++;
		temp/=10;
	};

	printf("The Frequency of %d in %d is %d\n",digit,num_input_1,cnt);

	return 0;
}
