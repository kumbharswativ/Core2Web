/* Problem Statement
 *
 * Program1 -- Write a Program that accepts a number from user and asks for user choice from (Binary, Octal, and Hexadecimal) and prints respective values of each digit from that number.
 * {Note: User Choice, 1 for Binary, 2 for Hexadecimal, and 3 for Octal)
 *
 * */

//Include Header File for all input output Operations and String Operations
#include <stdio.h>
#include <string.h>

/* 
 *Function Declarations
 * 
 * */

int power(int,int);
int reverse(int);
void toHexadecimal(int);
void toOctal(int);
void toBinary(int);

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - void
 * Function Arguments - void
 * */
void main() {

	/*
	 * Declarations
	 * num_input_1 - Integer type variable for user input
	 * temp - To store a temporary number for calculations
	 * flag - To control Loops
	 * choice - User input for choice
	 * rev - To store Reverse Number
	 * */
	int num_input_1 = 0,choice = 0,flag = 1,rev = 0;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */
	do {
		printf("Enter A number \n");
		/*
		 * if there is character input the scanf returns 0, Hence for unsuccesfull return of scanf execute
		 * */
		if(!scanf("%d",&num_input_1)){

			printf("Character Inputs not allowed, Enter Positive Integers only\n");
			//Store all the character input in a temporary string
			char* tmp;
			scanf("%s",tmp);
			num_input_1 = 0;
		}
		//else-if statement if Condition 1 is false
		else if(num_input_1 <= 0){

			printf("Invalid, Only Positive values allowed\n");
		}

	}while(num_input_1 <= 0);

	rev = reverse(num_input_1);

	//Swich case to select User choice for conversion 
	do {
		printf("Select Your Choice\n");
		printf("1. Binary\t2. Hexadecimal\t3. Octal\t");
		scanf("%d",&choice);

		switch(choice) {

			case 1 :  printf("The Binary Value of Digits of Input Number is\n");
				  toBinary(rev);
				  break;

			case 2 :  printf("The Hexadecimal Value of Digits of Input Number is\n");
				  toHexadecimal(rev);
				  break;

			case 3 :  printf("The Octal Value of Digits of Input Number is\n");
				  toOctal(rev);
				  break;

			default : flag = 0;

		}

	}while(flag);
}


/*
 * power function to calculate exponention of the form number^index
 * Function name - power
 * Function return type - int
 * Function arguments - int,int
 * 	1) number - The number whose exponention need to be calculated
 * 	2) index - The value of exponent
 * */

int power(int number, int index){

	int answer = 1;

	//while to calculate exponention value from the 0 to the specified Index
	while(index > 0){

		answer*=number;
		index--;
	}
	return answer;
}

/*
 * Function to calculate Hexadecimal value of each digit of a number
 * Function name - toHexadecimal
 * Function return type - void
 * Function arguments - int
 * 	1) input - The number whose Hexadecimal value is to be calculated
 * */
void toHexadecimal(int input){

	int temp = input,digit = 0;
	char Hex[10];

	//While loop to Separate the digits of the input Number
	while(temp > 0){

		char *h = Hex;

		digit = temp%10;

		//Convert the base 10 number (decimal) to base 16 (HexaDecimal)
		int check = digit%16;

		//If the hexadecimal character is less than or equal to 9, Convert it into Numeric ASCII values
		//Else Convert into Hex Character's ASCII values
		check <= 9 ? (*h = (char)(check+48)) : (*h = (char)(check+55));	

		//Print the HexaDecimal String
		printf("The HexaDecimal Number of %d : %s\n",digit,Hex);
		temp/=10;
	}

}

/*
 * Function to calculate Octal value of each digit of a number
 * Function name - toOctal
 * Function return type - void
 * Function arguments - int
 * 	1) input - The number whose Octal value is to be calculated
 * */
void toOctal(int input){

	char oct[10];
	int temp = input,digit = 0;
	//While loop to Separate the digits of the input Number
	while(temp > 0){

		char *h = oct;

		digit = temp%10;

		while(1){		
			//Convert the base 10 number (decimal) to base 8 (Octal)
			int check = digit%8;

			//Convert into Octal Character's ASCII values
			*h = (char)(check+48);
			h++;
			digit/=8;
			if (digit == 0){

				*h = '\0';
				break;
			}
		}

		//Print the Octal String
		printf("The Octal Number of %d : ",temp%10);
		for(int lc = strlen(oct); lc >= 0; lc--){
			printf("%c",oct[lc]);
		}
		printf("\n");

		temp/=10;
	}

}

/*
 * Function to calculate Binary value of each digit of a number
 * Function name - toBinary
 * Function return type - void
 * Function arguments - int
 * 	1) input - The number whose Binary value is to be calculated
 * */
void toBinary(int input){

	int temp = input,digit = 0,pow = 0;

	//While loop to Separate the digits of the input Number
	while(temp > 0){

		int bin[4] = {0,0,0,0};
		pow = 3;
		digit = temp%10;

		//While Loop to convert Decimal Digit Number into Binary Number
		while(digit > 0){

			bin[pow] = (digit%2);
			digit/=2;
			pow--;
		}

		//Print the resulting Binary Value of The Digit in group of 4 Bits
		printf("The Binary Number of %d : ",temp%10);
		for(int lc = 0; lc < 4; lc++){
			printf("%d",bin[lc]);
		}
		printf("\n");
		temp/=10;
	}
}

/*
 * Function to calculate reverse number
 * Function name - reverse
 * Function return type - int
 * Function arguments - int
 * 	1) input - The number which is to be reversed
 * */
int reverse(int input){

	int temp = input,rev = 0;

	//While loop to reverse the Number
	while(temp > 0){

		rev = (rev*10) + temp%10;
		temp/=10;
	};

	return rev;
}



