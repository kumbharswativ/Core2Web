/* Problem Statement
 *
 * Program0 -- Write a Program that checks whether an entered number is Harshad Number or Not.
 * {Note: A number is termed as Harshad number if sum of all digits from that number is Perfect Divisor of that number. E.g., 171, 1+7+1 = 9, and 9 is perfect divisor of 171 so 171 is Harshad number.}
 *
 * */

//Import io package for all Input Output Operations
import java.io.*;

//User defined class to find Harshad Number
class Harshad {

	//Entry Point Function main, throws IOException as the readLine method of BufferedReader throws Exception
	public static void main(String[] args) throws IOException {

		//To make a connection between Java code and Keyboard for Input 
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));

		/*
		 * Declarations
		 * num_input_1 - Integer type variable for user input
		 * temp - To store a temporary number for calculations
		 * sum - To store sum of the digits of the Number
		 * */
		int num_input_1 = 0,temp = 0,sum = 0;

		/*
		 * Use of do-while loop till all the conditions are true
		 * Condition 1 - All values should be greater than 0
		 * Condition 2 - Only Integer inputs are allowed
		 * */

		do {
			System.out.println("Enter A Number ");

			//Try-catch to Handle Character input 
			try {

				num_input_1 = Integer.parseInt(b.readLine());

				if(num_input_1 <= 0)
					System.out.println("Enter Positive Values only");

			}
			catch(NumberFormatException n){

				System.out.println("Invalid, Enter Numbers Only");
			}

		}while(num_input_1 <= 0);

		temp = num_input_1;

		//While loop to Calculate sum of the digits of the input Number
		while(temp > 0){

			sum = sum +  temp%10;
			temp/=10;
		}

		//If-else to check for Harshad Number
		if((num_input_1 % sum) == 0)
			System.out.printf("The Entered Number %d is Harshad Number\n",num_input_1);
		else
			System.out.printf("The Entered Number %d is not Harshad Number\n",num_input_1);

	}
}
