/* Problem Statement
 *
 * Program1 -- Write a Program that accepts a number from user and asks for user choice from (Binary, Octal, and Hexadecimal) and prints respective values of each digit from that number.
 * {Note: User Choice, 1 for Binary, 2 for Hexadecimal, and 3 for Octal)
 *
 * */

//Import io package for all Input Output Operations
import java.io.*;
import java.util.*;

//User defined class to Find Octal Value of Digits of the Number
class Conversions {

	//Entry Point Function main, throws IOException as the readLine method of BufferedReader throws Exception
	public static void main(String[] args) throws IOException {

		//To make a connection between Java code and Keyboard for Input 
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));

		Conversions conv = new Conversions();

		/* 
		 * Declarations
		 * Integer Variables
		 * num_input_1 - To store User Input
		 * rev - to store reversed Number
		 * */

		int num_input_1 = 0,temp,rev = 0,choice = 0;
		boolean flag = true;

		/*
		 * Test Conditions
		 * Condition1 - Number Should be greater than 0 
		 * Condition2 - Character/String Input Not allowed
		 * 
		 * */

		//do-while loop to take user input till all conditions are true
		do {
			System.out.println("Enter A Number ");

			//Try-catch to Handle Character input 
			try {
				num_input_1 = Integer.parseInt(b.readLine());

				if(num_input_1 <= 0)
					System.out.println("Invalid, Enter Positive Numbers Only");
			}
			catch(NumberFormatException n){

				System.out.println("Invalid, Enter Numbers Only");
			}

		}while(num_input_1 <= 0);

		rev = conv.reverse(num_input_1);

		//Swich case to select User choice for conversion 
		do {
			System.out.printf("Select Your Choice\n");
			System.out.printf("1. Binary\t2. Hexadecimal\t3. Octal\t");
			//Try-catch to Handle Character input 
			try {

				choice = Integer.parseInt(b.readLine());
			}
			catch(NumberFormatException n){

				System.out.println("Invalid, Enter Numbers Only");
			}


			switch(choice) {

				case 1 :  System.out.printf("The Binary Value of Digits of Input Number is\n");
					  conv.toBinary(rev);
					  break;

				case 2 :  System.out.printf("The Hexadecimal Value of Digits of Input Number is\n");
					  conv.toHexadecimal(rev);
					  break;

				case 3 :  System.out.printf("The Octal Value of Digits of Input Number is\n");
					  conv.toOctal(rev);
					  break;

				default : flag = false;

			}

		}while(flag);

	}


	/*
	 * Function to calculate Hexadecimal value of each digit of a number
	 * Function name - toHexadecimal
	 * Function return type - void
	 * Function arguments - int
	 * 	1) input - The number whose Hexadecimal value is to be calculated
	 * */
	void toHexadecimal(int input){

		int temp = input,digit = 0;

		//While loop to Separate the digits of the input Number
		while(temp > 0){

			digit = temp%10;

			//Convert the base 10 number (decimal) to base 16 (HexaDecimal)
			System.out.println("The HexaDecimal Number of "+digit+" : "+Integer.toHexString(digit));
			temp/=10;
		}

	}

	/*
	 * Function to calculate Octal value of each digit of a number
	 * Function name - toOctal
	 * Function return type - void
	 * Function arguments - int
	 * 	1) input - The number whose Octal value is to be calculated
	 * */
	void toOctal(int input){

		int temp = input,digit = 0;

		//While loop to Separate the digits of the input Number
		while(temp > 0){

			digit = temp%10;
			System.out.println("Octal Value of "+digit+" : "+Integer.toOctalString(digit));
			temp/=10;
		}

	}

	/*
	 * Function to calculate Binary value of each digit of a number
	 * Function name - toBinary
	 * Function return type - void
	 * Function arguments - int
	 * 	1) input - The number whose Binary value is to be calculated
	 * */
	void toBinary(int input){

		int temp = input,digit = 0;

		//While loop to Separate the digits of the input Number
		while(temp > 0){

			digit = temp%10;


			//Print the resulting Binary Value of The Digit
			System.out.println("The Binary Number of "+digit+" : "+Integer.toBinaryString(digit));
			temp/=10;
		}
	}

	/*
	 * Function to calculate reverse number
	 * Function name - reverse
	 * Function return type - int
	 * Function arguments - int
	 * 	1) input - The number which is to be reversed
	 * */
	int reverse(int input){

		int temp = input,rev = 0;

		//While loop to reverse the Number
		while(temp > 0){

			rev = (rev*10) + temp%10;
			temp/=10;
		};

		return rev;
	}

}
