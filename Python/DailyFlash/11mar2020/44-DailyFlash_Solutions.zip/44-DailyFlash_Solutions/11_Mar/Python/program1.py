
n = int(input("Enter Number : "))
for i in range(1,n+1):
    if(i*i % 10 == i):
        print(i,end = " ")
print()
	

