


num = 7

for itr in range(4):
    for jtr in range(itr+1):
        print(num,end="\t")
        num = num -1;
    print("")
    num = num + 1
