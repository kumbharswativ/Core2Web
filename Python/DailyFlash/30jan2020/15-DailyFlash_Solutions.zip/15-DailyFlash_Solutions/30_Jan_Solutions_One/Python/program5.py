
print("Enter the first complex : ")
real1 = input("real1 : ")
img1 = input("img1 : ")
print("Enter the Second complex : ")
real2 = input("real2 : ")
img2 = input("img2 : ")


print("Addition of "+str(real1)+" + i"+str(img1)+" & "+str(real2)+" + i"+str(img2)+" = "+str(real1+real2)+" + i"+str(img1+img2))
