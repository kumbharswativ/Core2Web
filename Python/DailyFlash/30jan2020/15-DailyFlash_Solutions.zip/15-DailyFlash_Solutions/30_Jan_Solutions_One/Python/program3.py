
num1 = input("Enter the num1 : ")
num2 = input("Enter the num2 : ")


print("Quotient : "+str(num1/num2 if num1>num2 else num2/num1))
print("Reminder : "+str(num1%num2 if num1>num2 else num2%num1))

