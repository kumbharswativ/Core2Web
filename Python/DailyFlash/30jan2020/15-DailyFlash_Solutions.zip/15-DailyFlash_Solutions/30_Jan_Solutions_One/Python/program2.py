
mass = input("Enter the mass : ")

velocity = input("Enter the velocity : ")

print("Kinetic Energy : "+str(0.5*mass*velocity*velocity))

        
