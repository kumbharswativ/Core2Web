'''
Problem Statement

Write a Program to that accepts two integers from user and calculates the Quotient & Reminder from their division
'''

num1 = int(input("Enter a number1 \n"))
num2 = int(input("Enter a number2 \n"))


print("Quotient = ",int(num1/num2))
print("Remainder = ",num1%num2)
