import java.util.*;

class Demo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter real and img : ");
		int r1 = sc.nextInt();
		int i1 = sc.nextInt();
		System.out.println("Enter real and img : ");
		int r2 = sc.nextInt();
		int i2 = sc.nextInt();
		System.out.println("Sum : " + (r1 + r2) + " + " + (i1 + i2) + "i");
	}
}
