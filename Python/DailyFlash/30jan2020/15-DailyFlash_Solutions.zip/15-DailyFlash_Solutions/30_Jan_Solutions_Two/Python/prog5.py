r1, i1 = [int(i) for i in input("enter real img : ").split()]
r2, i2 = [int(i) for i in input("enter real img : ").split()]
print("sum : ", r1 + r2, " + ", i1 + i2, "i");
