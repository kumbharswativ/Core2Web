num1 = int(input("num1 : "))
num2 = int(input("num2 : "))
print("Quo : ", int(num1/num2), "\nrem : ", num1 % num2);
