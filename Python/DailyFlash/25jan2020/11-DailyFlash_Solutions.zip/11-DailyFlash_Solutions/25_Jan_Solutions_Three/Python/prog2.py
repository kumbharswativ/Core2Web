num1, num2 = [int(i) for i in input("Input : ").split()]
num1 = num1 + num2
num2 = num1 - num2
num1 = num1 - num2
print("num1 : ", num1)
print("num2 : ", num2)
