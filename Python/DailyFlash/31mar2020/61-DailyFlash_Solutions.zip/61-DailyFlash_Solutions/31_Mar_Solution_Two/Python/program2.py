
print(len(input("Enter String : ")))
