arr = raw_input()
print(len(arr))
