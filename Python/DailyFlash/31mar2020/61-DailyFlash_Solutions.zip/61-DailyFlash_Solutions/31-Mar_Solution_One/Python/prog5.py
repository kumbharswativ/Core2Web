import math
l = float(input("Length: "))
print(1/((2 * 3.14) / math.sqrt(l / 9.81)))
