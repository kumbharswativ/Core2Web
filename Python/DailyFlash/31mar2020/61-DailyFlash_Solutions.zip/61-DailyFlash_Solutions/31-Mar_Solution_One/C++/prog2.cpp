#include<bits/stdc++.h>

int main() {
	char arr[100];
	int words = 0;
	std::cin.getline(arr, sizeof(arr));
	std::cout << strlen(arr);
}

