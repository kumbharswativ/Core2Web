print("Lenght of String is :",len(input("Enter the string :")))


