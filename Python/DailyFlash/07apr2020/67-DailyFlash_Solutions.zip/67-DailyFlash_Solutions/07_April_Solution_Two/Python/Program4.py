
freq=float(input("Enter the Frequency :"))

print("Period  :",round(1/freq,4))
