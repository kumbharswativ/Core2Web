st = input("Enter the string : ")

ch = input("Enter a Character : ")

cnt = 0
for x in st :

	if x == ch :
		cnt+=1

print("Count Of ",ch," is ",cnt)

