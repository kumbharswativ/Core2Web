num = int(input("Input : "))
for i in range(10):
    print(num * (i + 1))
