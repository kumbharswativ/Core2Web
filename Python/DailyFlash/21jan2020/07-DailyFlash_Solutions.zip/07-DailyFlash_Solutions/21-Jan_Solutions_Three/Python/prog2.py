for i in range(20):
    print((i + 1) * (i + 1) * (i + 1))
