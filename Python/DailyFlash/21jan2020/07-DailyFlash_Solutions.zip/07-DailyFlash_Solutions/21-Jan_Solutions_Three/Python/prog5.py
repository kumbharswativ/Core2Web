for i in range(4):
    print("0 "*(i + 1))
