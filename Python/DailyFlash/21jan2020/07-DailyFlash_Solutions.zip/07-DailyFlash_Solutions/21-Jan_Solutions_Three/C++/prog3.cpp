#include<iostream>

int main() {
	for(int i = 1; i <= 10; i++) {
		std::cout << i * 2<< std::endl;
	}
	return 0;
}
