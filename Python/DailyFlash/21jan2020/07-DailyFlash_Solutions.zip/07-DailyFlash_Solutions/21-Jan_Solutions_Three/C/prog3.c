#include<stdio.h>

int main(void) {
	for(int i = 1; i <= 10; i++) {
		printf("%d ", 2 * i);	
	}
	return 0;
}
