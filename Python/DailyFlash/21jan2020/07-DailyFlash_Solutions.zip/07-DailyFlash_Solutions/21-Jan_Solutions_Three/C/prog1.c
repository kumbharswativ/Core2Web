#include<stdio.h>

int main(void) {
	for(int i = 1; i <= 10; i++) {
		printf("%d\n", i * i);	
	}
	return 0;
}
