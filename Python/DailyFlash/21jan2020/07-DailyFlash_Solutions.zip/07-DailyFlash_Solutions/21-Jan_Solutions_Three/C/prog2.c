#include<stdio.h>

int main(void) {
	for(int i = 1; i <= 20; i++) {
		printf("%d\n", i * i * i);	
	}
	return 0;
}
