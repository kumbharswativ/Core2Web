/*Program 3: Write a Program to print table of 2.
Output: 2 4 6 8 10 12 14 16 18 20*/

#include<iostream>

int main(){
		
	for(int itr = 1 ;itr <= 10 ; itr++){
		
		printf("%d \n",itr*2);
	}	
}	
