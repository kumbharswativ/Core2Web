"""
Program 2 : Write a Program t o print cu be of first 20 numbers .
Output:
Cube of 1: 1
Cube of 2: 8
Cube of 3: 27
.
.
.
Cube of 20: 8000

"""


for itr in range(1,21):
    print("Cube of "+str(itr)+" is "+str(itr*itr*itr))
