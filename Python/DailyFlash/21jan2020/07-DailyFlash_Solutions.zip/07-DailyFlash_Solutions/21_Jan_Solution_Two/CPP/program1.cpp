
#include <iostream>

int main() {

	for(int i = 1; i <= 10; i++)
		std::cout << ("Square of ") <<  i << (i * i) << std::endl;
	
	return 0;
}
