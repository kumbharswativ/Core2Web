
#include <iostream>

int main() {

	for(int i = 1; i <= 20; i++)
		std::cout << ("Cube of ") <<  i << (i * i * i) << std::endl;
	
	return 0;
}
