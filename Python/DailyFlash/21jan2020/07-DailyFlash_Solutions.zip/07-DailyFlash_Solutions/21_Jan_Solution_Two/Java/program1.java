
class Scheduling {
	public static void main(String[] kbd) {

		for(int i = 1; i <= 10; i++)
			System.out.printf("Square of %d : %d\n", i, i * i);
	}
}
