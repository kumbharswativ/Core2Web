
class Scheduling {
	public static void main(String[] kbd) {

		for(int i = 1; i <= 20; i++)
			System.out.printf("Cube of %d : %d\n", i, i * i * i);
	}
}
