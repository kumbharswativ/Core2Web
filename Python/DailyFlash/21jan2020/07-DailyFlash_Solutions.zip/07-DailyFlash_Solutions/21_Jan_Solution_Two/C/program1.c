
#include <stdio.h>

int main() {

	for(int i = 1; i <= 10; i++)
		printf("Square of %d : %d\n", i, i * i);
	
	return 0;
}
