
#include <stdio.h>

int main() {

	for(int i = 1; i <= 10; i++)
		printf("%d  ",i * 2);
	printf("\n");
	
	return 0;
}
