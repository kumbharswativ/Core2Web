for i in range(1,21):
	print("Cube of {} : {}".format(i, i * i * i))