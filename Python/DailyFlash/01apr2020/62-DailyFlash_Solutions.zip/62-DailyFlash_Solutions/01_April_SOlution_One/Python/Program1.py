st = input("Enter the string : ")
s_list=[]
s_list= st.split()

print("Longest string is :",max(s_list))
