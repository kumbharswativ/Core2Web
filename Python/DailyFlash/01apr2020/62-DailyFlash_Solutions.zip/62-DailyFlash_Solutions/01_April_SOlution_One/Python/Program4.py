
time=float(input("Enter the lenght :"))

length = (4*(3.14*3.14)*9.81)/(time*time)
print("Length  :",round(length,2))
