import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		float T;
		Scanner sc = new Scanner(System.in);
		T = sc.nextFloat();
		System.out.print("T: ");
		System.out.println((4 * 3.14 * 3.14 * 3.18) / (2 * T));
	}
}
