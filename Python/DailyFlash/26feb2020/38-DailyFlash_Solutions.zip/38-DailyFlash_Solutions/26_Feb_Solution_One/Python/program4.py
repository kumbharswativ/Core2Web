
n = int(input("Enter Number : "))
for i in range(0,n):
    for j in range(0,n-i):
        print("*", end = "\t")
    print()
	

