print("1st point  : \n")
x1 = float(input())
y1 = float(input())

print("2nd point  : \n")
x2 = float(input())
y2 = float(input())

print("Mid point : ", (x1 + x2)/2 ,",",(y1+y2)/2)