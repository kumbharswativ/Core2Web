import math
n = int(input())
m = 0
for i in range(1, n + 1):
        m += i / (math.sqrt(i)*(i + 1))
print(m)
