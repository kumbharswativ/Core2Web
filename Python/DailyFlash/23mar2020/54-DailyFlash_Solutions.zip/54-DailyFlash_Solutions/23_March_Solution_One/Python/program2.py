

ch = raw_input("Enter the string ")

for itr in range(len(ch)):
    if ch[itr]=='a' or ch[itr]=='A':
        print(str(ord(ch[itr]))+" : "+ch[itr])
    elif ch[itr]=='e' or ch[itr]=='E':
        print(str(ord(ch[itr]))+" : "+ch[itr])
    elif ch[itr]=='i' or ch[itr]=='I':
        print(str(ord(ch[itr]))+" : "+ch[itr])
    elif ch[itr]=='o' or ch[itr]=='O':
        print(str(ord(ch[itr]))+" : "+ch[itr])
    elif ch[itr]=='U' or ch[itr]=='u':
        print(str(ord(ch[itr]))+" : "+ch[itr])
