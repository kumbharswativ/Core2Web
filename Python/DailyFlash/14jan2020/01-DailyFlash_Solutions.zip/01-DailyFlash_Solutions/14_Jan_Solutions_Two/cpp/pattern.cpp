/*

Program 4: Write a Program to Print following Pattern

1 1 1 1
1 1 1 1
1 1 1 1
1 1 1 1


*/

#include<iostream>

int main(){

	for(int i =0;i<=4;i++){

		for(int j=0;j<=4;j++)
			std::cout<<"1 ";
		std::cout<<"\n";

	}	

}	
