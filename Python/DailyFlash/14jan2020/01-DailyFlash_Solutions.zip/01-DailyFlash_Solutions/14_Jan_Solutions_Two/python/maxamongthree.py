
"""

Program 5: Write a Program to Find Maximum between three numbers
Input: 1 4 2
Output: 4 is Max number among 1, 4 & 2


"""


a = 1
b = 4
c = 3

if a>b and a>c:
    print("a is max than b and c")
elif b>a and b>c:
    print("b is max than a and c")
else:
    print("c is max than b and c")
