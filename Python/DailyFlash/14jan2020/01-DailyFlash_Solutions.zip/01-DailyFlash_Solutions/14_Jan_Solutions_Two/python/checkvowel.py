
"""

Program 2: Write a Program to check whether the Character is Vowel or
Consonant.
Input: E
Output: E is a Vowel.

"""


ch= 'E'

if ch=='a' or ch=='A':
    print(ch+" is vowel")
elif ch=='e' or ch=='E':
    print(ch+" is vowel")
elif ch=='i' or ch=='I':
    print(ch+" is vowel")
elif ch=='o' or ch=='O':
    print(ch+" is vowel")
elif ch=='u' or ch=='U':
    print(ch+" is vowel")
else:
    print(ch+" is consonant")
