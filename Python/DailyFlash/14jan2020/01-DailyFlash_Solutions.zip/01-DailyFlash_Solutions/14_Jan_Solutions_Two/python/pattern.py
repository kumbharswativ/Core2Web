"""

Program 4: Write a Program to Print following Pattern
1 1 1 1
1 1 1 1
1 1 1 1
1 1 1 1

"""


for x in range(4):
    print("1 "*4)
