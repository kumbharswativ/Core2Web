
"""

Program 1: Write a Program to check whether the Character is Alphabet or
not.
Input: v
Output: v is an alphabet.

"""


ch = '*'

if (ch>='A' and ch<='Z') or (ch>='a' and ch<='z'):
    print(ch+" is alphabet")
else:
    print(ch+" is not alphabet")
