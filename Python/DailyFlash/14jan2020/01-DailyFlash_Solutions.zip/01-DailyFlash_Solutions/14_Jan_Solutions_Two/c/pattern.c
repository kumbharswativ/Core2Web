/*

Program 4: Write a Program to Print following Pattern

1 1 1 1
1 1 1 1
1 1 1 1
1 1 1 1


*/

#include<stdio.h>

void main(){

	for(int i =0;i<=4;i++){

		for(int j=0;j<=4;j++)
			printf("1 ");
		printf("\n");

	}	

}	
