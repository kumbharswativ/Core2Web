#include<stdio.h>

void main(){
	
	printf("%c",48);
}	
