ch = input("Input : ")
print("Output : Alphabet") if ch>='A' and ch<='Z' or ch>='a' and ch<='z' else print("Not alphabet")
