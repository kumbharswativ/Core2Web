n1, n2, n3 = input("Input : ").split()
print("Output : ", n1) if n1>n2 and n1>n3 else print("Output : ", n2) if n2>n3 else print("Output : ", n3)
