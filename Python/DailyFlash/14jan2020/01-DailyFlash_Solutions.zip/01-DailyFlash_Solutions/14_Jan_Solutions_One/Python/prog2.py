ch = input("Input : ")
print("Output : Vowel") if ch=='A' or ch=='E' or ch=='I' or ch=='O' or ch=='U' or ch=='a' or ch=='e' or ch=='i' or ch=='o' or ch=='u' else print("Output : Consonent") if ch>='A' and ch<='Z' or ch>='a' and ch<='z' else print("Output : Not a vowel or consonent")
