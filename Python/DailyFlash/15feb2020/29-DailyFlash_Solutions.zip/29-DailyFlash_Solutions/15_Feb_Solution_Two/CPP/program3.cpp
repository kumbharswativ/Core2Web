
#include <iostream>

int main () {
	int n;
	std::cout << ("Enter Number: ");
	std::cin >> n;
	while(n!=0){
		std::cout << "The Square of " << n%10 << " : " << (n%10)*(n%10) << std::endl;
		n = n / 10;
	}
}
