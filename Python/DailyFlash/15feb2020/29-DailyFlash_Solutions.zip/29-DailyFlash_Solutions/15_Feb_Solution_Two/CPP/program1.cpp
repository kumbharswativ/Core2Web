
#include <iostream>

int main () {
	int n, flag;
	std::cout << ("Enter Number: ");
	std::cin >> n;

	while(n!=0){
		flag = 0;
		for(int i = 2; i<= (n%10)/2; i++){
			if((n%10) % i == 0){
				flag = 1;
			}
		}
		if(flag == 0){
			std::cout << (n%10) << " ";
		}
		n = n / 10;
	}
	std::cout << ("\n");
}
