
#include <iostream>

int main () {
	int n, flag;
	std::cout << ("Enter Number: ");
	std::cin >> n;
	int temp = n;
	n = 0;
	while(temp!= 0){
		n  = n * 10 + temp % 10;
		temp = temp/10;
	}
	int fact;
	while(n!=0){
		fact = 1;
		for(int i = 1; i<= n%10; i++){
			fact = fact * i;
		}
		std::cout << ("The Factorial of") << (n % 10) << " : " << fact << std::endl;
		n = n / 10;
	}
}
