
import java.io.*;

class Program {
	public static void main (String ... kbd) throws IOException{
		int n;
		System.out.printf("Enter Number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());

		int temp = n;
		n = 0;
		while(temp!= 0){
			n  = (n * 10) + (temp % 10);
			temp = temp/10;
		}
		
		while(n!=0){
			System.out.printf("The Square of %d : %d\n", (n % 10),(n % 10) * (n % 10));	
			n = n / 10;
		}
	}
}
