
import java.io.*;
class Program {

	public static void main(String[] args) throws IOException{
	
		int n;
		System.out.printf("Enter Number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());

		if(n<0)
			return;
		int fact = 1;
		while(n != 0){
			fact = 1;
			for(int i = 1; i<= n%10; i++){
				fact = fact * i;
			}
			System.out.printf("The Factorial of %d : %d\n", (n % 10),fact);
			n = n / 10;
		}	
	}
}
