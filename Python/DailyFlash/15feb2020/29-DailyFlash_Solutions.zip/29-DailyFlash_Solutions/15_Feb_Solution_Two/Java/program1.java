
import java.io.*;

class Program {
	public static void main (String ... kbd) throws IOException{
		int n, flag;
		System.out.printf("Enter Number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		
		while(n!=0){
			flag = 0;
			for(int i = 2; i<= (n%10)/2; i++){
				if((n%10) % i == 0){
					flag = 1;
				}
			}
			if(flag == 0){
				System.out.printf("%d ",n%10);
			}
			n = n / 10;
		}
	}
}
