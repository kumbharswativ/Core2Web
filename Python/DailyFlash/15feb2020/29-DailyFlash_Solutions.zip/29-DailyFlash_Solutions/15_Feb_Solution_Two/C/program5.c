
#include <stdio.h>

void main () {
	int n, flag;
	printf("Enter Number: ");
	scanf("%d", &n);
	int temp = n;
	n = 0;
	while(temp!= 0){
		n  = n * 10 + temp % 10;
		temp = temp/10;
	}
	int fact;
	while(n!=0){
		fact = 1;
		for(int i = 1; i<= n%10; i++){
			fact = fact * i;
		}
		printf("The Factorial of %d : %d\n", (n % 10),fact);
		n = n / 10;
	}
}
