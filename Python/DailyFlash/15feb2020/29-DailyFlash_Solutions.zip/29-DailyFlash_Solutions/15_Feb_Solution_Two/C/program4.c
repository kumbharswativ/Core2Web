
#include <stdio.h>

int main () {
	
	int n;
	printf("Enter Size : ");
	scanf("%d", &n);
	int k = (n*(n+1))/2;
	for(int i = 1; i <= n; i++){
		for(int j = n; j >= 1 ; j--){
			if(j > i){
				printf("\t");
			}
			else{
				printf("%d\t",k*k);
				k--;
			}
		}
		printf("\n");
	}	
}
