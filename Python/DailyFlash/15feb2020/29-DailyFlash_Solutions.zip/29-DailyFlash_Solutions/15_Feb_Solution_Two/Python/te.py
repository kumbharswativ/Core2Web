l = [1,2]
print(l)
l.extend([1,2])
print(l)
