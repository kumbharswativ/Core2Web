
try:
	n = int(input("Enter Number : "))
except ValueError as e:
	exit(0)

if(n<0):
	exit(0)
while(n != 0):
	print("Square : " , (n%10)*(n%10))	
	n = n // 10

