cnt = 0
c=0
print("Enter Hex Number : ")
n = input()
j = 0
total = list()
while j < len(n):
	bin = list()
	if(ord(n[j]) >= 71):
		print("Not a Hex Number\n")
		exit(0)
		
	if(ord(n[j]) <= 57):
		i = ord(n[j]) - 48
	else:
		i = ord(n[j]) - 55
	c = 0
	while(c < 4):
		bin.append(chr(i%2 + 48))
		i = i // 2
		cnt+=1
		c+=1
	bin.reverse()
	total.extend(bin);	
	j+=1
	
l = len(total)
num = 0
ct = 0
j = 0
i = l % 3
if(i != 0):
	while(j < (l % 3)):
		num = num*2 + (ord(total[j])-ord('0'))
		j+=1	
		
	print(num, end ="")

num = 0
while(i < l):
	num = num*2 + (ord(total[i])-ord('0'))
	i+=1
	ct+=1
	if(ct == 3):
		ct = 0
		if(num<=9):
			print(chr(num+48), end = "")
			
		else:
			print(chr(num+55), end = "")
			
		num = 0
		
		
print()


