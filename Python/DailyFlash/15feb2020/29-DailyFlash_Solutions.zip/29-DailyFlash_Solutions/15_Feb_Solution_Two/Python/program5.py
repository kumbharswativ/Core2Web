
try:
	n = int(input("Enter Number : "))
except ValueError as e:
	exit(0)

if(n<0):
	exit(0)
while(n != 0):
    fact = 1
    for i in range(1,(n%10)+1):
        fact = fact *(i)
    print(fact)
    n = n // 10

