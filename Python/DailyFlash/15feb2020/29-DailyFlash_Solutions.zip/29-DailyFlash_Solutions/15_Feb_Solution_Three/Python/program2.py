num = int(input(),16)

print(oct(num))

"""
output (use python3)
0x13
0o23
"""
