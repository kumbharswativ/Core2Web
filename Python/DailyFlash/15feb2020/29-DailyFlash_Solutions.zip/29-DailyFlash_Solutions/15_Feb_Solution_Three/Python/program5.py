

num = input("Enter the number : ")

while num!=0:

    rem = num%10
    fact =1

    for itr in range(2,rem+1):
        fact = fact*itr

    print(fact)
    num = num/10
