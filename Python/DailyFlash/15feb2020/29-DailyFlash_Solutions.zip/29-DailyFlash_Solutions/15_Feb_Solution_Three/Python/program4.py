
num = 10

for itr in range(4):
    for jtr in range(4):
        if jtr<3-itr:
            print("\t",end="")
        else:
            print(num*num,end="\t")
            num  = num - 1
    print("")        
