

num = input("Enter the number : ")

rem = 0 

while num!=0:
    rem = num%10

    print(str(rem*rem))

    num = num/10
