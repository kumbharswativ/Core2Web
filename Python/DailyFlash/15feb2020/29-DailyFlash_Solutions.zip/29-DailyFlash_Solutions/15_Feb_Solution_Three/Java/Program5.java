import java.io.*;


class Program5{

	
	public static void main(String args[])throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int num = Integer.parseInt(br.readLine());

		while(num!=0){
			int rem = num%10;
			int fact =1;
			for(int itr = 2 ;itr<=rem ; itr++){
				fact = fact*itr;
			}	

			System.out.printf("Factorial of %d = %d\n",rem,fact);
			num = num/10;

		}

	}	
}	
