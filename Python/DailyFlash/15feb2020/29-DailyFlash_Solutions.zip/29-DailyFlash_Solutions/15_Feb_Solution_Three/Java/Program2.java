import java.io.*;


class Program2{

	
	public static void main(String args[])throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	String hex = br.readLine();


	
	int bin=011;
	int place = 011;
	for(int i =0; i<hex.length();i++){

		bin = bin*place;

			switch(hex.charAt(i)){

				case '0':
					bin=bin+0;
					break;
				case '1':
					bin=bin+1;
					break;
				case '2':
					bin=bin+10;
					break;
				case '3':
					bin=bin+11;
					break;
				case '4':
					bin=bin+100;
					break;
				case '5':
					bin=bin+101;
					break;
				case '6':
					bin=bin+110;
					break;
				case '7':
					bin=bin+111;
					break;
				case '8':
					bin=bin+1000;
					break;
				case '9':
					bin=bin+1001;
					break;
				case 'A':
				case 'a':
					bin=bin+1010;
					break;
				case 'B':
				case 'b':
					bin=bin+1011;
					break;
				case 'C':
				case 'c':
					bin=bin+1100;
					break;
				case 'D':
				case 'd':
					bin=bin+1101;
					break;
				case 'E':
				case 'e':
					bin=bin+1110;
					break;
				case 'F':
				case 'f':
					bin=bin+1111;
					break;
				default:
					System.out.printf("Invalid");

			}
			place=10000;

			
	

		}

		int rem=0,val=0,place1=1,octal=011;
		while(bin>0){

			rem = bin%1000;
	
			switch(rem){

				case 0 :
					val=0;
					break;
				case 1:
					val =1;
					break;
				case 10:
					val =2;
					break;
				case 11:
					val =3;
					break;
				case 100:
					val=4;
					break;
				case 101:
					val =5;
					break;
				case 110:
					val=6;
					break;
				case 111:
					val=7;
					break;
			}
			octal = (val*place1)+octal;
			bin=bin/1000;

			place1 =place1*10;

		}

		System.out.printf("%d",octal);
	}	
}	
