import java.io.*;


class Program3{

	
	public static void main(String rags[])throws IOException{
		
		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));

		int num = Integer.parseInt(br.readLine());

		int rem=0;
		while(num!=0){
			rem = num%10;

			System.out.printf("Square of %d = %d\n",rem,rem*rem);

			num = num/10;

		}
	}	
}	
