

class Program4{

	
	public static void main(String rag[]){
		
		int num =10;
		for(int itr =0 ;itr<4;itr++){

			for(int jtr = 0; jtr<4;jtr++){

				if(jtr<3-itr){

					System.out.printf("\t");
				}else{
					System.out.printf("%d\t",num*num);
					num = num -1;
				}
			}
			System.out.printf("\n");
		}

	}	
}	
