#include<iostream>


int main(){
	
	int num;
	printf("Enter the number\n");
	scanf("%d",&num);

	while(num!=0){
		int rem = num%10;
		int fact =1;
		for(int itr = 2 ;itr<=rem ; itr++){
			fact = fact*itr;	
		}	

		printf("Factorial of %d = %d\n",rem,fact);
		num = num/10;

	}	
	
}	
