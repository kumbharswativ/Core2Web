#include<iostream>


int main(){
	
	int num =10;
	for(int itr =0 ;itr<4;itr++){

		for(int jtr = 0; jtr<4;jtr++){
			
			if(jtr<3-itr){
				
				printf("\t");
			}else{
				printf("%d\t",num*num);
				num--;
			}		
		}	
		printf("\n");	
	}	
	
}	
