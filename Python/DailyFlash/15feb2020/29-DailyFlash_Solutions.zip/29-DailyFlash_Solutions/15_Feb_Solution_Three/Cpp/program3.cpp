#include<iostream>


int main(){

	int num;

	printf("Enter the number : ");
	scanf("%d",&num);


	int rem=0;
	while(num!=0){
		rem = num%10;

		printf("Square of %d = %d\n",rem,rem*rem);

		num = num/10;	

	}	
}	
