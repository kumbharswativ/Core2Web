#include<iostream>


int main(){
	
	int num;

	printf("Enter the number\n");
	scanf("%d",&num);


	int prime[65];
	int rem = 0;
	int jtr =0 ;
	while(num!=0){
		
		rem = num%10;
		int flag = 0;
		for(int itr = 2 ; itr<=rem/2 ; itr++ ){
		
			if(rem%itr==0){
				flag = 1;
			}		
		}	

		if(flag==0){
			
			prime[jtr++]=rem;
				
		}
		num = num/10;	


	}	
	
	printf("Prime numbers\n");
	for(int itr = jtr-1;itr>=0;itr--){
		
		printf("%d",*(prime+itr));
	}	
	
}	
