#include<iostream>

int main(){
	
	char hex[65];

	printf("Enter the number : ");
	scanf("%s",hex);
	int i= 0;
	int bin=011;
	int place = 011;
	while(hex[i]!='\0'){
		
		bin = bin*place;

		switch(hex[i]){
			
			case '0':
				bin+=0;
				break;
			case '1':
				bin+=1;
				break;
			case '2':
				bin+=10;
				break;
			case '3':
				bin+=11;
				break;
			case '4':
				bin+=100;
				break;
			case '5':
				bin+=101;
				break;
			case '6':
				bin+=110;
				break;
			case '7':
				bin+=111;
				break;
			case '8':
				bin+=1000;
				break;
			case '9':
				bin+=1001;
				break;
			case 'A':
			case 'a':
				bin+=1010;
				break;
			case 'B':
			case 'b':
				bin+=1011;
				break;
			case 'C':
			case 'c':
				bin+=1100;
				break;
			case 'D':
			case 'd':
				bin+=1101;
				break;
			case 'E':
			case 'e':
				bin+=1110;
				break;
			case 'F':
			case 'f':
				bin+=1111;
				break;
			default:
				printf("Invalid");		
		
		}	
		place=10000;

		i++;

		
	}	

	int rem=0,val,place1=1,octal=011;
	while(bin>0){
		
		rem = bin%1000;

		switch(rem){
			
			case 0 :
				val=0;
				break;
			case 1:
				val =1;
				break;
			case 10:
				val =2;
				break;
			case 11:
				val =3;
				break;
			case 100:
				val=4;
				break;
			case 101:
				val =5;
				break;
			case 110:
				val=6;
				break;
			case 111:
				val=7;
				break;		
		}	
		octal = (val*place1)+octal;
		bin/=1000;

		place1 *=10;
		
	}	

	printf("%d",octal);

}	
