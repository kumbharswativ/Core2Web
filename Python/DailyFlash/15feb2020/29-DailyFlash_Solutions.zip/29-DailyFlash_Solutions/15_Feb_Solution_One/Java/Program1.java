/*
 * Problem Statement
 *
 * 	Program1 -- Write a Program to Convert entered Hexadecimal Number to Octal Number.
*/


//Import io package for all Input Output Operations
import java.io.*;

//User defined class to convert Hexadecimal Number to Octal
class Octal {

	//Entry Point Function main, throws IOException as the readLine method of BufferedReader throws Exception
	public static void main(String[] args) throws IOException {

		//To make a connection between Java code and Keyboard for Input 
		BufferedReader b = new BufferedReader(new InputStreamReader(System.in));

		/* 
		 * Declarations
		 * int Variable
		 * num_input_1 - To store User Input
		 *
		 * */

		int num_input_1 = 0;

		/*
		 * Test Conditions
		 * Condition1 - Number Should be greater than 0 
		 * Condition2 - Only HexaDecimal Characters are allowed
		 * 
		 * */

		//do-while loop to take user input till all conditions are true
		do {
			System.out.println("Enter Hexadecimal Number");

			//Try-catch to Handle input other than String 
			try {
				//parseInt - static method to convert input string into integer with base specified, 16 for Hexadecimal
				num_input_1 = Integer.parseInt(b.readLine(),16);
				
				if(num_input_1 <= 0)
					System.out.println("Enter Positive values Only");

			}
			catch(NumberFormatException n){

				System.out.println("Invalid, Enter in Proper Format");
			}

		}while(num_input_1 == 0);

		//Convert the Hexadecimal number to Octal String
		String octal = Integer.toOctalString(num_input_1);	

		//Print the Octal value of the Hexadecimal Strinng
		System.out.println("Octal Value is "+octal);	

	}
}
