'''
Problem Statement

Program3 -- Write a Program to Print the following pattern. 

 	 	 	100	
 	 	81	64	
	49	36	25	
16	9	4	1	
'''

rows = int(input("Enter The number of rows\n"))

last = 0
count = 0

for l in range(rows+1) :
    count = count + l

for c in range(count) :
    last = last + 1

for x in range(rows) :

    for y in range(rows):

        if( x+y < (rows-1)) :

            print(" \t",end="",sep='')
        elif( x+y >= (rows-1)) :

            print(last*last,"\t",end="",sep='')
            last = last - 1
    print()
