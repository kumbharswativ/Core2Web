'''
Problem Statement


	Program4 -- Write a Program that takes a number as input from user and prints the Squares of each digit.
'''

num=input("Enter a Number\n:")[::-1]

temp = int(num)

while(temp > 0):

    digit = temp%10

    print("Square of ",digit," = ",digit*digit)
    temp = temp//10

