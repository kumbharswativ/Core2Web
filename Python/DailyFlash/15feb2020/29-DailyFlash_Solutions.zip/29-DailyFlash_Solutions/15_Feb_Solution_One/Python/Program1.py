'''
Problem Statement


Program1 -- Write a Program to Convert entered Hexadecimal Number to Octal Number.
'''

hexdec = input("Enter number in Hexadecimal Format: ");

decimal = int(hexdec, 16);
octal = oct(decimal)

print(hexdec,"in Octal =",str(octal));
