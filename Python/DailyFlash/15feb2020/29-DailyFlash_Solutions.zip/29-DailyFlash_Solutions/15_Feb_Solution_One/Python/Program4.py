'''
Problem Statement


	Program4 -- Write a Program that takes a number as input from user and prints the factorials of each digit.
'''

num=input("Enter a Number\n:")[::-1]

temp = int(num)

while(temp > 0):

    fact = 1
    digit = temp%10

    for f in range(1,digit+1):
        fact = fact*f
    print("Factorial of ",digit," = ",fact)
    temp = temp//10

