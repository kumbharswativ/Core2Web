/* Problem Statement
 *
 * Program3 -- Write a Program to Print following Pattern.
 *						100
 *					81	64
 *				49	36	25
 *			16	9	4	1
 *
 * */
 
//Include Header File for all input output Operations
#include <iostream>

/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - int
 * Function Arguments - void
 * */

int main() {

	/*
	 * Declarations
	 * rows - Integer type variable for user input of rows 
	 * */
	int rows,lastNum = 0,numCount = 0;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - All values should be greater than 0
	 * Condition 2 - Only Integer inputs are allowed
	 * */
	do {
		std::cout<<"Enter Number of Rows"<<std::endl;
		/*
		 * if there is character input the cin returns 0, Hence for unsuccesfull return of cin execute
		 * */
		std::cin>>rows;
		if(!std::cin.fail()){

			std::cout<<"Character Inputs not allowed, Enter Positive Integers only"<<std::endl;

		}
		//else-if statement if Condition 1 is false
		else if(rows <= 0){

			std::cout<<"Invalid, Only Positive values allowed"<<std::endl;
		}

	}while(rows <= 0 && !std::cin.fail());

	for(int lc = 1; lc <= rows; lc++){
		
		numCount+=lc;
	}
	for(int lc = 1; lc <= numCount; lc++)
		lastNum = lc;
	printf("%d\n",lastNum);

	std::cout<<"The output of Pattern is "<<std::endl;

	//Outer for loop is for Number of Rows
	for(int olc = 0; olc < rows; olc++){

		//Inner for loop is for Number of Columns
		for(int ilc = 0; ilc < rows; ilc++){

			if (olc+ilc < rows-1)

				std::cout<<" \t";
			else {
				std::cout<<(lastNum*lastNum)<<"\t";
				lastNum--;
			}		

		}

		std::cout<<std::endl;
	}

	return 0;
}




/*
 * Dry Run of For Loop 1 for numCount
 * Let input = rows = 4
 * Consider F - False Conditions and T - True Conditions
 *
 * Initialisation	Condition	Operation-1		lc++		numCount 		
 *
 * 1]  lc = 1		1 <= 4 T	0 + 1			2		1
 * 			2 <= 4 T	1 + 2			3		3
 * 			3 <= 4 T	3 + 3			4		6
 * 			4 <= 4 T	6 + 4			5		10
 * 			5 <= 4 F 	Exit
 *
 * 
 * Dry Run of For Loop 2 for lastNum
 * Let input = rows = 4
 * numCount = 10 (From previos calculations)
 * Consider F - False Conditions and T - True Conditions
 *
 * Initialisation	Condition	Operation-1		lc++
 * 					lastNum		
 *
 * 1] lc = 1		1  <= 10 T	1			2
 * 			2  <= 10 T	2			3
 * 			3  <= 10 T	3			4
 * 			4  <= 10 T	4			5
 * 			5  <= 10 T	5			6
 * 			6  <= 10 T	6			7
 * 			7  <= 10 T	7			8
 * 			8  <= 10 T	8			9
 * 			9  <= 10 T	9			10
 * 			10 <= 10 T	10			11
 * 			11 <= 10 F	Exit			
 *
 *
 * Dry Run of Outer For loop for Actual Pattern
 * Let input = rows = 4
 * lastNum = 10 (From previous Calculations)
 * Consider F - False Conditions and T - True Conditions
 *
 * Initialisation	Condition	Operation-1		
 * 					Inner For Loop	 					(After		(Printing)		olc++
 * 					Initialisation		Condition	If-Condition 	Print)		Operation-2	ilc++  	(olc)
 *										Operation-1	lastNum				(ilc)	
 *
 * 1] olc = 0		0 < 4 T		ilc = 0			0 < 4 T		0+0 < 3 T	-		'  \t'		1
 * 								1 < 4 T		0+1 < 3 T	-		'  \t'		2
 * 								2 < 4 T		0+2 < 3 T	-		'  \t'		3
 * 								3 < 4 T		0+3 < 3 F	9		'100\t'		4
 * 								4 < 4 T		Exit				'\n'			1
 * 
 * 2] olc = 1		1 < 4 T		ilc = 0			0 < 4 T		1+0 < 3 T	-		'  \t'		1
 * 								1 < 4 T		1+1 < 3 T	-		'  \t'		2
 * 								2 < 4 T		1+2 < 3 F	8		'81\t'		3
 * 								3 < 4 T		1+3 < 3 F	7		'64\t'		4
 * 								4 < 4 T		Exit				'\n'			2
 *
 * 3] olc = 2		2 < 4 T		ilc = 0			0 < 4 T		2+0 < 3 T	-		'  \t'		1
 * 								1 < 4 T		2+1 < 3 F	6		'49\t'		2
 * 								2 < 4 T		2+2 < 3 F	5		'36\t'		3
 * 								3 < 4 T		2+3 < 3 F	4		'25\t'		4
 * 								4 < 4 T		Exit				'\n'			3
 *
 * 4] olc = 3		3 < 4 T		ilc = 0			0 < 4 T		3+0 < 3 T	3		'16\t'		1
 * 								1 < 4 T		3+1 < 3 T	2		' 9\t'		2
 * 								2 < 4 T		3+2 < 3 T	1		' 4\t'		3
 * 								3 < 4 T		3+3 < 3 T	0		' 1\t'		4
 * 								4 < 4 T		Exit				'\n'			4
 *
 * 5] olc = 4		4 < 4 F	Exit
 * 
 * */
