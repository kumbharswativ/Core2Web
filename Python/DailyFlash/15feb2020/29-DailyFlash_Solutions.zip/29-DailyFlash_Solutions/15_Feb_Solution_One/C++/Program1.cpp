/* Problem Statement
 *
 * Program1 -- Write a Program to Convert entered Hexadecimal Number to Octal Number.
 *
 * */


//Include Header File for all input output Operations
#include<iostream>

/*
 * power function to calculate exponention of the form number^index
 * Function name - power
 * Function return type - int
 * Function arguments - int,int
 * 	1) number - The number whose exponention need to be calculated
 * 	2) index - The value of exponent
 * */

int power(int number, int index){

	int answer = 1;
	//while to calculate exponention value from the 0 to the specified Index
	while(index > 0){

		answer*=number;
		index--;
	}
	return answer;
}


/* 
 * Entry Point function main
 * Function Name - main
 * Function Return Type - int
 * Function Arguments - void
 * */

int main() {

	/*
	 * Declarations
	 * type - int
	 * flag - to set flag for while loop
	 * pow - To keep the count of index
	 * decimal - to store decimal value
	 * octal - to store octal value
	 * tmp - temporary variable for calculations
	 *
	 * character Array HexString - To store User Input For Hexadecimal Value
	 * char *temp - temporary character pointer for operations on string
	 * */

	int flag = 1,pow = -1,decimal = 0;
	char HexString[50];
	char *temp;

	/*
	 * Use of do-while loop till all the conditions are true
	 * Condition 1 - Only Integer inputs and HexaDecimal Characters are allowed
	 * */
	do {
		std::cout<<"Enter a HexaDecimal Number "<<std::endl;

		std::cin>>HexString;
		pow = -1;
		
		//temp charachter pointer to navigate within the entered string to check for each character
		char* temp = HexString;
		
		//While loop to verify the user input for Hexadecimal Characters
		while(*temp != '\0'){

			if( (*temp >= 65 && *temp <= 70) || (*temp >= 48 && *temp <= 57 ) ){

				pow++;
				//If all the characters are Hexadecimal then exit the loop using flag = 0
				flag = 0;
			}
			else { 
				//If anyone of the characters is not Hexadecimal then repeat user input by using flag = 1
				flag = 1;
				std::cout<<"Entered Number is not a Hexadecimal Number"<<std::endl;
				//Break the loop at the first non-HexaDecimal Character
				break;
			}
			temp++;
		}

	}while(flag);

	temp = HexString;
	
	//While loop to tokenize the string and calculate decimal value for each character in HexaDecimal String
	while(*temp != '\0'){

		//If the character is of Integer type then calculate by converting ASCII to equivalent integer value
		if( (*temp >= 48 && *temp <= 57 ) ){

			decimal = decimal + ((*temp-48) * (power(16,pow)));

		}
		//If the Character is a HexaDecimal Character then convert it into its equivalent Integer value
		else {
			decimal = decimal + ((*temp-55) * power(16,pow));
		}
		pow--;
		temp++;
	}
	int temp1 = decimal;
	int octal = 0;
	pow = 0;

	//While Loop to convert Decimal Number into Octal Number
	while(temp1 > 0){

		octal = octal + ((temp1%8)*power(10,pow));
		pow++;
		temp1/=8;
	}

	//Print the resulting Octal Value of The Entered HexaDecimal String
	std::cout<<"The Octal Number of "<< HexString <<" is "<< octal<<std::endl;;
	
	return 0;
}


