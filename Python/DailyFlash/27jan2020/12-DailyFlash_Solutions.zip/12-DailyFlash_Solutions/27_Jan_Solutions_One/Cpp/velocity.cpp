#include<iostream>

int main(){

	int dist,time;

	printf("Distance: ");
	scanf("%d",&dist);

	printf("Time: ");
	scanf("%d",&time);

	printf("The Velocity of Particle roaming in space is %dm/s",(dist/time));

}	
