distance = input("Enter the Distance ")
time = input("Enter the Time ")

print("Velocity of particle is "+str(distance/time)+" m/s")
