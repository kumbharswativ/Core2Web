lowerlimit = input("Enter the lower limit : ")
upperlimit = input("Enter the upper limit : ")



for itr in range(lowerlimit,upperlimit+1):
    if itr%2==0:
        print(itr)

