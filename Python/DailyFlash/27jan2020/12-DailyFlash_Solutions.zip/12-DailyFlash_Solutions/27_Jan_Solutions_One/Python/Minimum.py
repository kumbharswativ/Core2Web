num = input("Enter the number1 : ")
num2 = input("Enter the number2: ")

if num < num2 :
    print(str(num)+" is minimum");
else:
    print(str(num2)+" is minimum");
   
