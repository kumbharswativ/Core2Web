
num=1;
for itr in range(0,4):
    for inner in range(0,itr+1):
        print(num*num,end=" ")
        num = num + 1;
    print("")    
