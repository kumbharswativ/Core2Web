
print("Enter Numbers : ")
for i in range(1,11):
	n = int(input())
	if(n<0):
		break
