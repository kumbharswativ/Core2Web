while(True):
    if(int(input()) < 0):
        break
