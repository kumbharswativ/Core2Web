#include<stdio.h>


void main(){

	int num;
	while(1){
		scanf("%d",&num);
		
		if(num<0)
			break;	
		
	}	
	printf("NEgative number bro/sis");
}	
