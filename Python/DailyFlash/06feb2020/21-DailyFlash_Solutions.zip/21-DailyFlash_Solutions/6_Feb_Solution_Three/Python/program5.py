temp = 0
itr = 1
while(itr<5):

    num= input()

    if(temp>num):
        print("Loop is exited")
        break
    temp = num
    itr = itr + 1
