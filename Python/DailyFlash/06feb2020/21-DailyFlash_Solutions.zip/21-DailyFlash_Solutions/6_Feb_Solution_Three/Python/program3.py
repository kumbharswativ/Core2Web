
while(1):
    num = input();
    if num<0:
        print("Negative number")
        break
