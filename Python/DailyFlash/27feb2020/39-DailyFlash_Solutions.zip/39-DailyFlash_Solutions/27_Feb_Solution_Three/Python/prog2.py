import math
a = float(input("Enter area : "))
print("Rad : ", math.sqrt(a / 3.14))
