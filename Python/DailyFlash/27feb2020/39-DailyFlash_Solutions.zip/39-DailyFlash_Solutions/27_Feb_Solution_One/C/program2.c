
#include <stdio.h>
#include <math.h>

main() {

	float n;
	printf("Enter Area : ");
	scanf("%f", &n);
	printf("Radius : %funits\n", sqrt(n / 3.142));

}
