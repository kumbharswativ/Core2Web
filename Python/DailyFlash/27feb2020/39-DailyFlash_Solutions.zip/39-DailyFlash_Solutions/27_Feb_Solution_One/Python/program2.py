import math
print("Radius : ", math.sqrt(float(input("Enter Area : ")) / 3.142))
