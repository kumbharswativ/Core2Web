
#include <iostream>
#include <math.h>

main() {

	float n;
	std::cout << ("Enter Area : ");
	std::cin >> n;
	std::cout << ("Radius : ") << sqrt(n / 3.142) << std::endl;

}
