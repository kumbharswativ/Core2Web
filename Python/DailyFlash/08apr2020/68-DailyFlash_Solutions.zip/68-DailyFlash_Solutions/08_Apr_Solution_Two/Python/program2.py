
sstr = input("Enter String : ")
substr = input("Enter SubString : ")
if(substr in sstr):
    print("String found")
else:
    print("string not found")
