"""
Program 1: Write a program to print First 10 Natural Numbers.
Output: 1 2 3 4 5 6 8 9 10

"""

print("First 10 Natural Number")

for itr in range(1,11):
    print(itr)
