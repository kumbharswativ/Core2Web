"""
Program 5 : Write a Program to print following Pattern.
Output :
0 0 0 0
0 0 0 0
0 0 0 0
0 0 0 0

"""

for outeritr in range(4):
    for inneritr in range(4):
        print("0 ",end=" ")
    print(" ")    
