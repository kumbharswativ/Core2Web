"""
Program 2 : Write a Program to print Sum of First 10 Natural Numbers.
Output: The s um of First 10 Natural Numbers : 55

"""


print("Sum of first 10 natural number")
sum1 = 0

for itr in range(1,11):
    sum1 = sum1 + itr;

print(sum1)    
