
#include <stdio.h>

void main () {
	int k = 1;

	do {
		printf("%d ", k);
		k++;
	}while(k <= 10);
	printf("\n");
}
