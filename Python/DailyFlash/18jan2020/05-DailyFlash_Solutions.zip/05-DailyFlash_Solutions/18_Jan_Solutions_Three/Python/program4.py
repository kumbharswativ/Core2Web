k = 1
m = 2
	
while(k <= 50):
	if(m % 2 == 0):
		print(m, end = ' ')
	
	m+=2
	k+=1
print()
