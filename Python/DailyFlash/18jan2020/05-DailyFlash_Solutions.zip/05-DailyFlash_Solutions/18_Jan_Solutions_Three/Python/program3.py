k = 1
m = 1
	
while(k <= 50):
	if(m % 2 == 1):
		print(m, end = ' ')
	
	m+=2
	k+=1
print()
