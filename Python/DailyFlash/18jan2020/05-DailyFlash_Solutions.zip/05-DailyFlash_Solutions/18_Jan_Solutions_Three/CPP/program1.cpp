
#include <iostream>

int main () {
	int k = 1;

	do {
		std::cout << k << " ";
		k++;
	}while(k <= 10);
	std::cout <<("\n");
}
