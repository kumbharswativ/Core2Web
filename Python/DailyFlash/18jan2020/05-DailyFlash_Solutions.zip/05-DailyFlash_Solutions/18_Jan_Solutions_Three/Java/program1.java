
class Thrashing {

	public static void main (String ... kbd) {
		int k = 1;

		do {
			System.out.printf("%d ", k);
			k++;
		}while(k <= 10);
		System.out.printf("\n");
	}
}