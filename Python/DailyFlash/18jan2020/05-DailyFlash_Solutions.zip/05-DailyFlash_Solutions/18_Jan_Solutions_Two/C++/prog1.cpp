#include<iostream>

int main() {
	std::cout << "First 10 natural numbers are : ";
	for(int i = 0; i < 10; i++) {
		std::cout << " " << i + 1;
	}
	return 0;
}
