print("First 50 even numbers : ")
for i in range(100):
    print(i + 1, end = " ") if (i + 1) % 2 == 0 else print(end = " ") 
