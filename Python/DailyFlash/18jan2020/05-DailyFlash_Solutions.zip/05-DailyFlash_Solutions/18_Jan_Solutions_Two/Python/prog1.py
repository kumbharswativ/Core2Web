print("First 10 natural numbers are :", end = " ")
for i in range(10):
    print(i + 1, end = " ")
