sum = 0
for i in range(10):
    sum += i + 1
print("Sum : ", sum)
