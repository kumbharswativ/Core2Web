print("First 50 odd numbers : ")
for i in range(100):
    print(i + 1, end = " ") if (i + 1) % 2 == 1 else print(end = " ") 
