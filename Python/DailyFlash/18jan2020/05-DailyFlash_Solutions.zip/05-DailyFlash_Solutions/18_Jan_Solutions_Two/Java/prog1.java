class Demo {
	public static void main(String[] args) {
		System.out.println("First 10 natural numbers are : ");
		for(int i = 0; i < 10; i++) {
			System.out.print((i + 1) + " ");
		}
	}
}
