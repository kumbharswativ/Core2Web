#include<stdio.h>

int main(void) {
	printf("First 10 natural numbers are : ");
	for(int i = 0; i < 10; i++) {
		printf("%d ", i + 1);
	}
	return 0;
}
