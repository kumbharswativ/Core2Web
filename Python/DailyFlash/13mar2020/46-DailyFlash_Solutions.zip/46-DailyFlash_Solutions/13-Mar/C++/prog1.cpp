#include<iostream>
#include<math.h>
int main() {
	std::cout << "Enter a num : ";
	int num;
	std::cin >> num;
	std::cout << pow(num, 1.0 / 3.0);
}
