print("CR : ", pow(int(input("Num : ")), 1 / 3))
