

sr = input("Enter a String  :\t")
st = int(input("Start\n"))
en = int(input("End\n"))

cp = sr[st:en+1]

print("Output String ",cp)
