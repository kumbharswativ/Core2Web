'''
Write a Program that calculates Diameter of a circle if user provides
the circumference covered by that circle.
'''
area=float(input("Enter the circumference of circle:"))
pi=3.142
cir=(area/pi)
print("Diameter of Circle is ",round(cir,2))
