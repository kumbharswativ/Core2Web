#include<stdio.h>

int main() {
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 4 - i; j++) {
			printf("%d%c ",i + j, 65 + j);
		}
		printf("\n");
	}
}
