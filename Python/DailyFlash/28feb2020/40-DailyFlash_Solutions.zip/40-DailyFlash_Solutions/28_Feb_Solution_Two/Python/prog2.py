c = float(input("Enter cir : "))
print("Dai : ", c / 3.142)
