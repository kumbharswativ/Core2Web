
#include <stdio.h>
#include <math.h>

main() {

	float n;
	printf("Enter Circumference : ");
	scanf("%f", &n);
	printf("Diameter : %funits\n", n / 3.142);

}
