
import math
print("1st point  : \n")
x1 = float(input())
y1 = float(input())

print("2nd point  : \n")
x2 = float(input())
y2 = float(input())

print("Distance : ", math.sqrt(pow(y2-y1,2)+ pow(x2-x1,2)))
