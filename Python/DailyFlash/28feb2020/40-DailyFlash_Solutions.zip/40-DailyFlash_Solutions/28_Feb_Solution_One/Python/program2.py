import math
print("Diameter : ", (float(input("Enter circumference : ")) / 3.142))
