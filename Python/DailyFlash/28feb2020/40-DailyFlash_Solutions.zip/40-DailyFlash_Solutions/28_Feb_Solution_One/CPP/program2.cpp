
#include <iostream>
#include <math.h>

main() {

	float n;
	std::cout << ("Enter Circumference : ");
	std::cin >> n;
	std::cout << ("Diameter : ") << n / 3.142 << "units \n";

}
