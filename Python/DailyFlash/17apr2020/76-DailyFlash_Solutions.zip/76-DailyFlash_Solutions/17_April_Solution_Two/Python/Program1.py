st1 = input("Enter a String 1\t :")
st2 = input("Enter a String 2\t :")


st1 = st1+st2

print(st1)
