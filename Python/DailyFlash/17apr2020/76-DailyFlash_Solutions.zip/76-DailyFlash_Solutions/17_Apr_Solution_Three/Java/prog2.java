import java.util.*;

class Demo {
	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);
		String str1 = sc.next();
		String str2 = sc.next();
		str1 = str1.concat(str2);
		System.out.println(str1);

	}
}
