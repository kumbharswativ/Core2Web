str1 = input()

str2 = input()

print(str1+str2)
