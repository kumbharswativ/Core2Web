
st = input("Enter String 1: ")
sub = input("Enter String 2: ")
t = st is sub
print(t)
