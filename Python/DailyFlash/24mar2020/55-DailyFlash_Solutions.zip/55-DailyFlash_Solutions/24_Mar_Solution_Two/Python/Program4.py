base  = int(input("Enter Base of Triangle : "))
height  = int(input("Enter Base of Triangle : "))
	
print("Area of triangle is ",round(base*height*0.5,2))
