

sr = input("Enter a String  :\t")

print("Lower Case String",sr.lower())

