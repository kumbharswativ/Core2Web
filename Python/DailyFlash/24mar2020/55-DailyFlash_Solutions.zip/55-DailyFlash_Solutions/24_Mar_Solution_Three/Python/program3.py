
n = int(input("Length of Array : "))
l = []
sum = 0
for i in range(0,n):
    l.append(int(input()))

print("Min" , min(l))

