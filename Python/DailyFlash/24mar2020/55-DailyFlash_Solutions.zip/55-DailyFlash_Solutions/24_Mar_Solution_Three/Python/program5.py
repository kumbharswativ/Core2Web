
print("Enter height and base")
h = int(input())
b = int(input())
area = 0.5 * b * h
print("Area : ", area)
