pie = 3.142
n = int(input("Enter Number : "))
mul = 0
factor = pie / 6
cnt = 0
while(cnt != n):
	mul = mul + factor
	cnt+=1
	
print(mul)

