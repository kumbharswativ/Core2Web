import math
n = int(input())
m = 0
for i in range(1, n + 1):
        m += (i-1)*(3.14/6)
print(m)
