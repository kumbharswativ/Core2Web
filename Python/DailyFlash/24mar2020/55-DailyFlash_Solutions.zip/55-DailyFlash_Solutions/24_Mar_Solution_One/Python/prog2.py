arr = raw_input()
for i in range(len(arr)):
    print(chr(ord(arr[i]) - 32))
