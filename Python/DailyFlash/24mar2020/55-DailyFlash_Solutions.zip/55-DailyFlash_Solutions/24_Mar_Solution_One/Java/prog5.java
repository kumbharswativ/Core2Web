import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		Float b, h;
		Scanner sc = new Scanner(System.in);
		b = sc.nextFloat();
		h = sc.nextFloat();
		System.out.println("A : " + b * h / 2);
	}

}
