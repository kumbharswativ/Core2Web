#include<iostream>
#include<math.h>
int main() {
	float b, h;
	std::cin >> b >> h;
	std::cout << b * h / 2;

}
