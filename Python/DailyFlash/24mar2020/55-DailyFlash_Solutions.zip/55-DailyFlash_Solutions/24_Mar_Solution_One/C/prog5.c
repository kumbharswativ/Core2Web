#include<stdio.h>
#include<math.h>
int main() {
	float b, h;
	scanf("%f %f", &b, &h);
	printf("%f", b * h / 2);
}
