area  = float(input("Enter Area of Triangle : "))
height  = int(input("Enter height of Triangle : "))
	
print("Base of triangle is ",round((2*area/height),2))
