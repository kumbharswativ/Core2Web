
l = int(input("Enter Angle in Degrees  :\t"))


print("Angle in Radians ",round(l*3.142/180,4))
