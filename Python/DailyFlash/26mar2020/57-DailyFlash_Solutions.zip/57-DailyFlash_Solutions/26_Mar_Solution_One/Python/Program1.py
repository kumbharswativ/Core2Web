

sr = input("Enter a String  :\t")

print("Reverse String",sr[::-1])

