s = input("Enter any String : ")
s = s[::-1]
print(s)

