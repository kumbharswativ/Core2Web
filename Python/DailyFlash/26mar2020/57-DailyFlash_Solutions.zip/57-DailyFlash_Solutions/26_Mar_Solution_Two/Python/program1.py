a = int(input("Enter angle in degrees : "))

print("radians : ", 3.142 * (a/180))


