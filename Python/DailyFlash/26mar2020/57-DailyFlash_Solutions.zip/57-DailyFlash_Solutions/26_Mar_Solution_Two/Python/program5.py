
print("Enter area and height")
area = int(input())
b = int(input())
h = (2 * area) / b
print("base : ", h)
