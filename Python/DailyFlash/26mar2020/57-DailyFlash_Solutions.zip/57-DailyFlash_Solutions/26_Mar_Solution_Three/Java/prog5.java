import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		Float A, b;
		Scanner sc = new Scanner(System.in);
		A = sc.nextFloat();
		b = sc.nextFloat();
		System.out.println("H : " + 2 * A / b);
	}

}
