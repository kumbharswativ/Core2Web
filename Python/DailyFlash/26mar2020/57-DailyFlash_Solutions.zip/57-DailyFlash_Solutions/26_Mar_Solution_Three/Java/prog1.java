import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		float deg;
		Scanner sc = new Scanner(System.in);
		deg = sc.nextFloat();
		System.out.println(deg * 3.14 / 180);
	}
}
