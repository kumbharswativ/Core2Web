#include<iostream>
#include<math.h>
int main(){
	float l;
	std::cin >> l;
	std::cout << l * 3.14 / 180;
}
