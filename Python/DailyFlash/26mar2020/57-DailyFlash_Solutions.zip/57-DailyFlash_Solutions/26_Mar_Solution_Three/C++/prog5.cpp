#include<iostream>
#include<math.h>
int main() {
	float A, b;
	std::cin >> A >> b;
	std::cout << 2 * A/ b;

}
