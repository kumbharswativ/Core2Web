#include<stdio.h>

int main() {
	float deg;
	scanf("%f", &deg);
	printf("Rad : %f", deg * 3.14 / 180);
}
