#include<stdio.h>

int main() {
	int num, n = 0;
	scanf("%d",  &n);
	int arr[n];
	for(int i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}



	for(int i = 0; i < n / 2; i++) {
		
		int t = arr[n - 1 - i];
		arr[n - 1 - i] = arr[i];
		arr[i] = t;
	}
	for(int i = 0; i < n; i++) {
		printf("%d", arr[i]);
	}

}
