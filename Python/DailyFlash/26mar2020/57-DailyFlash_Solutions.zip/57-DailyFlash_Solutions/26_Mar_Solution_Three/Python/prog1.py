import math
n = int(input())
print(n * 3.14 / 180)
