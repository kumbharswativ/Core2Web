arr = raw_input()
s = ""
for i in range(len(arr)):
    s+=arr[len(arr)- 1- i]
print(s)
