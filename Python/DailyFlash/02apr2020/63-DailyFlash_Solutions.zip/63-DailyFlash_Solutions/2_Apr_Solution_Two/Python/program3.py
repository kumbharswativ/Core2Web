
n = int(input("Enter Lenght : "))
l = list()
for i in range(0,n):
    l.append(int(input()))
l.sort(reverse = True)
print(l)
