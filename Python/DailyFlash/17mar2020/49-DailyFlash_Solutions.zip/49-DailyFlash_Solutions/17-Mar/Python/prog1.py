l = int(input("Enter num : "))
m = 1
for i in range(1, l + 1):
    m *= i * i
print(m)
