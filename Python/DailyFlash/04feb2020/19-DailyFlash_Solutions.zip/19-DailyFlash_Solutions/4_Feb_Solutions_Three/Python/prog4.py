num = 7;
for i in range(4):
    for j in range(4 - i):
        print(num, end = " ")
        num += 7
    print()
