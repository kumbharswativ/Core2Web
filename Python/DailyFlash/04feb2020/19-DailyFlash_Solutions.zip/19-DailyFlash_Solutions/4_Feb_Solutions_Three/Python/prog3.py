dist = int(input("Dist(ft) : "))
print("Dist(cm) : ", dist * 30) if dist >= 0 else print("Enter valid det.")

