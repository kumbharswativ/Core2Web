

num = input("Enter the value in feets : ")

print("Value in cm : "+str(num*30)+" cm")
