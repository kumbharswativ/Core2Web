

num = 1

for itr in range(4):
    for jtr in range(4-itr):
        print(num*7,end="\t")
        num = num +1
    print("")    
