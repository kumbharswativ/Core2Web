#include<iostream>


int main(){

	int feet ;

	printf("Enter the value  in feets : ");
	scanf("%d",&feet);

	printf("Value in cm : %d cm",feet*30);	
}	
