st = input("Enter a String \t :")
rm = input("Enter a Sub String \t :")


st = st.replace(rm,"")


print(st)
