
st = input("Enter String : ")
subst = input("Enter Sub String : ")
st = st.replace(subst, "")
print(st)


