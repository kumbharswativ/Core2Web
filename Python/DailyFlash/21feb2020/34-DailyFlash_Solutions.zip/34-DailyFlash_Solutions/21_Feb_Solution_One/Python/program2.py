
num  = input("Enter the number : ")


while num!=0:
    rem = num%10


    print(oct(rem))

    num = num/10

