
ch = ['C','O','R','E']

for itr in range(4):
    for jtr in range(4):
        print("",end="\t")if jtr<itr else print(ch[jtr],end="\t")
    print("")    
