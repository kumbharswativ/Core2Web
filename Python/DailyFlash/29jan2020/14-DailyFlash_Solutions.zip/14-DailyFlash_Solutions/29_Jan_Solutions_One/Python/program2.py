

num = input("Enter the number :  ")

print("Second Successor : "+str(num+2))
print("Second predcessor : "+str(num-2))
