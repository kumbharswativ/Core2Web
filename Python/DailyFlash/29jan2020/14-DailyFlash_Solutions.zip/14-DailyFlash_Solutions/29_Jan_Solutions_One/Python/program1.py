
num = input("Enter the number : ")

for itr in range(10,0,-1):
    print(str(num)+" x "+str(itr)+" = "+str(num*itr))
