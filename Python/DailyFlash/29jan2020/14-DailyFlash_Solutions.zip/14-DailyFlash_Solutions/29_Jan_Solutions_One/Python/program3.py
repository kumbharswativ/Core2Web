

length = input("Enter the length : ")

breadth = input("Enter the breadth : ")

print("Area of rectangle = "+str(length*breadth))
