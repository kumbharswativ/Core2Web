#include<stdio.h>


void main(){
	
	int length;
	int breadth;

	printf("Enter the length \n");
	scanf("%d",&length);

	printf("Enter the breadth\n");
	scanf("%d",&breadth);


	printf("Area of rectangle  = %d",length*breadth);
}	
