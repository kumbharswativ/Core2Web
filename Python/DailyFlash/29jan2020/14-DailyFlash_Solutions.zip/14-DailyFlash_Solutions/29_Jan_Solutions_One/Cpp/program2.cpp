#include<iostream>

int main(){
	
	int num;

	printf("Enter the number : ");
	scanf("%d",&num);

	printf("Second Successor : %d\n",num+2);
	printf("Second predcessor : %d",num-2);
}	
