#include <iostream>

int main (void){

	int n,i;
	std::cout << ("Enter Number : ");
	std::cin >> n;
	std::cout << ("Second Successor : ") << n + 2 << "\nSecond Predecessor : " << n - 2 << std::endl;
}
