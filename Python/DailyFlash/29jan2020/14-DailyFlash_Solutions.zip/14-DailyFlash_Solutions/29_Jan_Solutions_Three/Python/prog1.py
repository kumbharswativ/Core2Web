num = int(input("Num : "))
for i in range(10):
    print(num, " * ", 10 - i, " = ", num * (10 - i))
