num = int(input("Num : "))
print("succ = ", num + 2, "\npred = ", num - 2)
