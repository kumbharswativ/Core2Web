for i in range(4):
    for j in range(i + 1):
        print(3 - i + j, end = " ")
    print()
