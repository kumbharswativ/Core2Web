l = int(input("Enter len : "))
b = int(input("Enter br : "))
print("area = ", l * b) if l >= 0 and b >= 0 else print("Enter valid det.")
