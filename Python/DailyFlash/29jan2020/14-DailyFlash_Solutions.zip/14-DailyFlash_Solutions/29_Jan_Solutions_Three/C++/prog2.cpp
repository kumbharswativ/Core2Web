#include<iostream>

int main(void) {
	int num;
	std::cout << "Enter num : ";
	std::cin >> num;
	std::cout << "Second succ = " << num + 2 << "\n";
	std::cout << "Second pred = " << num - 2 << "\n";
}
