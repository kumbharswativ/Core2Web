'''
Problem Statement

Write a Program to take input length and breadth of rectangle and calculate its area.
'''

length = int(input("Enter Length in meters \n"))
breadth = int(input("Enter Breadth in meters \n"))

area = length*breadth

print("The Area of Rectangle =  ",area," m^2")
