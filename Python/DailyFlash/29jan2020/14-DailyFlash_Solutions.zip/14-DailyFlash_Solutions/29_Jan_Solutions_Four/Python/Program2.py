'''
Problem Statement

Write a Program that accepts an integer from user and prints its second successor and second predecessor.
'''

num = int(input("Enter a number \n"))

print("The Second Predecessor =  ",num-2)
print("The Second Successor =  ",num+2)
