num1 = 1
for i in range(4):
    for j in range(i + 1):
        print(num1, end = " ")
        num1 += 1
    print()

