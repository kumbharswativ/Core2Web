for i in range(4):
    for j in range(i + 1):
        print(i + 1,end = " ")
    print()

