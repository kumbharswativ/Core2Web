k = 0
print("Ending element :");
a = int(input())
print("Common difference :")
d = int(input())

while(a > 0):
	print(a, end = " ")
	a = a - d
print()