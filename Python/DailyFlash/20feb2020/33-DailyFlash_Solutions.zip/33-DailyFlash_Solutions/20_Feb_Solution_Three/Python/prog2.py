num = int(input("num : "))
while(num != 0):
    print("Hex : ", num % 10)
    num = int(num / 10)

