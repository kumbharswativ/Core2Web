import math
r = float(input("Enter r : "))
th = float(input("Enter th : "))
print("X : ",  r * math.cos(th), "\nY : ", r * math.sin(th))
