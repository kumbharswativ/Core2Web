l = int(input("l : "))
d = int(input("d : "))
while(l > 0):
    print(l, end = " ")
    l = l - d
