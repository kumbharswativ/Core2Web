
num = input("Enter the number : ")


while num!=0:
    rem = num%10;
    print(rem)
    num = num/10


