import math

angle = input("Enter the angle : ")

radius = input("Enter the radius : ")

print(radius*math.sin(angle*(3.14/180)))
print(radius*math.cos(angle*(3.14/180)))
