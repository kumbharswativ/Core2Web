

num = input("Enter the number : ")

diff = input("Enter the diff : ")

for itr in range(num,0,-diff):
    print(itr)
    
