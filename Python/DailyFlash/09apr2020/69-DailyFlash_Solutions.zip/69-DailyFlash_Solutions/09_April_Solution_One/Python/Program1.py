

sr = input("Enter a String  :\t")

if sr[::-1] == sr :
    print("Pallindrome")

