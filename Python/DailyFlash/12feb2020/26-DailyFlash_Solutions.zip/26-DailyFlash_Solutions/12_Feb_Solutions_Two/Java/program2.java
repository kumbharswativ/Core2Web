
import java.io.*;

class Program {

	static void reverse(char bin[]){
		int len = bin.length, i = 0;
		char c;
		while(i <= len/2){
			c = bin[i];
			bin[i] = bin[len-1-i];	
			bin[len-i-1] = c;
			i++;
		}
	}

	public static void main(String[] args) throws IOException{
	
		int n,i,cnt = 0, c=0;
		System.out.printf("Enter Octal Number : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		c = n;
		while(c!=0){
			c = c/10; 
			cnt++;
		}
		char bin[] = new char[cnt * 3];
		cnt = 0;
		c = 0;
		while(n != 0){
			if(n%10 >= 8){
				System.out.printf("Not a octal Number\n");
				System.exit(0);
			}
			i = n % 10;
			c = 0;
			while(c < 3){
				bin[cnt] = (char)(i%2 + 48);
				i = i / 2;
				cnt++;
				c++;
			}
			n = n / 10;
		}
		reverse(bin);
		int len = bin.length;
		int num = 0,ct = 0,j = 0;
		i = len % 4;
		if(i != 0){
			while(j < len % 4){
				num = num*2 + (bin[j]-'0');
				j++;	
			}
			System.out.printf("%d", num);
		}
		num = 0;
		while(i < len){
			num = num*2 + (bin[i]-'0');
			i++;
			ct++;
			if(ct == 4){
				ct = 0;
				if(num<=9){
					System.out.printf("%d",num);
				}
				else{
					System.out.printf("%c",num+55);
				}
				num = 0;
			}
		}	
		System.out.printf("\n");
	}
}
