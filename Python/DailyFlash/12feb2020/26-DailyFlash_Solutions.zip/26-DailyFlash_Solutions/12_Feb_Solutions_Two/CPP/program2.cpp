
#include <iostream>
#include<string.h>

void reverse(char bin[]){
	int len = strlen(bin), i = 0;
	char c;
	while(i <= len/2){
		c = bin[i];
		bin[i] = bin[len-1-i];	
		bin[len-i-1] = c;
		i++;
	}
}
int main () {

	int n,i,cnt = 0, c=0;
	char bin[20] = {'\0'};
	std::cout << ("Enter Octal Number : ");
	std::cin >> n;

	while(n != 0){
		if(n%10 >= 8){
			std::cout << ("Not a octal Number\n");
			exit(0);
		}
		i = n % 10;
		c = 0;
		while(c < 3){
			bin[cnt] = (char)(i%2 + 48);
			i = i / 2;
			cnt++;
			c++;
		}
		n = n / 10;
	}
	reverse(bin);
	int len = strlen(bin);
	len = strlen(bin);
	int num = 0,ct = 0,j = 0;
	i = len % 4;
	if(i != 0){
		while(j < len % 4){
			num = num*2 + (bin[j]-'0');
			j++;	
		}
		std::cout << (num);
	}
	num = 0;
	while(i < len){
		num = num*2 + (bin[i]-'0');
		i++;
		ct++;
		if(ct == 4){
			ct = 0;
			if(num<=9){
				std::cout << (char)(num+48);
			}
			else{
				std::cout << (char)(num+55);
			}
			num = 0;
		}
	}	
	std::cout << ("\n");
}

