
#include <iostream>

int main () {
	
	int n, k;
	std::cout << ("Enter Size : ");
	std::cin >> n;

	for(int i = 1; i <= n; i++){
		k = 3;
		for(int j = n; j >= 1 ; j--){
			if(j > i){
				std::cout << ("\t");
			}
			else{
				std::cout << k*k << "\t";
				k++;
			}
		}
		std::cout << ("\n");
	}	
}
