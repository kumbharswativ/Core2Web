
#include <stdio.h>

int main () {
	
	int n,k = 3;
	printf("Enter Size : ");
	scanf("%d", &n);

	for(int i = 1; i <= n; i++){
		k = 3;
		for(int j = n; j >= 1 ; j--){
			if(j > i){
				printf("\t");
			}
			else{
				printf("%d\t",(k*k));
				k++;
			}
		}
		printf("\n");
	}	
}
