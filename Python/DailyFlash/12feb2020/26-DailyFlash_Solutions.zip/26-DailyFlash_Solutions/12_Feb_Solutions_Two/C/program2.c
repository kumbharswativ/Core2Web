
#include <stdio.h>
#include<string.h>
void exit(int);

void reverse(char bin[]){
	int len = strlen(bin), i = 0;
	char c;
	while(i <= len/2){
		c = bin[i];
		bin[i] = bin[len-1-i];	
		bin[len-i-1] = c;
		i++;
	}
}
int main () {

	int n,i,cnt = 0, c=0;
	char bin[20] = {'\0'};
	printf("Enter Octal Number : ");
	scanf("%d", &n);

	while(n != 0){
		if(n%10 >= 8){
			printf("Not a octal Number\n");
			exit(0);
		}
		i = n % 10;
		c = 0;
		while(c < 3){
			bin[cnt] = (char)(i%2 + 48);
			i = i / 2;
			cnt++;
			c++;
		}
		n = n / 10;
	}
	reverse(bin);
	int len = strlen(bin);
	len = strlen(bin);
	int num = 0,ct = 0,j = 0;
	i = len % 4;
	if(i != 0){
		while(j < len % 4){
			num = num*2 + (bin[j]-'0');
			j++;	
		}
		printf("%d", num);
	}
	num = 0;
	while(i < len){
		num = num*2 + (bin[i]-'0');
		i++;
		ct++;
		if(ct == 4){
			ct = 0;
			if(num<=9){
				printf("%d",num);
			}
			else{
				printf("%c",num+55);
			}
			num = 0;
		}
	}	
	printf("\n");
}

