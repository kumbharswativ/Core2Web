cnt = 0
c=0
print("Enter Octal Number : ")
n = int(input())
bin = list()
while(n != 0):
	if(n%10 >= 8):
		print("Not a octal Number\n")
		exit(0)
		
	i = n % 10
	c = 0
	while(c < 3):
		bin.append(chr(i%2 + 48))
		i = i // 2
		cnt+=1
		c+=1
		
	n = n // 10
	
bin.reverse()
l = len(bin)

num = 0
ct = 0
j = 0
i = l % 4
if(i != 0):
	while(j < (l % 4)):
		num = num*2 + (ord(bin[j])-ord('0'))
		j+=1	
		
	print(num, end ="")

num = 0
while(i < l):
	num = num*2 + (ord(bin[i])-ord('0'))
	i+=1
	ct+=1
	if(ct == 4):
		ct = 0
		if(num<=9):
			print(chr(num+48), end = "")
			
		else:
			print(chr(num+55), end = "")
			
		num = 0
		
		
print()


