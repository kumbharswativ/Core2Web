try:
    n = int(input("Enter Number : "))
except ValueError as e:
    exit(0)
k = 1
for i in range(1,n+1):
    k = 3
    for j in range(n,0,-1):
        if(j > i):
            print(end = "\t")
        else:
            print(k*k, end = "\t")
            k = k + 1
    print()
