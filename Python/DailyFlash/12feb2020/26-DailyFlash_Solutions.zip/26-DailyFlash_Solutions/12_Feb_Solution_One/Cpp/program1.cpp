#include<iostream>


int main(){
	
	int num;
	printf("Enter the number : ");
	scanf("%d",&num);

	int sum = 0;

	for(int jtr = 1 ; jtr<num ; jtr++){
		sum=0;
		for (int itr =1 ; itr <= jtr/2 ; itr++){

			if(jtr%itr==0){
				sum = sum+itr;
			}	
		}	

		if(sum < jtr){
		
			printf("%d The number is deficient \n",jtr);
		}
	}

}	
