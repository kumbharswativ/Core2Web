#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void main(){


	int octalValues[]= {0,1,10,11,100,101,110,111};


	int octal;
	char hex[255]="";

	printf("Enter the ocatal number");
	scanf("%d",&octal);
	int rem = 0;
	long binary = 0;
	long place = 1;
	while(octal>0){
		
		rem = octal%10;
	       	
		binary = (octalValues[rem]*place)+binary;

		place = place*1000;
		
		octal = octal/10;	

		
	}	

	while(binary>0){

		rem = binary%10000;

		if (rem == 0)
			strcat(hex,"0");
		else if(rem == 0)
			strcat(hex,"1");
		else if(rem == 10)
			strcat(hex,"2");
		else if(rem == 11)
			strcat(hex,"3");
		else if(rem == 100)
			strcat(hex,"4");
		else if(rem == 101)
			strcat(hex,"5");
		else if(rem == 110)
			strcat(hex,"6");
		else if(rem == 111)
			strcat(hex,"7");
		else if(rem == 1000)
			strcat(hex,"8");
		else if(rem == 1001)
			strcat(hex,"9");
		else if(rem == 1010)
			strcat(hex,"A");
		else if(rem == 1011)
			strcat(hex,"B");
		else if(rem == 1100)
			strcat(hex,"C");
		else if(rem == 1101)
			strcat(hex,"D");
		else if(rem == 1110)
			strcat(hex,"E");
		else if(rem == 1111)
			strcat(hex,"F");

		binary = binary/10000;
	}	

	printf("%s",hex);

	
	


	
		
}	
