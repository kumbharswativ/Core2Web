import java.io.*;



class Program2{

	
	public static void main(String args[])throws IOException{

		BufferedReader br  = new BufferedReader(new InputStreamReader(System.in));	
		int octal = Integer.parseInt(br.readLine());

		int octalValues[]= {0,1,10,11,100,101,110,111};
		
	
	
		String hex="";
		int rem = 0;
		int binary = 0;
		int place = 1;

		while(octal>0){
		
			rem = octal%10;
	       	
			binary = (octalValues[rem]*place)+binary;

			place = place*1000;
		
			octal = octal/10;	

		
		}


		while(binary>0){

			rem = binary%10000;

			if (rem == 0)
				hex = hex+"0";
			else if(rem == 1)
				hex = hex+"1";
			else if(rem == 10)
				hex = hex+"2";
			else if(rem == 11)
				hex = hex+"3";
			else if(rem == 100)
				hex = hex+"4";
			else if(rem == 101)
				hex = hex+"5";
			else if(rem == 110)
				hex = hex+"6";
			else if(rem == 111)
				hex = hex+"7";
			else if(rem == 1000)
				hex = hex+"8";
			else if(rem == 1001)
				hex = hex+"9";
			else if(rem == 1010)
				hex = hex+"A";
			else if(rem == 1011)
				hex = hex+"B";
			else if(rem == 1100)
				hex = hex+"C";
			else if(rem == 1101)
				hex = hex+"D";
			else if(rem == 1110)
				hex = hex+"E";
			else if(rem == 1111)
				hex = hex+"F";

			binary = binary/10000;
		}


		System.out.println(hex);


	}	
}	
