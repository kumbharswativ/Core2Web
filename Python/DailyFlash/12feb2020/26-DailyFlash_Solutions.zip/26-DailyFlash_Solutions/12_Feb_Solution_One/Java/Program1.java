import java.io.*;



class Program1{

	
	public static void main(String arsg[])throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Enter the number");

		int num = Integer.parseInt(br.readLine());

		int sum = 0;

		for(int jtr = 1 ; jtr<num ; jtr++ ){
			sum=0;
			for (int itr =1 ; itr <= jtr/2 ; itr++){

				if(jtr%itr==0){
					sum = sum+itr;
				}
			}

			if(sum < jtr){
	
				System.out.printf("%d The number is deficient \n",jtr);
			}
		}
	}
		
}	
