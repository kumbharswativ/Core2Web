

num = int(raw_input("Enter the number "),8)




hexa= hex(num)


print(hexa)


""" output


Enter the number 0o265
0xb5

"""
