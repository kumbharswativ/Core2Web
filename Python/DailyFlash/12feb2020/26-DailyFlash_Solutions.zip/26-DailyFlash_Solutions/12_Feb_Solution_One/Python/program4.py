



for itr in range(0,4):

    for jtr in range(0,4):
        if jtr < 3- itr:
            print("",end="\t")
        else:
            print((itr+jtr)*(itr+jtr),end="\t")
            

    print("")
    
