#include<stdio.h>

int main(void) {
	
	char c = 65;
	printf("%c", c);
	return 0;
}	
