#include<stdio.h>

int main(void) {
	long num;
	int i = 0, odd = 0;
	printf("Enter num : ");
	scanf("%ld", &num);
	while(num != 0) {
		if((num % 10) % 2 == 1)
			odd++;
		num = num / 10;
	}
	printf("No of odd digits : %d", odd);
	return 0;
}
