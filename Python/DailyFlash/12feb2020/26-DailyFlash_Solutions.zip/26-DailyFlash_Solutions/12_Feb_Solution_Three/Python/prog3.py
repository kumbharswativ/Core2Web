num = int(input("Num : "))

while(num > 0):
    if(num % 2 == 1):
        print(num, end = " ")
    num -= 1
