octal = input("octal : ")
dec = int(octal, 8)
print("Hex : ", hex(dec))

