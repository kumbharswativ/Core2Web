import java.util.Scanner;
class Demo {
	public static void main(String[] args) {	
		int num;
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		while(num >= 0) {
			if(num % 2 == 1)
				System.out.println(num + " ");
			num--;
		}
	}
}
