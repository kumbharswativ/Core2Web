#include<iostream>
#include<string.h>
#include<stdlib.h>
int main(void) {
	char oct[10];
	char bin[30];
	char hex[10];
	char arr[3];
	for(int i = 0; i < 20; i++) {
		bin[i] = '\0';
	}
	for(int i = 0; i < 10; i++) {
		hex[i] = '\0';
	}
	printf("Enter octal : ");
	std::cin.getline(oct, sizeof(oct));
	int len = strlen(oct);
	int temp = len;
	while(temp > -1) {
		if(oct[temp - 1] > '7') {
			std::cout << "Enter valid oct num\n";
			exit(1);
		}
		temp--;
	}
	int k, i = 0, b = 0, rem, num;
	//octal to bin
	while(len > 0) {
		for(int j = 0; j < 3; j++) {
			arr[j] = '0';
		}
		num = oct[i] - 48;
		k = 0;
		while(1) {
			rem = num % 2;
			num = num / 2;
			arr[2 - k] = rem + '0';
			k++;
			if(num == 0)
				break;
		}
		for(int j = 0; j < 3; j++) {
			bin[b] = arr[j];
			b++;
		}
		i++;
		len--;	
	}
	std::cout << "bin : ";
	puts(bin);
	//bin to hex
	int d = 0, cnt= 0;
	len = strlen(bin);
	b = len % 4;
	k = 0;
	if(b != 0) {
		for(int j = 0; j < b; j++) {
			num = bin[j] - 48;
			d = d * 2 + num;
		}
		hex[k] = d < 10 ? d + '0' : d + 55;;
		k++;
	}
	d = 0;
	for(int j = b; j < len; j++) {
		num = bin[j] - 48;
		d = d * 2 + num;
		cnt++;
		if(cnt % 4 == 0) {
			hex[k] = d < 10 ? d + '0' : d + 55;
			k++;
			d = 0;
		}
	}
	std::cout << "Hex : ";
	puts(hex);
	return 0;
}
