#include<iostream>

int main() {
	long num;
	int i = 0, odd = 0;
	std::cout << "Enter num : ";
	std::cin >> num;
	while(num != 0) {
		if((num % 10) % 2 == 1)
			odd++;
		num = num / 10;
	}
	std::cout << "No of odd digits : " << odd;
	return 0;
}
