#include<iostream>

int main() {
	
	int num;
	std::cout << "Enter num : ";
	scanf("%d", &num);
	while(num >= 0) {
		if(num % 2 == 1)
			std::cout << num << " ";
		num--;
	}
	return 0;
}
