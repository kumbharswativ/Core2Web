try:
	n = int(input("Enter Binary : "),2)
except Exception as e:
	exit(0)

print(hex(n))
