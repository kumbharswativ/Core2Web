

num = input("Enter the Distance in Km ")

print("Distance in meter "+str(num*1000))

