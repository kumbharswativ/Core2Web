#include<stdio.h>


void main(){
	
	int num;

	printf("Enter the Distance in Km \n");
	scanf("%d",&num);

	printf("Distance in meter %d m",num*1000);



}	
