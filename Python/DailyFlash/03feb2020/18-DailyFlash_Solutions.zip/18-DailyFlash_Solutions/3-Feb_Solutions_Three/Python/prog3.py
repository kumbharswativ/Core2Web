dist = int(input("Dist(KM) : "))
print("dist(m) : ", dist * 1000) if dist >= 0 else print("Enter valid det.")

