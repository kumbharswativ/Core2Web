
l = input("Enter String : ")

for i in l:
    print(i,end = " ")
print()
