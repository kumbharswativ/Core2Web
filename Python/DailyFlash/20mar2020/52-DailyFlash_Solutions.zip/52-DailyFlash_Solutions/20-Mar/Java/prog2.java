import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int l, sum, mul = 1;
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		for(int i = 0; i < str.length(); i++) {
			System.out.print(str.charAt(i));
		}
	}
}
