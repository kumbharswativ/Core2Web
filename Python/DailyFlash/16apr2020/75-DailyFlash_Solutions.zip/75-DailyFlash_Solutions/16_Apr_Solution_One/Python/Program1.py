st = input("Enter a String \t :")

st = st.swapcase()

print(st)
