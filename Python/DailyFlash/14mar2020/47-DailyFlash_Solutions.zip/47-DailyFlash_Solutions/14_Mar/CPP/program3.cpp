
#include <iostream>

int main () {
	int n, t;
	std::cout << ("Enter Numbers : ");
	do {
		std::cin >> n;
		t = n;
		while(t != 0){
			if(t % 10 == 0){
				std::cout << (n) << "\n";
				break;
			}
			t /= 10;
		}
		if(n < 0)
			return 0;
	}while(1);
}
