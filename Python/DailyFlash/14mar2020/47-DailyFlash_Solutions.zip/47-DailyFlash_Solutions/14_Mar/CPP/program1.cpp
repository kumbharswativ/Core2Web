
#include <iostream>

int main () {
	int n1, n2;

	std::cout << ("Enter Numbers : ");
	std::cin >> n1 >> n2;
	
	int s1 = 0, s2 = 0;
	for(int i = 1; i<= ((n1 < n2)?(n2): (n1))/2; i++){
		if(n1 % i == 0)
			s1 += i;
		if(n2 % i == 0)
			s2 += i;

	}
	if(s1 == n2 && s2 == n1)
		std::cout << ("Numbers are Ambilical\n");
	else 
		std::cout << ("Numbers are Not Ambilical\n");
}
