
import java.io.*;

class Program {
	public static void main (String ... kanif) throws IOException{
		int n, t;
		System.out.printf("Enter Numbers : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do {
			n = Integer.parseInt(br.readLine());
			t = n;
			while(t != 0){
				if(t % 10 == 0){
					System.out.printf("%d\n", n);
					break;
				}
				t /= 10;
			}
			if(n < 0)
				return;
		}while(true);
	}
}