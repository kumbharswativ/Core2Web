

import java.io.*;

class Program {

	public static void main(String[] args) {

		int n,k =  0;
		n = 4;
		for(int i = 1; i<= n; i++){
			k = ((i == 1 || i == 4)?(0) : (2));
			for(int j = 1; j < n+i; j++){
				if(j > n-i){
					System.out.print(k + "\t");
					k = k + i - 1;
				}
				else
					System.out.printf("\t");
			}
			System.out.printf("\n");
		}
	}
}
