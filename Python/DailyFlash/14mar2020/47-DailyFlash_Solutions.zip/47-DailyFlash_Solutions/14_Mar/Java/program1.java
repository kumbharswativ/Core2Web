
import java.io.*;

class Program {

	public static void main (String ... kanif) throws IOException{
		int n1, n2;

		System.out.printf("Enter Numbers : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n1 = Integer.parseInt(br.readLine());
		n2 = Integer.parseInt(br.readLine());
		
		int s1 = 0, s2 = 0;
		for(int i = 1; i<= ((n1 < n2)?(n2): (n1))/2; i++){
			if(n1 % i == 0)
				s1 += i;
			if(n2 % i == 0)
				s2 += i;

		}
		if(s1 == n2 && s2 == n1)
			System.out.printf("Numbers are Ambilical\n");
		else 
			System.out.printf("Numbers are Not Ambilical\n");
	}
}