
print("Enter Numbers : ")
while(True) :
	n = int(input())
	t = n
	while(t != 0):
		if(t % 10 == 0):
			print(n)
			break
			
		t /= 10
		
	if(n < 0):
		exit(0)

