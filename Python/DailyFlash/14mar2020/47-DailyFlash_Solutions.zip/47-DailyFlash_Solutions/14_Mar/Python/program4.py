
n = 4
k = 0
for i in range(1,n+1):
    if(i == 1 or i == 4):
        k = 0
    else:
        k = 2
    for j in range(1, n+i):
        if j > n - i:
            print(k, end = "\t")
            k = k + i - 1
        else:
            print(end = "\t")
    print()
