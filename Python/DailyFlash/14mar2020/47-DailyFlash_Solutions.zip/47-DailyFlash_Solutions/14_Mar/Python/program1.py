print("Enter Numbers")
n1 = int(input())
n2 = int(input())
s1 = 0
s2 = 0
limit = 0
if(n1 > n2):
	limit = n1
else:
	limit = n2
for i in range(1, limit// 2 + 1):
	if(n1 % i == 0):
		s1 += i
	if(n2 % i == 0):
		s2 += i

	
if(s1 == n2 and s2 == n1):
	print("Numbers are Ambilical")
else :
	print("Numbers are Not Ambilical")

