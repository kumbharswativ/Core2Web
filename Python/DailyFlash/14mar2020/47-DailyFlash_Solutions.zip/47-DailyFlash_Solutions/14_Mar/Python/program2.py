n = int(input("Enter Number : "))
max = n % 10
rev = 0
while(n != 0):
	if(max < n % 10):
		max = n % 10
	rev = rev * 10 + n % 10
	n = n // 10
	
while(rev != 0):
	if(rev % 10 == 1):
		n = n * 10 + max
	else:
		n = n * 10 + rev % 10
	rev = rev // 10
print(n)

