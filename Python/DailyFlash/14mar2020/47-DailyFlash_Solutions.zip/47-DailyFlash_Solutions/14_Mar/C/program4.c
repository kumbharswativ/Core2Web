
#include <stdio.h>

void main() {

	int n, k;
	//printf("Enter Number : ");
	//scanf("%d", &n);
	n =4;
	for(int i = 1; i <= n; i++){
		k = ((i == 1 || i == 4)?(0) : (2));
		for(int j = 1; j < n + i; j++){
			if(j > n-i){
				printf("%d\t", (k));
				k = k + i-1;
			}
			else{
				printf("\t");
			}
		}
		printf("\n");
	}
}
