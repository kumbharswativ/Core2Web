
#include <stdio.h>

void main () {
	int n, t;
	printf("Enter Numbers : ");
	do {
		scanf("%d", &n);
		t = n;
		while(t != 0){
			if(t % 10 == 0){
				printf("%d\n", n);
				break;
			}
			t /= 10;
		}
		if(n < 0)
			return;
	}while(1);
}
