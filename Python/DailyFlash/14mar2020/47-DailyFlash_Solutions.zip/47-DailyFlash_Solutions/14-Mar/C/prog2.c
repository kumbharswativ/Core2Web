#include<stdio.h>
#include<math.h>
int main() {
	int num;
	printf("Enter num : ");
	scanf("%d", &num);
	int temp = num, max = 0;
	while(temp != 0) {
		if(max <= temp % 10)
			max = temp % 10;
		temp /= 10;
	}
	temp = num;
	int cnt = 0;
	while(temp != 0) {
		cnt++;
		if(temp % 10 == 1) {
			num += (max - 1) * pow(10, cnt - 1);	
		}
		temp /= 10;
	}
	printf("%d", num);
}
