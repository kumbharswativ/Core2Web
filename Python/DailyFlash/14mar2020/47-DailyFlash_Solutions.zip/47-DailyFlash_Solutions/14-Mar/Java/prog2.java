import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num;
		System.out.println("Enter num : ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		int temp = num, max = 0;
		while(temp != 0) {
			if(max <= temp % 10)
				max = temp % 10;
			temp /= 10;
		}
		temp = num;
		int cnt = 0;
		while(temp != 0) {
			cnt++;
			if(temp % 10 == 1) {
				num += (max - 1) * Math.pow(10, cnt - 1);	
			}
			temp /= 10;
		}
		System.out.println(num);
	}
}
