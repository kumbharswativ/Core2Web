import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num, temp, len, cnt;
		Scanner sc = new Scanner(System.in);
		do {
			num = sc.nextInt();
			temp = num;
			len = 0;
			while(temp != 0) {
				len += 1;
				temp /= 10;
			}
			temp = num;
			cnt = 0;
			while(temp != 0) {
				len--;
				if(temp % 10 == 0) {
					if(len == 0) {
						cnt = 0;
						break;
					}
					cnt++;
				}
				temp /= 10;
			}
			if(cnt > 0)
				System.out.println(num);
		} while(num >= 0);
	}
}
