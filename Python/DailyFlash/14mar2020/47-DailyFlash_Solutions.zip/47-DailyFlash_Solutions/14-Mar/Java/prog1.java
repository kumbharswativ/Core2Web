import java.util.Scanner;
class Demo {
	public static void main(String[] args) {
		int num1, num2, sum1 = 0, sum2 = 0;
		System.out.println("Enter num1, num2 : ");
		Scanner sc = new Scanner(System.in);
		num1 = sc.nextInt();
		num2 = sc.nextInt();

		for(int i = 1; i <= Math.sqrt(num1); i++) {
			if(num1 % i == 0) {
				if(i == (num1 / i)) {
					sum1 += i;
				} else {
					sum1 += i + (num1 / i);
				}
			}
		}

		for(int i = 1; i <= Math.sqrt(num2); i++) {
			if(num2 % i == 0) {
				if(i == (num2 / i)) {
					sum2 += i;
				} else {
					sum2 += i + (num2 / i);
				}
			}
		}

		if(sum1 == sum2) 
			System.out.println("amicable.");
	}
}
