class Demo {
	public static void main(String[] args) {
		int num;
		for(int i = 0; i < 4; i++) {
			if(i == 1 || i == 2)
				num = i;
			else
				num = 0;
			for(int j = 0; j < 7; j++) {
				if(j < 4) {
					if(j >= 3 - i) {
						System.out.print(num + "\t");
						num += i;
					} else {
						System.out.print("\t");
					}
				} else {
					if(j < 4 + i) {
						System.out.print(num + "\t");
						num += i;
					}
				}
			}
			System.out.println();
		}
	}
}
