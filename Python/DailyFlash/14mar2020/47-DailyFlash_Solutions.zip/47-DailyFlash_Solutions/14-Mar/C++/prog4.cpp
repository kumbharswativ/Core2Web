#include<iostream>

int main() {
	int num;
	for(int i = 0; i < 4; i++) {
		if(i == 1 || i == 2)
			num = i;
		else
			num = 0;
		for(int j = 0; j < 7; j++) {
			if(j < 4) {
				if(j >= 3 - i) {
					std::cout << num << "\t";
					num += i;
				} else {
					std::cout << "\t";
				}
			} else {
				if(j < 4 + i) {
					std::cout << num << "\t";
					num += i;
				}
			}
		}
		std::cout << "\n";
	}
}
