#include<iostream>
#include<math.h>
int main() {
	int num;
	std::cout << "Enter num : ";
	std::cin >> num;
	int temp = num, max = 0;
	while(temp != 0) {
		if(max <= temp % 10)
			max = temp % 10;
		temp /= 10;
	}
	temp = num;
	int cnt = 0;
	while(temp != 0) {
		cnt++;
		if(temp % 10 == 1) {
			num += (max - 1) * pow(10, cnt - 1);	
		}
		temp /= 10;
	}
	std::cout << num;
}
