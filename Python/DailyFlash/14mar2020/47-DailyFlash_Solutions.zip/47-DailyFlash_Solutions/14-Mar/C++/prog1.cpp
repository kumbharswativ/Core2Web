#include<iostream>
#include<math.h>
int main() {
	int num1, num2, sum1 = 0, sum2 = 0;
	std::cout << "Enter num1, num2 : ";
	std::cin >> num1 >> num2;

	for(int i = 1; i <= sqrt(num1); i++) {
		if(num1 % i == 0) {
			if(i == (num1 / i)) {
				sum1 += i;
			} else {
				sum1 += i + (num1 / i);
			}
		}
	}

	for(int i = 1; i <= sqrt(num2); i++) {
		if(num2 % i == 0) {
			if(i == (num2 / i)) {
				sum2 += i;
			} else {
				sum2 += i + (num2 / i);
			}
		}
	}

	if(sum1 == sum2) 
		std::cout << "amicable.";
}
