#include<iostream>

int main() {
	int num, temp, len, cnt;
	do {
		std::cin >> num;
		temp = num;
		len = 0;
		while(temp != 0) {
			len += 1;
			temp /= 10;
		}
		temp = num;
		cnt = 0;
		while(temp != 0) {
			len--;
			if(temp % 10 == 0) {
				if(len == 0) {
					cnt = 0;
					break;
				}
				cnt++;
			}
			temp /= 10;
		}
		if(cnt > 0)
			std::cout << num << "\n";
	} while(num >= 0);
}
