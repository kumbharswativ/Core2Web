import math
num1, num2 = [int(i) for i in input("Enter num1, num2 : ").split()]
sum1 = 0
sum2 = 0
for i in range(1, int(math.sqrt(num1)) + 1):
    if(num1 % i == 0):
        if(i == (num1 / i)):
            sum1 += i 
        else:
            sum1 =sum1 +  i + int(num1 / i) 

for i in range(1, int(math.sqrt(num2)) + 1):
    if(num2 % i == 0):
        if(i == (num2 / i)):
            sum2 += i 
        else:
            sum2 = sum2 + i + int(num2 / i) 

if(sum1 == sum2):
    print("amicable.") 

