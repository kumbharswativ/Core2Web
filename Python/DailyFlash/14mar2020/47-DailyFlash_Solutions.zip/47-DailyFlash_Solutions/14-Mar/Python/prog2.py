num = int(input("Enter num : "))
temp = num
m = 0
while(temp != 0):
    if(temp % 10 >= m):
        m = temp % 10
    temp = int(temp / 10)
temp = num
cnt = 0
while(temp != 0):
    cnt += 1
    if(temp % 10 == 1):
        num = num + (m - 1) * pow(10, cnt - 1)
    temp = int(temp / 10)
print(num)
