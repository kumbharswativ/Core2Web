l = 0
while(True):
    num = int(input())
    if(num < 0):
        break
    temp = num
    while(temp != 0):
        l += 1
        temp = int(temp / 10)
    temp = num
    cnt = 0
    while(temp != 0):
        l -= 1
        if(temp % 10 == 0):
            if(l == 0):
                cnt = 0
                break
            cnt += 1
        temp = int(temp / 10)
    if(cnt > 0):
        print(num)

