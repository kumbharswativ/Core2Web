for i in range(4):
    if(i == 1 or i == 2):
        num = i
    else:
        num = 0
    for j in range(7):
        if(j < 4):
            if(j >= 3 - i):
                print(num, end = "\t")
                num += i
            else:
                print("", end = "\t")
        else:
            if(j < 4 + i):
                print(num, end = "\t")
                num += i
    print()

